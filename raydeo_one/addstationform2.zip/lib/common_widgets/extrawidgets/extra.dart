// _initURIHandler();
//     _incomingLinkHandler();
// 
// 
// 
// Future<void> _initURIHandler() async {
//     if (!_initialURILinkHandled) {
//       _initialURILinkHandled = true;
//       // Fluttertoast.showToast(
//       //     msg: "Invoked _initURIHandler",
//       //     toastLength: Toast.LENGTH_SHORT,
//       //     gravity: ToastGravity.BOTTOM,
//       //     timeInSecForIosWeb: 1,
//       //     backgroundColor: Colors.green,
//       //     textColor: Colors.white);
//       try {
//         final initialURI = await getInitialUri();
//         // Use the initialURI and warn the user if it is not correct,
//         // but keep in mind it could be `null`.
//         if (initialURI != null) {
//           debugPrint("Initial URI received $initialURI");
//           if (!mounted) {
//             return;
//           }
//           setState(() {});
//         } else {
//           debugPrint("Null Initial URI received");
//         }
//       } on PlatformException {
//         // Platform messages may fail, so we use a try/catch PlatformException.
//         // Handle exception by warning the user their action did not succeed
//         debugPrint("Failed to receive initial uri");
//       } on FormatException catch (err) {
//         if (!mounted) {
//           return;
//         }
//         debugPrint('Malformed Initial URI received');
//       }
//     }
//   }

//   /// Handle incoming links - the ones that the app will receive from the OS
//   /// while already started.
//   void _incomingLinkHandler() {
//     if (!kIsWeb) {
//       // It will handle app links while the app is already started - be it in
//       // the foreground or in the background.
//       _streamSubscription = uriLinkStream.listen((Uri? uri) {
//         if (!mounted) {
//           return;
//         }
//         debugPrint('Received URI: $uri');
//         setState(() {});
//       }, onError: (Object err) {
//         if (!mounted) {
//           return;
//         }
//         debugPrint('Error occurred: $err');
//         setState(() {
//           if (err is FormatException) {
//           } else {}
//         });
//       });
//     }
//   }
// 
// 
// 
// 
// 
// Text(
                      //   "$nameOfChannel",
                      //   textAlign:
                      //       TextAlign.center,
                      //   style: const TextStyle(
                      //       fontSize: 25,
                      //       fontWeight:
                      //           FontWeight.bold,
                      //       color: Colors.white),
                      // ),
                      // Row(
                      //   mainAxisAlignment:
                      //       MainAxisAlignment
                      //           .spaceAround,
                      //   children: [
                      //     InkWell(
                      //       onTap: () {
                      //         // _dialogBuilder(context);
                      //         print("tapped");
                      //         tapped.value = true;
                      //       },
                      //       child: Column(
                      //         children: const [
                      //           Icon(
                      //             Icons
                      //                 .chat_sharp,
                      //             size: 35,
                      //             color: Colors
                      //                 .white,
                      //           ),
                      //           Text(
                      //             "Live Chat",
                      //             style: TextStyle(
                      //                 fontSize:
                      //                     18,
                      //                 fontWeight:
                      //                     FontWeight
                      //                         .bold,
                      //                 color: Colors
                      //                     .white),
                      //           )
                      //         ],
                      //       ),
                      //     ),
                      //     InkWell(
                      //       onTap: () {},
                      //       child: Column(
                      //         children: const [
                      //           Icon(
                      //             Icons
                      //                 .keyboard_voice_rounded,
                      //             size: 35,
                      //             color: Colors
                      //                 .white,
                      //           ),
                      //           Text(
                      //             "Detect Audio",
                      //             style: TextStyle(
                      //                 fontSize:
                      //                     18,
                      //                 fontWeight:
                      //                     FontWeight
                      //                         .bold,
                      //                 color: Colors
                      //                     .white),
                      //           )
                      //         ],
                      //       ),
                      //     ),
                      //   ],
                      // ),