import 'package:amplify_api/amplify_api.dart';
import 'package:amplify_flutter/amplify_flutter.dart';

class GraphqlServices {
  CreateChannel() async {
    try {
      var operation = await Amplify.API.query(
        request: GraphQLRequest<String>(
            document: ''' mutation CreateChannel(\$input: CreateChannelInput) {
    CreateChannel(input: \$input) {
      status
      status_message
      __typename
    }
  }
   ''',
            variables: {
              'input': {
                'channel_name': 'demo',
                'channel_stream_url': 'demo',
                'channel_location': 'demo',
              }
            }),
      );
      var response = await operation.response;
      print('Mutation result:${response}');
      var data = response.data;
      var errors = response.errors;
      print('Mutation result:${data}');
    } catch (e) {
      print('error:$e');
    }
  }
}
