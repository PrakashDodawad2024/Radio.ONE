import 'dart:convert';
import 'dart:math' as math;
import 'dart:math';
import 'dart:ui' as ui;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:radio_player/radio_player.dart';
import 'package:raydeo_one/widgets/connectivity.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:volume_controller/volume_controller.dart';
import '../backgroundplay/frp_player.dart';
import '../backgroundplay/mainplay.dart';
import '../main.dart';
import '../mqtt/mqttconnection.dart';
import '../mqtt/mqttregister.dart';
import '../widgets/allchannel.dart';
import '../widgets/chatpage.dart';
import '../widgets/minimusic.dart';
import '../widgets/musicplayer.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import '../widgets/search.dart';

final controllerStack = MiniplayerController();
RxBool miniplayerOpen = false.obs;
RxBool loader = false.obs;
int currentindex = 0;
Map surce = {ConnectivityResult.none: false};
MyConnectivity _connectivity = MyConnectivity.instance;
String status = "Mobile: Online";
RxBool miniplayerOpened = false.obs;
RadioPlayer _radioPlayer = RadioPlayer();
bool isPlaying = false;

List<String>? metadata;
RxBool playing = false.obs;

class MyHomePage extends StatefulWidget {
  final FlutterRadioPlayer flutterRadioPlayers;
  final FRPSource frpSource;
  final bool useIcyData;

  const MyHomePage({
    Key? key,
    required this.flutterRadioPlayers,
    required this.frpSource,
    required this.useIcyData,
  }) : super(key: key);
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // initRadioPlayer();
    AudioPlayer.global.setGlobalAudioContext(_getAudioContext());
    widget.flutterRadioPlayers.useIcyData(widget.useIcyData);
    print("categories:$categorylist");
    _connectivity.initialise();
    _connectivity.myStream.listen((source) {
      if (!mounted) {
        return;
      } else {
        setState(() => surce = source);
      }
    });
  }

  // void initRadioPlayer() {

  // }

  connectmqtt() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var connectionDetail =
        await jsonDecode("${sharedPreferences.getString('allconnectionData')}");
    print(
        "connectionDetailconnectionDetail:${sharedPreferences.getString('allconnectionData')}");
    await MQTTConnections().connectToMQTTMethod(
        connectionDetail['ip_address'],
        connectionDetail['port'],
        connectionDetail['user_name'],
        connectionDetail['password']);
  }

  bool _customTileExpanded = false;
  int selected = -1;
  int currentIndex = 0;
  String frpStatus = "flutter_radio_stopped";
  static final AudioPlayer _player = AudioPlayer();
  double _volumeListenerValue = 0;
  double _getVolume = 0;

  @override
  void dispose() {
    VolumeController().removeListener();
    super.dispose();
  }

  AudioContext _getAudioContext() {
    return const AudioContext(
        android: AudioContextAndroid(
          isSpeakerphoneOn: false,
          stayAwake: true,
          contentType: AndroidContentType.music,
          usageType: AndroidUsageType.media,
          audioFocus: AndroidAudioFocus.gain,
        ),
        iOS: AudioContextIOS(
            category: AVAudioSessionCategory.soloAmbient,
            options: [
              // AVAudioSessionOptions.defaultToSpeaker,
            ]
            // +
            // [AVAudioSessionOptions.allowAirPlay] +
            // [AVAudioSessionOptions.allowBluetooth] +
            // [AVAudioSessionOptions.allowBluetoothA2DP]
            ));
  }

  startminiplayerOpen(url) {
    playing.value = true;
    _player.play(UrlSource('$url'));
  }

  stopminiplayerOpen() {
    playing.value = false;
    _player.stop();
  }

  getSegregatedLists() {
    print("segrerrere");
    return Obx(
      () => SingleChildScrollView(
        child: Column(
          children: [
            for (int j = 0; j < categorylist.length; j++)
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ExpansionTile(
                    title: const Text('ExpansionTile 2'),
                    subtitle: const Text('Custom expansion arrow icon'),
                    trailing: Icon(
                      _customTileExpanded
                          ? Icons.arrow_drop_down_circle
                          : Icons.arrow_drop_down,
                    ),
                    children: const <Widget>[
                      ListTile(title: Text('This is tile number 2')),
                    ],
                    onExpansionChanged: (bool expanded) {
                      setState(() {
                        _customTileExpanded = expanded;
                      });
                    },
                  ),
                  Container(
                      color: Colors.white,
                      child: SingleChildScrollView(
                        child: Column(children: [
                          ListView.builder(
                            key: Key(
                                'builder ${selected.toString()}'), //attention
                            padding: const EdgeInsets.only(
                                left: 13.0, right: 13.0, bottom: 25.0),
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: alldata.length,
                            itemBuilder: (context, index) {
                              return Column(children: <Widget>[
                                ExpansionTile(
                                    key: Key(index.toString()), //attention
                                    initiallyExpanded:
                                        index == selected, //attention

                                    leading: const Icon(
                                      Icons.person,
                                      size: 50.0,
                                      color: Colors.black,
                                    ),
                                    title: Text('${categorylist[j]}',
                                        style: const TextStyle(
                                            color: Color(0xFF09216B),
                                            fontSize: 17.0,
                                            fontWeight: FontWeight.bold)),
                                    // subtitle: Text(
                                    //   'Software Engineer',
                                    //   style: TextStyle(
                                    //       color: Colors.black,
                                    //       fontSize: 13.0,
                                    //       fontWeight: FontWeight.bold),
                                    // ),
                                    children: [
                                      InkWell(
                                        onTap: () async {
                                          if (status != 'Offline') {
                                            if (idOfChannel != "") {
                                              await MQTTConnections()
                                                  .MQTTUnSubscribeMethod(
                                                      "$idOfChannel");
                                              controllerStack.animateToHeight(
                                                  state: PanelState.MAX,
                                                  duration: const Duration(
                                                      milliseconds: 30));
                                            }
                                            controllerStack.animateToHeight(
                                                state: PanelState.MAX,
                                                duration: const Duration(
                                                    milliseconds: 30));

                                            // print("called");
                                            // print(
                                            //     "channel_id:${alldata[index]["channel_id"]}");
                                            // print(
                                            //     "channel_namesss:${alldata[index]["channel_name"]}");
                                            // if (play.value == true)

                                            currentindx = alldata[index]
                                                ["total_number_of_subscribers"];

                                            Mqtt.firsttime!.value = false;
                                            nameOfChannel.value =
                                                alldata[index]["channel_name"];
                                            descOfChannel.value = alldata[index]
                                                ["channel_description"];
                                            idOfChannel.value =
                                                alldata[index]["channel_id"];
                                            urlOfChannel.value = alldata[index]
                                                ["channel_stream_url"];
                                            imgurlOfChannel.value =
                                                alldata[index]
                                                    ["channel_image_url"];
                                            // startminiplayerOpen(urlOfChannel);

                                            await MQTTConnections()
                                                .MQTTSubscribeMethod(
                                                    "$idOfChannel");
                                            _radioPlayer.stop();
                                            await _radioPlayer.setChannel(
                                              title: '$nameOfChannel',
                                              url: '$urlOfChannel',
                                              imagePath: '$imgurlOfChannel',
                                            );
                                            Future.delayed(
                                                const Duration(
                                                    milliseconds: 10), () {
                                              _radioPlayer.play();
                                            });

                                            _radioPlayer.stateStream
                                                .listen((value) {
                                              print("sdgxcfhjbkn:$value");
                                              setState(() {
                                                isPlaying = value;
                                              });
                                            });

                                            _radioPlayer.metadataStream
                                                .listen((value) {
                                              setState(() {
                                                metadata = value;
                                              });
                                            });

                                            print(
                                                "nameOfChannel:${nameOfChannel}");
                                            print(
                                                "descOfChannel:${descOfChannel}");
                                            print(
                                                "firsttime:${Mqtt.firsttime!.value}");
                                          } else {
                                            _radioPlayer.stop();
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(SnackBar(
                                                    behavior: SnackBarBehavior
                                                        .floating,
                                                    padding:
                                                        const EdgeInsets.all(5),
                                                    shape:
                                                        const StadiumBorder(),
                                                    backgroundColor:
                                                        const Color.fromARGB(
                                                            255, 242, 242, 242),
                                                    duration: const Duration(
                                                        seconds: 3),
                                                    content: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: const [
                                                        SizedBox(
                                                          width: 40,
                                                          height: 40,
                                                          child: Image(
                                                              image: AssetImage(
                                                                  "assets/Raydeo.ONE512.png")),
                                                        ),
                                                        SizedBox(
                                                          width: 250,
                                                          child: Text(
                                                            "Please check your internet connection and try again",
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                fontSize: 14),
                                                          ),
                                                        )
                                                      ],
                                                    )));
                                          }
                                        },
                                        child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              .3,
                                          height: MediaQuery.of(context)
                                                  .size
                                                  .height *
                                              .2,
                                          margin: const EdgeInsets.only(
                                              left: 8, right: 20),
                                          // padding: const EdgeInsets.all(5),
                                          alignment: Alignment.center,
                                          decoration: const BoxDecoration(
                                              // image: DecorationImage(
                                              //   image: NetworkImage(
                                              //       "${alldata[index]['channel_image_url']}"),
                                              // ),

                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(40))),
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(12.0),
                                            child: status != 'Offline'
                                                ? Image.network(
                                                    "${alldata[index]['channel_image_url']}",
                                                  )
                                                : const Image(
                                                    image: AssetImage(
                                                        "assets/Raydeo.ONE512.png")),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                .3,
                                        child: Text(
                                          "${alldata[index]['channel_name']}",
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                              color: Colors.black,
                                              fontSize: 12),
                                        ),
                                      ),
                                    ],
                                    onExpansionChanged: ((newState) {
                                      if (newState) {
                                        setState(() {
                                          const Duration(seconds: 20000);
                                          selected = index;
                                        });
                                      } else {
                                        setState(() {
                                          selected = -1;
                                        });
                                      }
                                    })),
                              ]);
                            },
                          )
                        ]),
                      )),
                  // Container(
                  //   margin: const EdgeInsets.only(left: 20),
                  //   width: MediaQuery.of(context).size.width * 1,
                  //   child: Text(
                  //     "${categorylist[j]}",
                  //     style: const TextStyle(
                  //         color: Colors.black,
                  //         fontSize: 22,
                  //         fontWeight: FontWeight.bold),
                  //     textAlign: TextAlign.start,
                  //   ),
                  // ),
                  // SizedBox(
                  //   width: MediaQuery.of(context).size.width * 1,
                  //   height: MediaQuery.of(context).size.height * 0.26,
                  //   //  color: Colors.green.withOpacity(0.5),
                  //   child: ListView.builder(
                  //     shrinkWrap: true,
                  //     scrollDirection: Axis.horizontal,
                  //     itemCount: alldata.length,
                  //     itemBuilder: (context, index) {
                  //       // print("checkk:${alldata[index]} ${categorylist[j]}");
                  //       return (alldata[index]['channel_category']
                  //               .contains(categorylist[j]))
                  //           ? Column(
                  //               mainAxisAlignment: MainAxisAlignment.start,
                  //               children: [
                  //                 InkWell(
                  //                   onTap: () async {
                  //                     if (status != 'Offline') {
                  //                       if (idOfChannel != "") {
                  //                         await MQTTConnections()
                  //                             .MQTTUnSubscribeMethod(
                  //                                 "$idOfChannel");
                  //                         controllerStack.animateToHeight(
                  //                             state: PanelState.MAX,
                  //                             duration: const Duration(
                  //                                 milliseconds: 30));
                  //                       }
                  //                       controllerStack.animateToHeight(
                  //                           state: PanelState.MAX,
                  //                           duration: const Duration(
                  //                               milliseconds: 30));

                  //                       // print("called");
                  //                       // print(
                  //                       //     "channel_id:${alldata[index]["channel_id"]}");
                  //                       // print(
                  //                       //     "channel_namesss:${alldata[index]["channel_name"]}");
                  //                       // if (play.value == true)

                  //                       currentindx = alldata[index]
                  //                           ["total_number_of_subscribers"];

                  //                       Mqtt.firsttime!.value = false;
                  //                       nameOfChannel.value =
                  //                           alldata[index]["channel_name"];
                  //                       descOfChannel.value = alldata[index]
                  //                           ["channel_description"];
                  //                       idOfChannel.value =
                  //                           alldata[index]["channel_id"];
                  //                       urlOfChannel.value = alldata[index]
                  //                           ["channel_stream_url"];
                  //                       imgurlOfChannel.value =
                  //                           alldata[index]["channel_image_url"];
                  //                       // startminiplayerOpen(urlOfChannel);

                  //                       await MQTTConnections()
                  //                           .MQTTSubscribeMethod(
                  //                               "$idOfChannel");
                  //                       _radioPlayer.stop();
                  //                       await _radioPlayer.setChannel(
                  //                         title: '$nameOfChannel',
                  //                         url: '$urlOfChannel',
                  //                         imagePath: '$imgurlOfChannel',
                  //                       );
                  //                       Future.delayed(
                  //                           const Duration(milliseconds: 10),
                  //                           () {
                  //                         _radioPlayer.play();
                  //                       });

                  //                       _radioPlayer.stateStream
                  //                           .listen((value) {
                  //                         print("sdgxcfhjbkn:$value");
                  //                         setState(() {
                  //                           isPlaying = value;
                  //                         });
                  //                       });

                  //                       _radioPlayer.metadataStream
                  //                           .listen((value) {
                  //                         setState(() {
                  //                           metadata = value;
                  //                         });
                  //                       });

                  //                       print("nameOfChannel:${nameOfChannel}");
                  //                       print("descOfChannel:${descOfChannel}");
                  //                       print(
                  //                           "firsttime:${Mqtt.firsttime!.value}");
                  //                     } else {
                  //                       _radioPlayer.stop();
                  //                       ScaffoldMessenger.of(context)
                  //                           .showSnackBar(SnackBar(
                  //                               behavior:
                  //                                   SnackBarBehavior.floating,
                  //                               padding:
                  //                                   const EdgeInsets.all(5),
                  //                               shape: const StadiumBorder(),
                  //                               backgroundColor:
                  //                                   const Color.fromARGB(
                  //                                       255, 242, 242, 242),
                  //                               duration:
                  //                                   const Duration(seconds: 3),
                  //                               content: Row(
                  //                                 mainAxisAlignment:
                  //                                     MainAxisAlignment
                  //                                         .spaceEvenly,
                  //                                 children: const [
                  //                                   SizedBox(
                  //                                     width: 40,
                  //                                     height: 40,
                  //                                     child: Image(
                  //                                         image: AssetImage(
                  //                                             "assets/Raydeo.ONE512.png")),
                  //                                   ),
                  //                                   SizedBox(
                  //                                     width: 250,
                  //                                     child: Text(
                  //                                       "Please check your internet connection and try again",
                  //                                       textAlign:
                  //                                           TextAlign.center,
                  //                                       style: TextStyle(
                  //                                           color: Colors.black,
                  //                                           fontWeight:
                  //                                               FontWeight.bold,
                  //                                           fontSize: 14),
                  //                                     ),
                  //                                   )
                  //                                 ],
                  //                               )));
                  //                     }
                  //                   },
                  //                   child: Container(
                  //                     width: MediaQuery.of(context).size.width *
                  //                         .3,
                  //                     height:
                  //                         MediaQuery.of(context).size.height *
                  //                             .2,
                  //                     margin: const EdgeInsets.only(
                  //                         left: 8, right: 20),
                  //                     // padding: const EdgeInsets.all(5),
                  //                     alignment: Alignment.center,
                  //                     decoration: const BoxDecoration(
                  //                         // image: DecorationImage(
                  //                         //   image: NetworkImage(
                  //                         //       "${alldata[index]['channel_image_url']}"),
                  //                         // ),

                  //                         borderRadius: BorderRadius.all(
                  //                             Radius.circular(40))),
                  //                     child: ClipRRect(
                  //                       borderRadius:
                  //                           BorderRadius.circular(12.0),
                  //                       child: status != 'Offline'
                  //                           ? Image.network(
                  //                               "${alldata[index]['channel_image_url']}",
                  //                             )
                  //                           : const Image(
                  //                               image: AssetImage(
                  //                                   "assets/Raydeo.ONE512.png")),
                  //                     ),
                  //                   ),
                  //                 ),
                  //                 SizedBox(
                  //                   width:
                  //                       MediaQuery.of(context).size.width * .3,
                  //                   child: Text(
                  //                     "${alldata[index]['channel_name']}",
                  //                     textAlign: TextAlign.center,
                  //                     style: const TextStyle(
                  //                         color: Colors.black, fontSize: 12),
                  //                   ),
                  //                 ),
                  //                 // SizedBox(
                  //                 //   height: MediaQuery.of(context).size.height *
                  //                 //       0.05,
                  //                 // ),

                  //                 // Align(
                  //                 //   alignment: Alignment.topRight,
                  //                 //   child: Container(
                  //                 //     width: 75,
                  //                 //     height: 35,
                  //                 //     decoration: BoxDecoration(
                  //                 //         color: Colors.black38,
                  //                 //         borderRadius:
                  //                 //             BorderRadius.circular(20)),
                  //                 //     margin: EdgeInsets.only(
                  //                 //         left: MediaQuery.of(context)
                  //                 //                 .size
                  //                 //                 .width *
                  //                 //             0.28,
                  //                 //         top: MediaQuery.of(context)
                  //                 //                 .size
                  //                 //                 .width *
                  //                 //             0.045),
                  //                 //     child: Center(
                  //                 //       child: Padding(
                  //                 //         padding: const EdgeInsets.all(2.0),
                  //                 //         child: Row(
                  //                 //           children: [
                  //                 //             const Icon(
                  //                 //               Icons.remove_red_eye,
                  //                 //               color: Colors.white,
                  //                 //             ),
                  //                 //             Text(
                  //                 //               " ${alldata[index]["total_number_of_subscribers"]}",
                  //                 //               style: const TextStyle(
                  //                 //                   color: Colors.white),
                  //                 //             ),
                  //                 //           ],
                  //                 //         ),
                  //                 //       ),
                  //                 //     ),
                  //                 //   ),
                  //                 // ),
                  //               ],
                  //             )
                  //           : const SizedBox(
                  //               height: 0,
                  //             );
                  //     },
                  //   ),
                  // ),
                ],
              ),
            if (Mqtt.firsttime!.value == false)
              const SizedBox(
                height: 130,
              )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    print('status**********:${status}');
    switch (surce.keys.toList()[0]) {
      case ConnectivityResult.none:
        status = "Offline";

        isDataConnected = false;
        _radioPlayer.stop();

        break;
      case ConnectivityResult.mobile:
        status = "Mobile: Online";

        isDataConnected = true;

        break;
      case ConnectivityResult.wifi:
        status = "WiFi: Online";

        isDataConnected = true;

        break;
      case ConnectivityResult.ethernet:
        status = "Ethernet: Online";

        isDataConnected = true;

        break;
    }
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: ValueListenableBuilder(
          valueListenable: allmessages!.listenable(),
          builder: (context, value, child) {
            final allresponse = allmessages!.get("allmessages");
            print("allresponvvbvbse$allresponse");
            if (allresponse != null) {
              final decodeddata = jsonDecode(allresponse["channel_message"]);
              final alldecodeddata = jsonDecode(decodeddata["description"]);
              // print("alldecodeddata${alldecodeddata}");
              alldata = alldecodeddata;
              print("alldaddddta$alldata");
              // if (alldata.length != 0) {
              print("segregating alldata");
              for (int i = 0; i < alldata.length; i++) {
                if (!categorylist.contains(alldata[i]["channel_category"])) {
                  categorylist.add(alldata[i]["channel_category"]);
                  print("categorylist$categorylist");
                }
                if (!titlelist.contains(alldata[i]["channel_name"])) {
                  titlelist.add(alldata[i]["channel_name"]);
                  print("titlelist$titlelist");
                }
              }
              // print("tapped${alldata.contains("$idOfChannel")}");
              // if (alldata.contains("$idOfChannel")) {
              //   // print("tappedcontaines:$tapped");

              //   Mqtt.firsttime!.value = false;

              //   print("tappedcontaines:$tapped");
              // } else {
              //   print("tappedcoes$idOfChannel");
              //   // print("beforeeeee:$tapped");
              //   Mqtt.firsttime!.value = true;
              //   print("tappeddoesnt:$tapped");
              // }
            }

            return MiniplayerWillPopScope(
              onWillPop: () async {
                return false;
              },
              child: Obx(
                () => Stack(
                  children: <Widget>[
                    Container(
                      height: MediaQuery.of(context).size.height * 1,
                      padding: const EdgeInsets.only(top: 30),
                      color: const Color.fromARGB(255, 242, 242, 242),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(
                                  height: 45,
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 20, right: 20),
                                  width: MediaQuery.of(context).size.width * 1,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      IconButton(
                                        onPressed: () {
                                          // method to show the search bar
                                          showSearch(
                                              context: context,
                                              // delegate to customize the search bar
                                              delegate: CustomSearchDelegate(
                                                  setState: setState));
                                        },
                                        icon: const Icon(
                                          Icons.search,
                                          color: Colors.black,
                                          size: 30,
                                        ),
                                      ),
                                      const Spacer(),
                                      const Text(
                                        'Radio.ONE',
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 30,
                                            fontWeight: FontWeight.bold),
                                        textAlign: TextAlign.start,
                                      ),
                                      const Spacer(),
                                      IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.account_circle_rounded,
                                          color: Colors.black,
                                          size: 35,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height * 0.02,
                                ),
                                SizedBox(
                                    height: miniplayerOpen.value != null
                                        ? MediaQuery.of(context).size.height *
                                                1 -
                                            160
                                        : 120,
                                    child: (categorylist.isNotEmpty)
                                        ? getSegregatedLists()
                                        : const Center(
                                            child: CircularProgressIndicator(),
                                          )),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    // if (status == 'Offline')
                    //   Container(
                    //     width: double.infinity,
                    //     margin: EdgeInsets.only(
                    //         top: Mqtt.firsttime!.value == false
                    //             ? MediaQuery.of(context).size.height * 0.78
                    //             : MediaQuery.of(context).size.height * 0.9),
                    //     padding: EdgeInsets.all(10),
                    //     child: Container(
                    //       color: Colors.grey.shade500,
                    //       height: 40,
                    //       width: double.infinity,
                    //       alignment: Alignment.center,
                    //       child: Row(
                    //         mainAxisAlignment: MainAxisAlignment.center,
                    //         children: const [
                    //           Icon(
                    //             Icons.wifi_off,
                    //             color: Colors.white60,
                    //           ),
                    //           SizedBox(
                    //             width: 10,
                    //           ),
                    //           Text(
                    //             'No Internet Connection!..',
                    //             style: TextStyle(color: Colors.white60),
                    //           ),
                    //         ],
                    //       ),
                    //     ),
                    //   ),
                    Mqtt.firsttime!.value == false
                        ? Miniplayer(
                            controller: controllerStack,
                            backgroundColor: Colors.grey,
                            minHeight: 120,
                            maxHeight: MediaQuery.of(context).size.height * 1,
                            builder: (height, percentage) => ClipRect(
                                  child: BackdropFilter(
                                      filter: ui.ImageFilter.blur(
                                          sigmaX: 100.0,
                                          sigmaY: 100.0,
                                          tileMode: TileMode.mirror),
                                      child: (height != 120)
                                          ? FutureBuilder(
                                              future: _radioPlayer
                                                  .getArtworkImage(),
                                              builder: (BuildContext context,
                                                  AsyncSnapshot snapshot) {
                                                Image artwork;
                                                if (snapshot.hasData) {
                                                  artwork = snapshot.data;
                                                } else {
                                                  artwork = Image(
                                                      image: NetworkImage(
                                                    '$imgurlOfChannel',
                                                  ));
                                                }
                                                return Stack(children: [
                                                  InkWell(
                                                    onTap: () {
                                                      tapped.value = false;
                                                      print("tapppppppeddddd");
                                                      controllerStack
                                                          .animateToHeight(
                                                              state: PanelState
                                                                  .MIN,
                                                              duration:
                                                                  const Duration(
                                                                      milliseconds:
                                                                          30));
                                                    },
                                                    child: FittedBox(
                                                      child: Container(
                                                        height: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .height *
                                                            1,
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width *
                                                            1,
                                                        decoration:
                                                            const BoxDecoration(
                                                          color: Color.fromARGB(
                                                              255,
                                                              242,
                                                              242,
                                                              242),
                                                        ),
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            const Icon(
                                                              Icons
                                                                  .keyboard_double_arrow_down_rounded,
                                                              size: 45,
                                                              color: Colors
                                                                  .blueGrey,
                                                            ),
                                                            // Text(
                                                            //   "$nameOfChannel",
                                                            //   textAlign:
                                                            //       TextAlign.center,
                                                            //   style: const TextStyle(
                                                            //       fontSize: 25,
                                                            //       fontWeight:
                                                            //           FontWeight.bold,
                                                            //       color: Colors.white),
                                                            // ),
                                                            // Row(
                                                            //   mainAxisAlignment:
                                                            //       MainAxisAlignment
                                                            //           .spaceAround,
                                                            //   children: [
                                                            //     InkWell(
                                                            //       onTap: () {
                                                            //         // _dialogBuilder(context);
                                                            //         print("tapped");
                                                            //         tapped.value = true;
                                                            //       },
                                                            //       child: Column(
                                                            //         children: const [
                                                            //           Icon(
                                                            //             Icons
                                                            //                 .chat_sharp,
                                                            //             size: 35,
                                                            //             color: Colors
                                                            //                 .white,
                                                            //           ),
                                                            //           Text(
                                                            //             "Live Chat",
                                                            //             style: TextStyle(
                                                            //                 fontSize:
                                                            //                     18,
                                                            //                 fontWeight:
                                                            //                     FontWeight
                                                            //                         .bold,
                                                            //                 color: Colors
                                                            //                     .white),
                                                            //           )
                                                            //         ],
                                                            //       ),
                                                            //     ),
                                                            //     InkWell(
                                                            //       onTap: () {},
                                                            //       child: Column(
                                                            //         children: const [
                                                            //           Icon(
                                                            //             Icons
                                                            //                 .keyboard_voice_rounded,
                                                            //             size: 35,
                                                            //             color: Colors
                                                            //                 .white,
                                                            //           ),
                                                            //           Text(
                                                            //             "Detect Audio",
                                                            //             style: TextStyle(
                                                            //                 fontSize:
                                                            //                     18,
                                                            //                 fontWeight:
                                                            //                     FontWeight
                                                            //                         .bold,
                                                            //                 color: Colors
                                                            //                     .white),
                                                            //           )
                                                            //         ],
                                                            //       ),
                                                            //     ),
                                                            //   ],
                                                            // ),
                                                            Text(
                                                              '$nameOfChannel',
                                                              softWrap: false,
                                                              overflow:
                                                                  TextOverflow
                                                                      .fade,
                                                              style: const TextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontSize: 24),
                                                            ),

                                                            // Text(
                                                            //   '$nameOfChannel',
                                                            //   style: const TextStyle(
                                                            //       fontSize:
                                                            //           25,
                                                            //       fontWeight:
                                                            //           FontWeight
                                                            //               .bold,
                                                            //       color: Colors
                                                            //           .white),
                                                            // ),
                                                            Stack(
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                  child:
                                                                      Container(
                                                                    decoration:
                                                                        BoxDecoration(
                                                                            //color: Colors.yellow,
                                                                            borderRadius:
                                                                                BorderRadius.circular(20)),
                                                                    width: MediaQuery.of(context)
                                                                            .size
                                                                            .width *
                                                                        .8,
                                                                    height: MediaQuery.of(context)
                                                                            .size
                                                                            .width *
                                                                        .8,
                                                                    child:
                                                                        ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              15),
                                                                      child: status !=
                                                                              'Offline'
                                                                          ? Image(
                                                                              image:
                                                                                  NetworkImage(
                                                                              '$imgurlOfChannel',
                                                                            ))
                                                                          : const Image(
                                                                              image: AssetImage("assets/Raydeo.ONE512.png")),
                                                                    ),
                                                                  ),
                                                                ),
                                                                if (status !=
                                                                    'Offline')
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child:
                                                                        Container(
                                                                      decoration: BoxDecoration(
                                                                          color: const Color.fromARGB(
                                                                              255,
                                                                              242,
                                                                              242,
                                                                              242),
                                                                          borderRadius:
                                                                              BorderRadius.circular(20)),
                                                                      margin: EdgeInsets.only(
                                                                          left: MediaQuery.of(context).size.width *
                                                                              0.7,
                                                                          top: MediaQuery.of(context).size.width *
                                                                              0.01,
                                                                          right:
                                                                              MediaQuery.of(context).size.width * 0.11),
                                                                      child:
                                                                          Padding(
                                                                        padding:
                                                                            const EdgeInsets.all(2.0),
                                                                        child:
                                                                            Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          children: [
                                                                            const Icon(
                                                                              Icons.remove_red_eye,
                                                                              color: Colors.black,
                                                                            ),
                                                                            Obx(
                                                                              () => Text(
                                                                                " ${subcount}",
                                                                                style: const TextStyle(color: Colors.black),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                              ],
                                                            ),
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Colors
                                                                      .black,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              20)),
                                                              width: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  .85,
                                                              height: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .height *
                                                                  .15,
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // const Icon(
                                                                      //   Icons
                                                                      //       .skip_previous_rounded,
                                                                      //   color: Colors
                                                                      //       .white,
                                                                      //   size: 50,
                                                                      // ),
                                                                      InkWell(
                                                                        onTap:
                                                                            () {
                                                                          if (status !=
                                                                              'Offline') {
                                                                            setState(() {
                                                                              isPlaying ? _radioPlayer.pause() : _radioPlayer.play();
                                                                            });
                                                                          } else {
                                                                            _radioPlayer.stop();
                                                                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                                                behavior: SnackBarBehavior.floating,
                                                                                padding: const EdgeInsets.all(5),
                                                                                shape: const StadiumBorder(),
                                                                                backgroundColor: const Color.fromARGB(255, 242, 242, 242),
                                                                                duration: const Duration(seconds: 3),
                                                                                content: Row(
                                                                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                  children: const [
                                                                                    SizedBox(
                                                                                      width: 40,
                                                                                      height: 40,
                                                                                      child: Image(image: AssetImage("assets/Raydeo.ONE512.png")),
                                                                                    ),
                                                                                    SizedBox(
                                                                                      width: 250,
                                                                                      child: Text(
                                                                                        "Please check your internet connection and try again",
                                                                                        textAlign: TextAlign.center,
                                                                                        style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                                                                                      ),
                                                                                    )
                                                                                  ],
                                                                                )));
                                                                          }
                                                                        },
                                                                        child:
                                                                            Icon(
                                                                          isPlaying
                                                                              ? Icons.pause_rounded
                                                                              : Icons.play_arrow_rounded,
                                                                          color:
                                                                              Colors.white,
                                                                          size:
                                                                              50,
                                                                        ),
                                                                        //     Icon(
                                                                        //   (playing.value == true) ? Icons.pause : Icons.play_arrow_rounded,
                                                                        // color: Colors.white,
                                                                        // size: 50,
                                                                        // ),
                                                                      ),

                                                                      // const Icon(
                                                                      //   Icons
                                                                      //       .skip_next_rounded,
                                                                      //   color: Colors
                                                                      //       .white,
                                                                      //   size: 50,
                                                                      // ),
                                                                    ],
                                                                  ),
                                                                  // Slider(
                                                                  //   activeColor: Colors.white,
                                                                  //   min: 0,
                                                                  //   max: 1,
                                                                  //   onChanged: (double value) {
                                                                  //     _setVolumeValue = value;
                                                                  //     VolumeController()
                                                                  //         .setVolume(_setVolumeValue);
                                                                  //     setState(() {});
                                                                  //   },
                                                                  //   value: _setVolumeValue,
                                                                  // ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  tapped == true
                                                      ? Align(
                                                          alignment: Alignment
                                                              .bottomCenter,
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(5.0),
                                                            child: InkWell(
                                                              onTap: () {},
                                                              child: Container(
                                                                color: const Color
                                                                        .fromARGB(
                                                                    239,
                                                                    186,
                                                                    185,
                                                                    185),
                                                                height: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height *
                                                                    0.95,
                                                                width: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height *
                                                                    1,
                                                                child:
                                                                    const ChatPage(),
                                                              ),
                                                            ),
                                                          ),
                                                        )
                                                      : const SizedBox(
                                                          height: 0,
                                                        ),
                                                  // if (loader.value == true)
                                                  //   const Opacity(
                                                  //     opacity: 0.5,
                                                  //     child: ModalBarrier(
                                                  //         dismissible: false,
                                                  //         color: Colors.white),
                                                  //   ),
                                                  // if (loader.value == true)
                                                  //   Center(
                                                  //     child: Container(
                                                  //       width: 50,
                                                  //       height: 50,
                                                  //       decoration:
                                                  //           const BoxDecoration(
                                                  //               shape: BoxShape
                                                  //                   .circle),
                                                  //       child:
                                                  //           const CircularProgressIndicator(
                                                  //         color: Colors.blue,
                                                  //         strokeWidth: 5,
                                                  //       ),
                                                  //     ),
                                                  //   ),
                                                ]);
                                              })
                                          : FutureBuilder(
                                              future: _radioPlayer
                                                  .getArtworkImage(),
                                              builder: (BuildContext context,
                                                  AsyncSnapshot snapshot) {
                                                Image artwork;
                                                if (snapshot.hasData) {
                                                  artwork = snapshot.data;
                                                } else {
                                                  artwork = Image(
                                                      image: NetworkImage(
                                                    '$imgurlOfChannel',
                                                    // fit: BoxFit.cover,
                                                  ));
                                                }
                                                return Stack(children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 10.0,
                                                            left: 5,
                                                            top: 5,
                                                            bottom: 5),
                                                    child: Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              1,
                                                      decoration: const BoxDecoration(
                                                          color: Color.fromARGB(
                                                              255,
                                                              242,
                                                              242,
                                                              242),
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          15))),
                                                      // padding: const EdgeInsets.only(
                                                      //     bottom: 30),

                                                      // child: Text('$height, $percentage'),
                                                      child: Column(
                                                        children: [
                                                          const Icon(
                                                            Icons
                                                                .keyboard_double_arrow_up_rounded,
                                                            size: 30,
                                                            color:
                                                                Colors.blueGrey,
                                                          ),
                                                          Row(
                                                            children: [
                                                              const SizedBox(
                                                                width: 20,
                                                              ),
                                                              SizedBox(
                                                                height: 55,
                                                                width: 55,
                                                                // color: Colors.purple ,
                                                                child: status !=
                                                                        'Offline'
                                                                    ? Image(
                                                                        image:
                                                                            NetworkImage(
                                                                        '$imgurlOfChannel',
                                                                      ))
                                                                    : const Image(
                                                                        image: AssetImage(
                                                                            "assets/Raydeo.ONE512.png")),
                                                                // fit: BoxFit
                                                                // .fill,
                                                              ),
                                                              const SizedBox(
                                                                width: 10,
                                                              ),

                                                              Column(
                                                                children: [
                                                                  Text(
                                                                    '$nameOfChannel',
                                                                    style: const TextStyle(
                                                                        fontSize:
                                                                            16,
                                                                        color: Colors
                                                                            .black),
                                                                  ),
                                                                  // Text(
                                                                  //   metadata?[
                                                                  //           1] ??
                                                                  //       '',
                                                                  //   softWrap:
                                                                  //       false,
                                                                  //   overflow:
                                                                  //       TextOverflow
                                                                  //           .fade,
                                                                  //   style: const TextStyle(
                                                                  //   fontSize:
                                                                  //       16,
                                                                  //   color: Colors
                                                                  //       .white),
                                                                  // ),
                                                                ],
                                                              ),
                                                              // Text(
                                                              //   '$nameOfChannel',
                                                              // style: const TextStyle(
                                                              //     fontSize:
                                                              //         16,
                                                              //     color: Colors
                                                              //         .white),
                                                              // ),
                                                              const Spacer(),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .all(
                                                                        5.0),
                                                                child: InkWell(
                                                                  onTap: () {
                                                                    if (status !=
                                                                        'Offline') {
                                                                      miniplayerOpen
                                                                              .value =
                                                                          !miniplayerOpen
                                                                              .value;
                                                                      setState(
                                                                          () {
                                                                        print(
                                                                            "tapppingggggg$isPlaying");

                                                                        isPlaying
                                                                            ? _radioPlayer.pause()
                                                                            : _radioPlayer.play();
                                                                      });
                                                                    } else {
                                                                      _radioPlayer
                                                                          .stop();
                                                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                                          behavior: SnackBarBehavior.floating,
                                                                          padding: const EdgeInsets.all(5),
                                                                          shape: const StadiumBorder(),
                                                                          backgroundColor: const Color.fromARGB(255, 242, 242, 242),
                                                                          duration: const Duration(seconds: 3),
                                                                          content: Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceEvenly,
                                                                            children: const [
                                                                              SizedBox(
                                                                                width: 40,
                                                                                height: 40,
                                                                                child: Image(image: AssetImage("assets/Raydeo.ONE512.png")),
                                                                              ),
                                                                              SizedBox(
                                                                                width: 250,
                                                                                child: Text(
                                                                                  "Please check your internet connection and try again",
                                                                                  textAlign: TextAlign.center,
                                                                                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                                                                                ),
                                                                              )
                                                                            ],
                                                                          )));
                                                                    }
                                                                  },
                                                                  child: Icon(
                                                                    isPlaying
                                                                        ? Icons
                                                                            .pause_rounded
                                                                        : Icons
                                                                            .play_arrow_rounded,
                                                                    color: Colors
                                                                        .black,
                                                                    size: 45,
                                                                  ),
                                                                  //  Icon(
                                                                  //     (playing.value ==
                                                                  //             true)
                                                                  //         ? Icons
                                                                  //             .pause
                                                                  //         : Icons
                                                                  //             .play_arrow_rounded,
                                                                  //     color: Colors
                                                                  //         .white,
                                                                  //     size: 45,
                                                                  //   ),
                                                                ),
                                                              )
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  // if (loader.value == true)
                                                  //   const Opacity(
                                                  //     opacity: 0.5,
                                                  //     child: ModalBarrier(
                                                  //         dismissible: false,
                                                  //         color: Colors.white),
                                                  //   ),
                                                  // if (loader.value == true)
                                                  //   Center(
                                                  //     child: Container(
                                                  //       width: 50,
                                                  //       height: 50,
                                                  //       decoration:
                                                  //           const BoxDecoration(
                                                  //               shape: BoxShape
                                                  //                   .circle),
                                                  //       child:
                                                  //           const CircularProgressIndicator(
                                                  //         color: Colors.blue,
                                                  //         strokeWidth: 5,
                                                  //       ),
                                                  //     ),
                                                  //   ),
                                                ]);
                                              })),
                                ))
                        : const SizedBox(
                            height: 0,
                          ),
                  ],
                ),
              ),
            );
          }),
    );
  }

  addSourceFunction() {
    return widget.flutterRadioPlayers.addMediaSources(widget.frpSource);
  }

  updateCurrentStatus(status) {
    frpStatus = status;
  }

  ontapplay() {}

  void resetNowPlayingInfo() {
    currentPlaying.value = "";
  }

  ontapchannel() {
    setState(() {
      bgColor = Color((math.Random().nextDouble() * 0xFFFFFF).toInt())
          .withOpacity(1.0);
      print("startminiplayerOpen");
      widget.flutterRadioPlayers.addMediaSources(widget.frpSource);
      print("ontapchannelhomme${widget.frpSource.mediaSources!.length}");

      loader.value = true;
      Future.delayed(const Duration(seconds: 3), () {
        setState(() {
          loader.value = false;
        });
      });
    });
    controllerStack.animateToHeight(
        state: PanelState.MAX, duration: const Duration(milliseconds: 30));
  }
}
                    // if (miniplayerOpen.value != null)
                    //   Miniplayer(
                    //       controller: controllerStack,
                    //       backgroundColor: bgColor,
                    //       minHeight: 120,
                    //       maxHeight: MediaQuery.of(context).size.height * 1,
                    //       builder: (height, percentage) {
                    //         print("percentage:$percentage");
                    //         if (percentage > 0.2) {
                    //           return GestureDetector(
                    //             child: FittedBox(
                    //                 child: Container(
                    //               width: MediaQuery.of(context).size.width * 1,
                    //               height: MediaQuery.of(context).size.height * 1,
                    //               decoration: BoxDecoration(
                    //                 gradient: LinearGradient(
                    //                   begin: Alignment.bottomCenter,
                    //                   end: Alignment.topCenter,
                    //                   colors: [
                    //                     Colors.black.withOpacity(0.9),
                    //                     Colors.black.withOpacity(0.7),
                    //                     Colors.black.withOpacity(0.5),
                    //                     Colors.black.withOpacity(0.3),
                    //                   ],
                    //                 ),
                    //               ),
                    //               child: Center(
                    //                 child: musicplayer(
                    //                     widget.frpSource,
                    //                     flutterRadioPlayer,
                    //                     addSourceFunction,
                    //                     context,
                    //                     updateCurrentStatus,
                    //                     setState),
                    //               ),
                    //             )),
                    //           );
                    //         } else {
                    //           return minimusic(widget.frpSource, flutterRadioPlayer,
                    //               addSourceFunction, updateCurrentStatus, setState);
                    //         }
                    //       }),
                    // if (miniplayerOpen.value != null)
                    //   firsttime != true
                    //       ? Miniplayer(
                    //           elevation: 0,
                    //           controller: controllerStack,
                    //           backgroundColor: Colors.purple,
                    //           minHeight: 110,
                    //           maxHeight: MediaQuery.of(context).size.height * 1,
                    // builder: (height, percentage) {
                    //   print("percentage:$percentage");
                    //   if (percentage > 0.2) {
                    //     return GestureDetector(
                    //       // onTap: () {
                    //       //   print("sddddddddddddddddddd");
                    //       //   miniplayerOpen.value =
                    //       //       !miniplayerOpen.value;
                    // controllerStack.animateToHeight(
                    //     state: PanelState.MIN,
                    //     duration:
                    //         const Duration(milliseconds: 500));
                    //       //   minimusic(
                    //       //       widget.frpSource,
                    //       //       flutterRadioPlayer,
                    //       //       addSourceFunction,
                    //       //       updateCurrentStatus,
                    //       //       setState);
                    //       // },
                    //       // onVerticalDragDown: (DragDownDetails) {
                    //       //   miniplayerOpen.value =
                    //       //       !miniplayerOpen.value;
                    //       //   print("123456");
                    //       //   minimusic(
                    //       //       widget.frpSource,
                    //       //       flutterRadioPlayer,
                    //       //       addSourceFunction,
                    //       //       updateCurrentStatus,
                    //       //       setState);
                    //       // },
                    //       child: FittedBox(
                    //           child: Container(
                    //         width: MediaQuery.of(context).size.width * 1,
                    //         height: MediaQuery.of(context).size.height * 1,
                    //         decoration: BoxDecoration(
                    //           gradient: LinearGradient(
                    //             begin: Alignment.bottomCenter,
                    //             end: Alignment.topCenter,
                    //             colors: [
                    //               Colors.black.withOpacity(0.9),
                    //               Colors.black.withOpacity(0.7),
                    //               Colors.black.withOpacity(0.5),
                    //               Colors.black.withOpacity(0.3),
                    //             ],
                    //           ),
                    //         ),
                    //         child: Center(
                    //           child: musicplayer(
                    //               widget.frpSource,
                    //               widget.flutterRadioPlayers,
                    //               addSourceFunction,
                    //               context,
                    //               updateCurrentStatus,
                    //               setState),
                    //         ),
                    //       )),
                    //     );
                    //   } else {
                    //     return minimusic(
                    //         widget.frpSource,
                    //         widget.flutterRadioPlayers,
                    //         addSourceFunction,
                    //         updateCurrentStatus,
                    //         setState);
                    //   }
                    // }

                    //           //  ClipRect(
                    //           //   child: BackdropFilter(
                    //           //     filter: ui.ImageFilter.blur(
                    //           //       sigmaX: 20.0,
                    //           //       sigmaY: 20.0,
                    //           //     ),
                    //           //     child: (height != 110)
                    //           //         ? GestureDetector(
                    //           //             // onTap: () {
                    //           //             //   print("sddddddddddddddddddd");
                    //           //             //   miniplayerOpen.value =
                    //           //             //       !miniplayerOpen.value;
                    //           //             //   controllerStack.animateToHeight(
                    //           //             //       state: PanelState.MIN,
                    //           //             //       duration:
                    //           //             //           const Duration(milliseconds: 500));
                    //           //             //   minimusic(
                    //           //             //       widget.frpSource,
                    //           //             //       flutterRadioPlayer,
                    //           //             //       addSourceFunction,
                    //           //             //       updateCurrentStatus,
                    //           //             //       setState);
                    //           //             // },
                    //           //             // onVerticalDragDown: (DragDownDetails) {
                    //           //             //   miniplayerOpen.value =
                    //           //             //       !miniplayerOpen.value;
                    //           //             //   print("123456");
                    //           //             //   minimusic(
                    //           //             //       widget.frpSource,
                    //           //             //       flutterRadioPlayer,
                    //           //             //       addSourceFunction,
                    //           //             //       updateCurrentStatus,
                    //           //             //       setState);
                    //           //             // },
                    //           //             child: FittedBox(
                    //           //                 child: Container(
                    //           //               width:
                    //           //                   MediaQuery.of(context).size.width * 1,
                    //           //               height:
                    //           //                   MediaQuery.of(context).size.height * 1,
                    //           //               decoration: BoxDecoration(
                    //           //                 gradient: LinearGradient(
                    //           //                   begin: Alignment.bottomCenter,
                    //           //                   end: Alignment.topCenter,
                    //           //                   colors: [
                    //           //                     Colors.black.withOpacity(0.9),
                    //           //                     Colors.black.withOpacity(0.7),
                    //           //                     Colors.black.withOpacity(0.5),
                    //           //                     Colors.black.withOpacity(0.3),
                    //           //                   ],
                    //           //                 ),
                    //           //               ),
                    //           //               child: Center(
                    //           //                 child: musicplayer(
                    //           //                     widget.frpSource,
                    //           //                     widget.flutterRadioPlayers,
                    //           //                     addSourceFunction,
                    //           //                     context,
                    //           //                     updateCurrentStatus,
                    //           //                     setState),
                    //           //               ),
                    //           //             )),
                    //           //           )
                    //           //         : minimusic(
                    //           //             widget.frpSource,
                    //           //             widget.flutterRadioPlayers,
                    //           //             addSourceFunction,
                    //           //             updateCurrentStatus,
                    //           //             setState),
                    //           //   ),
                    //           // ),
                    //           )
                    //       : SizedBox(
                    //           height: 0,
                    //         ),
                    // if (loadingdata == true)
                    //   const Opacity(
                    //     opacity: 0.5,
                    //     child: ModalBarrier(
                    //         dismissible: false, color: Colors.white),
                    //   ),
                    // if (loadingdata == true)
                    //   Center(
                    //     child: Container(
                    //       width: 50,
                    //       height: 50,
                    //       decoration:
                    //           const BoxDecoration(shape: BoxShape.circle),
                    //       child: const CircularProgressIndicator(
                    //         color: Colors.blue,
                    //         strokeWidth: 5,
                    //       ),
                    //     ),
                    //   ),
    
  // startminiplayerOpen() async {
  //   playing.value = true;
  //   //print("playing..$urlOfChannel");
  //   widget.flutterRadioPlayers.playOrPause();
  //   resetNowPlayingInfo();
  // }

  // stopminiplayerOpen() {
  //   playing.value = false;
  //   widget.flutterRadioPlayers.stop();
  //   resetNowPlayingInfo();
  // }

 
  // getlocationname() async {
  //   final SharedPreferences sharedPreferences =
  //       await SharedPreferences.getInstance();
  //   List<Placemark> addresses = await placemarkFromCoordinates(2.11, 21.0);
  //   Placemark placeMark = addresses[0];
  //   String? name = placeMark.name;
  //   String? subLocality = placeMark.subLocality;
  //   String? locality = placeMark.locality;
  //   String? administrativeArea = placeMark.administrativeArea;
  //   String? postalCode = placeMark.postalCode;
  //   String? country = placeMark.country;
  //   String address =
  //       "${name}, ${subLocality}, ${locality}, ${administrativeArea} ${postalCode}, ${country}";
  //   print('MY ADDRESSSSSSSS${address}');
  //   print(addresses);

  //   var first = addresses.first;
  //   print("${first.name} : ${first..administrativeArea}");
  //   sharedPreferences.setString('address', subLocality!);
  // }

