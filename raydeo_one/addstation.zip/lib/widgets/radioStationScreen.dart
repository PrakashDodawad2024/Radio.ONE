import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:raydeo_one/main.dart';

class radioStationScreen extends StatefulWidget {
  const radioStationScreen({super.key});

  @override
  State<radioStationScreen> createState() => _radioStationScreenState();
}

class _radioStationScreenState extends State<radioStationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      appBar: AppBar(
          iconTheme: IconThemeData(color: maincolor),
          title: Text(
            "Submit a Radio Station",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: isDark == true ? Colors.white : Colors.black,
            ),
          )),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              RichText(
                text: TextSpan(
                  text: 'To submit a radio station to Radio.ONE ',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: isDark == true ? Colors.white : Colors.black,
                  ),
                  // style: DefaultTextStyle.of(context).style,
                  children: <TextSpan>[
                    TextSpan(
                        text: 'please fill in the station submission form.',
                        style: TextStyle(
                          color: maincolor,
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
