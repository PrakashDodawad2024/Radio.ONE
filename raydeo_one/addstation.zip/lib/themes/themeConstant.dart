import 'package:flutter/material.dart';

import '../main.dart';

ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: maincolor,
    backgroundColor: Colors.white,
    accentColor: Colors.grey.shade800,
    cardColor: Colors.white,
    canvasColor: Colors.white70,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.grey.shade100,
      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      floatingLabelBehavior: FloatingLabelBehavior.always,
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: maincolor.withOpacity(0.5))),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: maincolor.withOpacity(0.5))),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: maincolor.withOpacity(0.5))),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
          // backgroundColor:
          //     MaterialStateProperty.all<Color>(Color.fromARGB(255, 0, 0, 139)),
          shape: MaterialStateProperty.all<OutlinedBorder>(
              RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                  side: BorderSide(color: Colors.transparent)))),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      elevation: 0,
      backgroundColor: Colors.white,
      selectedItemColor: maincolor,
      unselectedItemColor: Colors.grey.shade600,
      showSelectedLabels: true,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
    ),
    appBarTheme: AppBarTheme(
      color: Colors.white,
      elevation: 0,
    ),
    tabBarTheme: TabBarTheme(
        indicatorColor: maincolor,
        indicatorSize: TabBarIndicatorSize.tab,
        // indicator: BoxDecoration(
        //     color: Colors.white,
        //     // borderRadius: BorderRadius.circular(10),
        //     border: Border(
        //         bottom: BorderSide(
        //       width: 2,
        //       color: Color.fromARGB(255, 0, 0, 139),
        //     ))),
        indicator: ShapeDecoration(
            color: maincolor,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10))),
        // dividerColor: Colors.red,
        // overlayColor: MaterialStateProperty.all<Color>(Colors.pink),
        unselectedLabelColor: Colors.grey.shade700,
        labelColor: Colors.white)
    // popupMenuTheme: PopupMenuThemeData(
    //   color:
    // )
    // textTheme: TextTheme(
    //     titleLarge:
    //         TextStyle(color: Colors.white, fontWeight: FontWeight.normal)),
    );

ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: maincolor,
    accentColor: Colors.white,
    backgroundColor: Colors.grey.shade900,
    cardColor: Colors.grey.shade700,
    canvasColor: Colors.grey.shade700,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.grey.shade700,
      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      floatingLabelBehavior: FloatingLabelBehavior.always,
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: maincolor.withOpacity(0.5))),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: maincolor.withOpacity(0.5))),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: maincolor.withOpacity(0.5))),
    ),
    // buttonColor: Color.fromARGB(255, 0, 0, 139),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(maincolor),
          shape: MaterialStateProperty.all<OutlinedBorder>(
              RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                  side: BorderSide(color: Colors.transparent)))),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      elevation: 0,
      backgroundColor: Colors.grey.shade900,
      selectedItemColor: Colors.white,
      unselectedItemColor: Colors.grey.shade600,
      showSelectedLabels: true,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
    ),
    appBarTheme: AppBarTheme(
      color: Colors.grey.shade900,
      elevation: 0,
    ),
    tabBarTheme: TabBarTheme(
      indicatorColor: maincolor,
      indicatorSize: TabBarIndicatorSize.tab,
      indicator: ShapeDecoration(
          color: Colors.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
      // BoxDecoration(
      //     color: Colors.white,
      //     border: Border(
      //         bottom: BorderSide(
      //       width: 2,
      //       color: Color.fromARGB(255, 0, 0, 139),
      //     ))),
      // dividerColor: Colors.red,
      // overlayColor: MaterialStateProperty.all<Color>(Colors.pink),
      unselectedLabelColor: Colors.white54,
      labelColor: maincolor,
    )

    // textTheme: TextTheme(
    //     titleLarge: TextStyle(
    //         color: Colors.grey.shade800, fontWeight: FontWeight.normal)),
    );

// textTheme.titleMedium --> button text
//textTheme.headlineSmall--> headline
//textTheme.labelLarge--> label
//textTheme.headlinesmall --> appbar title