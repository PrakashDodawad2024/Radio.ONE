import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:radio_player/radio_player.dart';
import 'homepage.dart';
import '../main.dart';
import '../mqtt/mqttregister.dart';

Widget MiniPlayerMusic(setState) {
  RadioPlayer _radioPlayer = RadioPlayer();

  return SafeArea(
    child: FutureBuilder(
        future: _radioPlayer.getArtworkImage(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          Image artwork;
          if (snapshot.hasData) {
            artwork = snapshot.data;
          } else {
            artwork = Image(
                image: NetworkImage(
              '$imgurlOfChannel',
              // fit: BoxFit.cover,
            ));
          }
          return Obx(
            () => Stack(children: [
              InkWell(
                onTap: () {
                  controllerStack.animateToHeight(
                      state: PanelState.MAX,
                      duration: const Duration(milliseconds: 30));
                },
                child: Container(
                  color: Colors.black12,
                  // color: Theme.of(context).backgroundColor,
                  child: Container(
                    width: MediaQuery.of(context).size.width * 1,
                    decoration: BoxDecoration(
                        color: isDark == true
                            ? Colors.grey.shade900
                            : Colors.white,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(15))),
                    // padding: const EdgeInsets.only(
                    //     bottom: 30),

                    // child: Text('$height, $percentage'),
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 5,
                        ),
                        InkWell(
                          onTap: () {
                            controllerStack.animateToHeight(
                                state: PanelState.MAX,
                                duration: const Duration(milliseconds: 30));
                          },
                          child: Icon(
                            Icons.keyboard_double_arrow_up_rounded,
                            size: 26,
                            color: maincolor,
                          ),
                        ),
                        Row(
                          children: [
                            const SizedBox(
                              width: 20,
                            ),
                            Container(
                              decoration: BoxDecoration(
                                  //color: Colors.yellow,
                                  borderRadius: BorderRadius.circular(10)),
                              width: MediaQuery.of(context).size.width * .12,
                              height: MediaQuery.of(context).size.width * .12,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: status != 'Offline'
                                    ? Image(
                                        image: NetworkImage(
                                          '$imgurlOfChannel',
                                        ),
                                        fit: BoxFit.fill,
                                      )
                                    : const Image(
                                        image: AssetImage(
                                            "assets/Raydeo.ONE512.png")),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '$nameOfChannel',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: isDark == true
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                ),
                                Text(
                                  '$catgOfChannel',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: isDark == true
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                ),
                              ],
                            ),
                            const Spacer(),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: InkWell(
                                  onTap: () {
                                    if (status != 'Offline') {
                                      miniplayerOpen.value =
                                          !miniplayerOpen.value;
                                      setState(() {
                                        print("tapppingggggg$isPlaying");

                                        isPlaying
                                            ? _radioPlayer.pause()
                                            : _radioPlayer.play();
                                        if (cancel.value == true) {
                                          cancel.value = !cancel.value;
                                        } else {
                                          cancel.value = true;
                                        }
                                      });
                                    } else {
                                      // _radioPlayer
                                      //     .stop();
                                      WidgetsBinding.instance
                                          .addPostFrameCallback((_) {
                                        // Add Your Code here.

                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                                behavior:
                                                    SnackBarBehavior.floating,
                                                padding:
                                                    const EdgeInsets.all(5),
                                                shape: const StadiumBorder(),
                                                backgroundColor:
                                                    const Color.fromARGB(
                                                        255, 242, 242, 242),
                                                duration:
                                                    const Duration(seconds: 3),
                                                content: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: const [
                                                    SizedBox(
                                                      width: 40,
                                                      height: 40,
                                                      child: Image(
                                                          image: AssetImage(
                                                              "assets/Raydeo.ONE512.png")),
                                                    ),
                                                    SizedBox(
                                                      width: 250,
                                                      child: Text(
                                                        "Please check your internet connection and try again",
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 14),
                                                      ),
                                                    ),
                                                  ],
                                                )));
                                      });
                                    }
                                  },
                                  child: Container(
                                    height: 50,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: maincolor),
                                    child: isPlaying
                                        ? loader.value == true
                                            ? Center(
                                                child:
                                                    CircularProgressIndicator(
                                                color: isDark == true
                                                    ? Colors.white
                                                    : Colors.black,
                                              ))
                                            : Icon(
                                                Icons.pause_rounded,
                                                color: isDark == true
                                                    ? Colors.white
                                                    : Colors.black,
                                                size: 35,
                                              )
                                        : Icon(
                                            Icons.play_arrow_rounded,
                                            color: isDark == true
                                                ? Colors.white
                                                : Colors.black,
                                            size: 35,
                                          ),
                                  )),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ]),
          );
        }),
  );
}
