import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:get/get.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:radio_player/radio_player.dart';
import 'package:share_plus/share_plus.dart';
import 'package:volume_controller/volume_controller.dart';
import 'homepage.dart';
import '../main.dart';
import '../mqtt/mqttconnection.dart';
import '../mqtt/mqttregister.dart';
import '../widgets/chatpage.dart';

Widget MusicPlayer(appBarHeight, setState) {
  RadioPlayer _radioPlayer = RadioPlayer();

  return SafeArea(
    child: FutureBuilder(
        future: _radioPlayer.getArtworkImage(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          Image artwork;
          if (snapshot.hasData) {
            artwork = snapshot.data;
            print("hbshscccs$artwork${snapshot.data}");
          } else {
            print("hfnfkne");
            artwork = Image(
                image: NetworkImage(
              '$imgurlOfChannel',
            ));
          }
          print("hbshscccs2$metadata");
          return Obx(
            () => Stack(children: [
              InkWell(
                onTap: () {},
                child: Container(
                  height: MediaQuery.of(context).size.height -
                      (appBarHeight + MediaQuery.of(context).viewPadding.top),
                  width: MediaQuery.of(context).size.width * 1,
                  decoration: BoxDecoration(
                    color: isDark == true ? Colors.grey.shade900 : Colors.white,
                    // color: Theme.of(context).backgroundColor,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              tapped.value = false;
                              displayfavlist =
                                  favouritelist!.get("favlist") ?? [];
                              controllerStack.animateToHeight(
                                  state: PanelState.MIN,
                                  duration: const Duration(milliseconds: 30));
                              print("tapppppppeddddd");
                            },
                            child: Icon(
                              Icons.keyboard_double_arrow_down_rounded,
                              size: 35,
                              color: maincolor,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.015,
                      ),
                      // Text(
                      //   "$nameOfChannel",
                      //   textAlign:
                      //       TextAlign.center,
                      //   style: const TextStyle(
                      //       fontSize: 25,
                      //       fontWeight:
                      //           FontWeight.bold,
                      //       color: Colors.white),
                      // ),
                      // Row(
                      //   mainAxisAlignment:
                      //       MainAxisAlignment
                      //           .spaceAround,
                      //   children: [
                      //     InkWell(
                      //       onTap: () {
                      //         // _dialogBuilder(context);
                      //         print("tapped");
                      //         tapped.value = true;
                      //       },
                      //       child: Column(
                      //         children: const [
                      //           Icon(
                      //             Icons
                      //                 .chat_sharp,
                      //             size: 35,
                      //             color: Colors
                      //                 .white,
                      //           ),
                      //           Text(
                      //             "Live Chat",
                      //             style: TextStyle(
                      //                 fontSize:
                      //                     18,
                      //                 fontWeight:
                      //                     FontWeight
                      //                         .bold,
                      //                 color: Colors
                      //                     .white),
                      //           )
                      //         ],
                      //       ),
                      //     ),
                      //     InkWell(
                      //       onTap: () {},
                      //       child: Column(
                      //         children: const [
                      //           Icon(
                      //             Icons
                      //                 .keyboard_voice_rounded,
                      //             size: 35,
                      //             color: Colors
                      //                 .white,
                      //           ),
                      //           Text(
                      //             "Detect Audio",
                      //             style: TextStyle(
                      //                 fontSize:
                      //                     18,
                      //                 fontWeight:
                      //                     FontWeight
                      //                         .bold,
                      //                 color: Colors
                      //                     .white),
                      //           )
                      //         ],
                      //       ),
                      //     ),
                      //   ],
                      // ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              Text(
                                '$catgOfChannel',
                                softWrap: false,
                                overflow: TextOverflow.fade,
                                style: TextStyle(
                                    color: isDark == true
                                        ? Colors.white
                                        : Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16),
                              ),
                              Text(
                                '$nameOfChannel',
                                softWrap: false,
                                overflow: TextOverflow.fade,
                                style: TextStyle(
                                    color: isDark == true
                                        ? Colors.white
                                        : Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 24),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              if (status != 'Offline')
                                Container(
                                  decoration: BoxDecoration(
                                      // color: isDark == true
                                      //     ? Colors.white
                                      //     : Colors.black,
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Padding(
                                    padding: const EdgeInsets.all(2.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.remove_red_eye,
                                          color: isDark == true
                                              ? Colors.white
                                              : Colors.black,
                                        ),
                                        Obx(
                                          () => Text(
                                            " ${subcount}",
                                            style: TextStyle(
                                                color: isDark == true
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              metadata != []
                                  ? Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      color: Colors.grey.shade300,
                                      elevation: 0,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.8,
                                        height:
                                            MediaQuery.of(context).size.height *
                                                0.085,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.7,
                                                  child: Text(
                                                    metadata != []
                                                        ? metadata![0]
                                                                .isNotEmpty
                                                            ? metadata![0].contains(
                                                                    "errorCode")
                                                                ? "No Data Found"
                                                                : '${metadata![0]}'
                                                            : "No Data Found"
                                                        : "No Data Found",
                                                    softWrap: false,
                                                    overflow: TextOverflow.fade,
                                                    style: TextStyle(
                                                        color: isDark == true
                                                            ? Colors.white
                                                            : Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 12),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                Container(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.7,
                                                  child: Text(
                                                    metadata != []
                                                        ? metadata![1]
                                                                .isNotEmpty
                                                            ? metadata![1].contains(
                                                                    "errorCode")
                                                                ? ""
                                                                : '${metadata![1]}'
                                                            : ""
                                                        : "",
                                                    softWrap: false,
                                                    overflow: TextOverflow.fade,
                                                    style: TextStyle(
                                                        color: isDark == true
                                                            ? Colors.white
                                                            : Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 12),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            metadata != [] ||
                                                    metadata![1].isNotEmpty ||
                                                    !metadata![1].contains(
                                                        "errorCode") ||
                                                    !metadata![0]
                                                        .contains("errorCode")
                                                ? InkWell(
                                                    onTap: () {
                                                      Clipboard.setData(
                                                          ClipboardData(
                                                              text:
                                                                  '${metadata![0]}${metadata![1]}'));
                                                      ScaffoldMessenger
                                                              .of(context)
                                                          .showSnackBar(SnackBar(
                                                              backgroundColor:
                                                                  maincolor,
                                                              behavior:
                                                                  SnackBarBehavior
                                                                      .floating,
                                                              shape:
                                                                  StadiumBorder(),
                                                              duration:
                                                                  const Duration(
                                                                      seconds:
                                                                          3),
                                                              content: const Text(
                                                                  "Copied Succesfully")));
                                                    },
                                                    child: Icon(
                                                      Icons.copy_outlined,
                                                      color: maincolor,
                                                    ))
                                                : const SizedBox(
                                                    height: 0,
                                                  )
                                          ],
                                        ),
                                      ),
                                    )
                                  : const SizedBox(
                                      height: 0,
                                    )
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.005,
                      ),

                      Stack(
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              decoration: BoxDecoration(
                                  //color: Colors.yellow,
                                  borderRadius: BorderRadius.circular(20)),
                              width: MediaQuery.of(context).size.width * .8,
                              height: MediaQuery.of(context).size.width * .7,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15),
                                child: status != 'Offline'
                                    ? Image(
                                        image: NetworkImage(
                                          '$imgurlOfChannel',
                                        ),
                                        fit: BoxFit.fill,
                                      )
                                    : const Image(
                                        image: AssetImage(
                                            "assets/Raydeo.ONE512.png")),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.015,
                      ),

                      Container(
                        decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20)),
                        width: MediaQuery.of(context).size.width * .8,
                        height: MediaQuery.of(context).size.height * .18,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                IconButton(
                                    onPressed: () {
                                      Share.share(
                                        "Hi, I am listening to radio using the Radio.ONE application. Download and enjoy the application https://play.google.com/store/apps/details?id=com.mobil80.radio.ONE",
                                      );
                                    },
                                    icon: Icon(
                                      Icons.share_rounded,
                                      color: maincolor,
                                      size: 35,
                                    )),

                                InkWell(
                                    onTap: () {
                                      print("qwerty");
                                      if (status != 'Offline') {
                                        setState(() {
                                          isPlaying
                                              ? _radioPlayer.pause()
                                              : _radioPlayer.play();
                                          if (cancel.value == true) {
                                            cancel.value = !cancel.value;
                                          } else {
                                            cancel.value = true;
                                          }
                                        });
                                      } else {
                                        WidgetsBinding.instance
                                            .addPostFrameCallback((_) {
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(SnackBar(
                                                  behavior:
                                                      SnackBarBehavior.floating,
                                                  padding:
                                                      const EdgeInsets.all(5),
                                                  shape: const StadiumBorder(),
                                                  backgroundColor:
                                                      const Color.fromARGB(
                                                          255, 242, 242, 242),
                                                  duration: const Duration(
                                                      seconds: 3),
                                                  content: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: const [
                                                      SizedBox(
                                                        width: 40,
                                                        height: 40,
                                                        child: Image(
                                                            image: AssetImage(
                                                                "assets/Raydeo.ONE512.png")),
                                                      ),
                                                      SizedBox(
                                                        width: 250,
                                                        child: Text(
                                                          "Please check your internet connection and try again",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: 14),
                                                        ),
                                                      )
                                                    ],
                                                  )));
                                        });
                                      }
                                    },
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: maincolor),
                                      child: isPlaying
                                          ? loader.value == true
                                              ? Center(
                                                  child:
                                                      CircularProgressIndicator(
                                                  color: isDark == true
                                                      ? Colors.white
                                                      : Colors.black,
                                                ))
                                              : Icon(
                                                  Icons.pause_rounded,
                                                  color: isDark == true
                                                      ? Colors.white
                                                      : Colors.black,
                                                  size: 35,
                                                )
                                          : Icon(
                                              Icons.play_arrow_rounded,
                                              color: isDark == true
                                                  ? Colors.white
                                                  : Colors.black,
                                              size: 35,
                                            ),
                                    )),
                                // IconButton(
                                //   onPressed: () async {},
                                //   icon: Icon(
                                //     Icons.skip_next_rounded,
                                //     color: maincolor,
                                //     size: 35,
                                //   ),
                                // ),
                                IconButton(
                                    onPressed: () async {
                                      if (displayfavlist.isNotEmpty) {
                                        if (addFavourite == true) {
                                          favlist = favouritelist!.get(
                                                "favlist",
                                              ) ??
                                              [];
                                          print(
                                              "favlistsecondlist${favlist.length}");

                                          for (int x = 0;
                                              x < favlist.length;
                                              x++) {
                                            print(
                                                "channel_name : ${favlist[x]["channel_name"]}");
                                            if (favlist[x]["channel_name"]
                                                    .toString() ==
                                                "$nameOfChannel") {
                                              setState(() {
                                                print(
                                                    "matched  ##################");
                                                favlist.removeAt(x);
                                                favouritelist!
                                                    .put("favlist", []);
                                                favouritelist!
                                                    .put("favlist", favlist);
                                                addFavourite = !addFavourite;
                                                displayfavlist = favouritelist!
                                                        .get("favlist") ??
                                                    [];
                                              });
                                            }
                                          }
                                        } else {
                                          setState(() {
                                            favlist = favouritelist!.get(
                                                  "favlist",
                                                ) ??
                                                [];
                                            favouritelist!.put("favlist", []);

                                            favlist.add(favdata);
                                            favouritelist!
                                                .put("favlist", favlist);
                                            addFavourite = !addFavourite;
                                            displayfavlist =
                                                favouritelist!.get("favlist") ??
                                                    [];
                                          });
                                        }
                                      } else {
                                        setState(() {
                                          favlist = favouritelist!.get(
                                                "favlist",
                                              ) ??
                                              [];
                                          favouritelist!.put("favlist", []);

                                          favlist.add(favdata);
                                          favouritelist!
                                              .put("favlist", favlist);
                                          addFavourite = !addFavourite;
                                        });
                                        setState(() {
                                          displayfavlist =
                                              favouritelist!.get("favlist") ??
                                                  [];
                                        });

                                        // print("favlistfavlist${favouritelist!.values}");
                                      }
                                    },
                                    icon: addFavourite == true
                                        ? const Icon(
                                            Icons.favorite,
                                            color: Colors.red,
                                            size: 35,
                                          )
                                        : Icon(
                                            Icons.favorite_border_rounded,
                                            color: maincolor,
                                            size: 35,
                                          )),
                              ],
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width * .8,
                              height: MediaQuery.of(context).size.height * .05,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(
                                    Icons.volume_down_rounded,
                                    color: Colors.grey,
                                  ),
                                  Container(
                                    width:
                                        MediaQuery.of(context).size.width * .64,
                                    child: Slider(
                                      activeColor: maincolor,
                                      inactiveColor: Colors.blueGrey,
                                      min: 0,
                                      max: 1,
                                      onChanged: (double value) {
                                        // makemute.value = !makemute.value;
                                        setState(() {
                                          setVolumeValue = value;
                                          VolumeController()
                                              .setVolume(setVolumeValue);
                                        });
                                      },
                                      value: setVolumeValue,
                                    ),
                                  ),
                                  InkWell(
                                      onTap: () {
                                        // makemute.value = !makemute.value;
                                        // makemute.value == true
                                        //     ? VolumeController().muteVolume()
                                        //     : VolumeController()
                                        //         .setVolume(setVolumeValue);
                                      },
                                      child:
                                          //  makemute.value != true
                                          //     ?
                                          const Icon(
                                        Icons.volume_up_rounded,
                                        color: Colors.grey,
                                      )
                                      // : const Icon(
                                      //     Icons.volume_off_rounded,
                                      //     color: Colors.grey,
                                      //   )
                                      ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      loader.value == true
                          ? Text("Loading Please wait .....",
                              style: Theme.of(context).textTheme.bodyLarge)
                          : const SizedBox(
                              height: 0,
                            ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.015,
                      ),
                    ],
                  ),
                ),
              ),
              tapped == true
                  ? Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: InkWell(
                          onTap: () {},
                          child: Container(
                            color: const Color.fromARGB(239, 186, 185, 185),
                            height: MediaQuery.of(context).size.height * 0.95,
                            width: MediaQuery.of(context).size.height * 1,
                            child: const ChatPage(),
                          ),
                        ),
                      ),
                    )
                  : const SizedBox(
                      height: 0,
                    ),
            ]),
          );
        }),
  );
}
