import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:double_back_to_close_app/double_back_to_close_app.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:radio_player/radio_player.dart';
import 'package:raydeo_one/widgets/connectivity.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uni_links/uni_links.dart';
import '../main.dart';
import '../mqtt/mqttconnection.dart';
import '../mqtt/mqttregister.dart';

import 'minimusic.dart';
import 'musicplayer.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:expansion_widget/expansion_widget.dart';
import '../profilepages/profile.dart';
import '../widgets/viewmore.dart';
import 'search.dart';
import 'package:nowplaying/nowplaying.dart';

final controllerStack = MiniplayerController();
RxBool miniplayerOpen = false.obs;
Map favdata = {};
int currentindex = 0;
Map surce = {ConnectivityResult.none: false};
MyConnectivity _connectivity = MyConnectivity.instance;
String status = "Mobile: Online";
RxBool miniplayerOpened = false.obs;
RadioPlayer _radioPlayer = RadioPlayer();
bool isPlaying = false;
int selected = 0;
List<String>? metadata;
RxBool playing = false.obs;
List closeRest = [0];
Uri? _initialURI;
Uri? _currentURI;
Object? _err;
StreamSubscription? _streamSubscription;

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    super.initState();
    _incomingLinkHandler();

    displayfavlist = favouritelist!.get("favlist") ?? [];
    print("categories:$categorylist");
    _connectivity.initialise();
    _connectivity.myStream.listen((source) {
      if (!mounted) {
        return;
      } else {
        setState(() => surce = source);
      }
    });
  }

  void _incomingLinkHandler() {
    // 1
    if (!kIsWeb) {
      // 2
      _streamSubscription = uriLinkStream.listen((Uri? uri) {
        if (!mounted) {
          return;
        }
        debugPrint('Received URI: $uri');
        setState(() {
          _currentURI = uri;
          _err = null;
        });
        // 3
      }, onError: (Object err) {
        if (!mounted) {
          return;
        }
        debugPrint('Error occurred: $err');
        setState(() {
          _currentURI = null;
          if (err is FormatException) {
            _err = err;
          } else {
            _err = null;
          }
        });
      });
    }
  }

  @override
  void dispose() {
    _streamSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    PreferredSize appBar = PreferredSize(
      preferredSize: const Size.fromHeight(60.0),
      child: AppBar(
        elevation: 0,
        backgroundColor: Theme.of(context).backgroundColor,
        leading: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const Text('  '),
            IconButton(
              onPressed: () {
                showSearch(
                    context: context,
                    delegate: CustomSearchDelegate(setState: setState));
              },
              icon: Icon(
                Icons.search,
                color: maincolor,
                size: 28,
              ),
            ),
          ],
        ),
        title: Text(
          'Radio.ONE',
          textAlign: TextAlign.start,
          style: Theme.of(context).textTheme.titleLarge,
        ),
        centerTitle: true,
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const Profile(),
                  ));
                },
                icon: Icon(
                  Icons.account_circle_rounded,
                  color: maincolor,
                  size: 40,
                ),
              ),
              const Text('    ')
            ],
          ),
        ],
      ),
    );
    final appBarHeight = appBar.preferredSize.height;

    print('status**********:${status}');
    switch (surce.keys.toList()[0]) {
      case ConnectivityResult.none:
        status = "Offline";

        isDataConnected = false;
        _radioPlayer.stop();

        break;
      case ConnectivityResult.mobile:
        status = "Mobile: Online";

        isDataConnected = true;

        break;
      case ConnectivityResult.wifi:
        status = "WiFi: Online";

        isDataConnected = true;

        break;
      case ConnectivityResult.ethernet:
        status = "Ethernet: Online";

        isDataConnected = true;

        break;
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: appBar,
        resizeToAvoidBottomInset: false,
        body: ValueListenableBuilder(
            valueListenable: allmessages!.listenable(),
            builder: (context, value, child) {
              final allresponse = allmessages!.get("allmessages");
              print("allresponvvbvbse$allresponse");
              if (allresponse != null) {
                final decodeddata = jsonDecode(allresponse["channel_message"]);
                final alldecodeddata = jsonDecode(decodeddata["description"]);
                // print("alldecodeddata${alldecodeddata}");
                alldata = alldecodeddata;
                print("alldaddddta$alldata");
                // if (alldata.length != 0) {
                print("segregating alldata");
                for (int i = 0; i < alldata.length; i++) {
                  if (!categorylist.contains(alldata[i]["channel_category"])) {
                    categorylist.add(alldata[i]["channel_category"]);
                    print("categorylist$categorylist");
                  }
                  homepageloader.value = false;
                  if (!titlelist.contains(alldata[i]["channel_name"]) ||
                      !titlelist.contains(alldata[i]["channel_category"])) {
                    titlelist.add(alldata[i]["channel_name"].toString());
                    titlelist.add(alldata[i]["channel_category"].toString());
                    print("titlelist$titlelist");
                  }
                }
              }

              return DoubleBackToCloseApp(
                snackBar: const SnackBar(
                  duration: Duration(seconds: 5),
                  dismissDirection: DismissDirection.up,
                  shape: StadiumBorder(),
                  showCloseIcon: true,
                  backgroundColor: Colors.red,
                  content: Text('Tap back again to leave'),
                ),
                child: homepageloader.value == true
                    ? Scaffold(
                        body: Center(
                          child: CircularProgressIndicator(
                            color: maincolor,
                          ),
                        ),
                      )
                    : Stack(
                        children: <Widget>[
                          Container(
                            height: MediaQuery.of(context).size.height * 1,
                            padding: const EdgeInsets.only(top: 5),
                            color: Colors.grey.shade200,
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      for (int j = 0;
                                          j < categorylist.length;
                                          j++)
                                        SizedBox(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                1,
                                            child: (categorylist.isNotEmpty)
                                                ? Card(
                                                    color: const Color.fromARGB(
                                                        255, 242, 242, 242),
                                                    elevation: 0,
                                                    child: getSortedChannels(j),
                                                  )
                                                : const Center(
                                                    child:
                                                        CircularProgressIndicator(),
                                                  )),
                                      miniplayerOpen.value != null
                                          ? SizedBox(
                                              height: MediaQuery.of(context)
                                                      .size
                                                      .height *
                                                  0.115,
                                            )
                                          : const SizedBox(
                                              height: 0,
                                            )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          openmini == true
                              ? Miniplayer(
                                  controller: controllerStack,
                                  backgroundColor: maincolor,
                                  minHeight: 100,
                                  maxHeight:
                                      MediaQuery.of(context).size.height * 1,
                                  builder: (height, percentage) {
                                    if (height <= 100) {
                                      displayfavlist =
                                          favouritelist!.get("favlist") ?? [];
                                      miniplay.value = true;
                                      print("123456smallll");
                                    } else if (height > 100) {
                                      miniplay.value = false;
                                      print("123456largeeee");
                                    }
                                    return ClipRect(
                                      child: BackdropFilter(
                                          filter: ui.ImageFilter.blur(
                                              sigmaX: 100.0,
                                              sigmaY: 100.0,
                                              tileMode: TileMode.mirror),
                                          child: (height != 100)
                                              ? MusicPlayer(
                                                  appBarHeight, setState)
                                              : MiniPlayerMusic(setState)),
                                    );
                                  })
                              : const SizedBox(
                                  height: 0,
                                ),
                        ],
                      ),
              );
            }),
      ),
    );
  }

  getSortedChannels(j) {
    try {
      bool checkPieOpenClose = (closeRest.contains(j)) ? true : false;
      return ExpansionWidget(
        onSaveState: (isExpanded) => checkPieOpenClose = isExpanded,
        onExpansionChanged: (value) {
          if (value == true) {
            setState(() {
              closeRest = [];
              closeRest.add(j);
            });
          }
        },
        onRestoreState: () => checkPieOpenClose,
        maintainState: true,
        duration: const Duration(milliseconds: 350),
        // initiallyExpanded:
        //     (jsonDecode(widget.decodedItem['description']).length == 1)
        //         ? true
        //         : false,
        titleBuilder:
            (animationValue, easeInValue, isExpanded, toggleFunction) {
          return GestureDetector(
            onTap: () {
              toggleFunction(animated: true);
              catgChannel.value = categorylist[j];
              print("${categorylist[j]} catgChannel$catgChannel");
              viewmorelist.value = [];
              for (int k = 0; k < alldata.length; k++) {
                if (alldata[k]['channel_category'].contains(catgChannel)) {
                  viewmorelist.add(alldata[k]);
                }
                print("catgChannel$viewmorelist");
              }
            },
            child: Container(
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(
                  Radius.circular(5),
                ),
                color: Theme.of(context).backgroundColor,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.925,
                    alignment: Alignment.centerLeft,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "${categorylist[j]}",
                          textAlign: TextAlign.start,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        categorylist[j] == "Favourites"
                            ? isExpanded == true && displayfavlist.length > 10
                                ? SizedBox(
                                    height: MediaQuery.of(context).size.height *
                                        0.035,
                                    width: MediaQuery.of(context).size.height *
                                        0.125,
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        elevation: 0,
                                        backgroundColor:
                                            Theme.of(context).backgroundColor,
                                      ),
                                      onPressed: () {
                                        Navigator.of(context)
                                            .push(MaterialPageRoute(
                                          builder: (context) => viewMore(
                                              context, setState, catgChannel),
                                        ));
                                      },
                                      child: Text(
                                        "View All",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            color: maincolor),
                                      ),
                                    ),
                                  )
                                : const SizedBox(
                                    height: 0,
                                  )
                            : isExpanded == true && viewmorelist.length > 10
                                ? SizedBox(
                                    height: MediaQuery.of(context).size.height *
                                        0.035,
                                    width: MediaQuery.of(context).size.height *
                                        0.125,
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        elevation: 0,
                                        backgroundColor:
                                            Theme.of(context).backgroundColor,
                                      ),
                                      onPressed: () {
                                        Navigator.of(context)
                                            .push(MaterialPageRoute(
                                          builder: (context) => viewMore(
                                              context, setState, catgChannel),
                                        ));
                                      },
                                      child: Text(
                                        "View All",
                                        textAlign: TextAlign.start,
                                        // style:
                                        //     Theme.of(context).textTheme.titleSmall,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            color: maincolor),
                                      ),
                                    ),
                                  )
                                : const SizedBox(
                                    height: 0,
                                  )
                      ],
                    ),
                  ),
                  // Transform.rotate(
                  //   angle: math.pi * animationValue + 1.55,
                  //   alignment: Alignment.center,
                  //   child: const Icon(
                  //     Icons.arrow_forward_ios,
                  //     size: 18,
                  //     color: Colors.black,
                  //   ),
                  // ),
                ],
              ),
            ),
          );
        },
        content: categorylist[j] == "Favourites"
            ? displayfavlist.isNotEmpty
                ? Container(
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(
                        Radius.circular(5),
                      ),
                      color:
                          isDark == true ? Colors.grey.shade900 : Colors.white,
                    ),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                    child: Column(
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 1,
                          height: MediaQuery.of(context).size.height * 0.22,
                          child: ListView.builder(
                            padding: const EdgeInsets.all(0),
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                            itemCount: displayfavlist.length,
                            itemBuilder: (context, index) {
                              return Container(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        if (status != 'Offline') {
                                          controllerStack.animateToHeight(
                                              state: PanelState.MAX,
                                              duration: const Duration(
                                                  milliseconds: 30));
                                          cancel.value = false;
                                          if (idOfChannel.isNotEmpty) {
                                            await MQTTConnections()
                                                .unsubscribeToChannel(
                                                    "$idOfChannel");
                                          }
                                          _radioPlayer.stop();

                                          loader.value = true;
                                          Future.delayed(
                                              const Duration(seconds: 5), () {
                                            setState(() {
                                              loader.value = false;
                                            });
                                          });
                                          print("currentindx:$currentindx");
                                          favdata = displayfavlist[index];

                                          nameOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_name"];
                                          descOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_description"];
                                          catgOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_category"];
                                          idOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_id"];
                                          urlOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_stream_url"];
                                          imgurlOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_image_url"];
                                          setState(() {
                                            openmini = true;
                                          });
                                          subcount = 1.obs;

                                          // startminiplayerOpen(urlOfChannel);
                                          Future.delayed(
                                              const Duration(seconds: 2));
                                          var qwe = await MQTTConnections()
                                              .MQTTSubscribeMethod(
                                                  "$idOfChannel");

                                          if (displayfavlist.isNotEmpty) {
                                            for (int i = 0;
                                                i < displayfavlist.length;
                                                i++) {
                                              if (displayfavlist[i]
                                                      ["channel_id"]
                                                  .toString()
                                                  .contains(idOfChannel)) {
                                                setState(() {
                                                  addFavourite = true;
                                                });
                                                break;
                                              } else {
                                                setState(() {
                                                  addFavourite = false;
                                                });
                                              }
                                            }
                                          }
                                          print("spdata:${idOfChannel}");
                                          print("favdfgdcg:${displayfavlist}");
                                          Future.delayed(
                                              const Duration(seconds: 2));

                                          final SharedPreferences
                                              sharedPreferences =
                                              await SharedPreferences
                                                  .getInstance();

                                          print(
                                              "spdata:${sharedPreferences.getString('device_id')} ");

                                          Future.delayed(
                                              const Duration(seconds: 5),
                                              () {});
                                          var resp = await MQTTConnections()
                                              .getChannelDetails(
                                                  "$idOfChannel");
                                          print(
                                              "spdata:${resp["total_number_of_subscribers"]}name${resp["channel_id"]}");
                                          // subcount.value =
                                          //     resp["total_number_of_subscribers"];
                                          print("tacsvvdcvaadcad");
                                          await _radioPlayer.setChannel(
                                            title: '$nameOfChannel',
                                            url: '$urlOfChannel',
                                            imagePath: '$imgurlOfChannel',
                                          );
                                          Future.delayed(
                                              const Duration(milliseconds: 10),
                                              () {
                                            _radioPlayer.play();
                                          });

                                          _radioPlayer.stateStream
                                              .listen((value) {
                                            print("sdgxcfhjbkn:$value");
                                            setState(() {
                                              isPlaying = value;
                                            });
                                          });

                                          _radioPlayer.metadataStream
                                              .listen((value) {
                                            print("hbshscccs$metadata");
                                            setState(() {
                                              metadata = value;
                                            });
                                            print("hbshscccs$metadata");
                                          });

                                          print(
                                              "nameOfChannel:${nameOfChannel}");
                                          print("idOfChannel:${idOfChannel}");
                                          print(
                                              "descOfChannel:${descOfChannel}");
                                        } else {
                                          WidgetsBinding.instance
                                              .addPostFrameCallback((_) {
                                            // Add Your Code here.

                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(SnackBar(
                                                    behavior: SnackBarBehavior
                                                        .floating,
                                                    padding:
                                                        const EdgeInsets.all(5),
                                                    shape:
                                                        const StadiumBorder(),
                                                    backgroundColor: maincolor,
                                                    duration: const Duration(
                                                        seconds: 3),
                                                    content: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: [
                                                        const SizedBox(
                                                          width: 40,
                                                          height: 40,
                                                          child: Image(
                                                              image: AssetImage(
                                                                  "assets/Raydeo.ONE512.png")),
                                                        ),
                                                        SizedBox(
                                                          width: 250,
                                                          child: Text(
                                                            "Please check your internet connection and try again",
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: Theme.of(
                                                                    context)
                                                                .textTheme
                                                                .bodyLarge,
                                                          ),
                                                        )
                                                      ],
                                                    )));
                                          });
                                        }
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                .3,
                                        height:
                                            MediaQuery.of(context).size.height *
                                                .129,
                                        padding: const EdgeInsets.all(0),
                                        alignment: Alignment.center,
                                        decoration: const BoxDecoration(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(15))),
                                        child: Card(
                                          elevation: 5,
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(15))),
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(12.0),
                                            child: status != 'Offline'
                                                ? Image.network(
                                                    "${displayfavlist[index]['channel_image_url']}")
                                                : const Image(
                                                    image: AssetImage(
                                                        "assets/Raydeo.ONE512.png")),
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          .26,
                                      child: Column(
                                        children: [
                                          Text(
                                            "${displayfavlist[index]['channel_name']}",
                                            textAlign: TextAlign.center,
                                            // style: Theme.of(context)
                                            //     .textTheme
                                            //     .bodyMedium,
                                            style: TextStyle(
                                                color: isDark == true
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 12),
                                          ),
                                          Text(
                                            "${displayfavlist[index]['channel_category']}",
                                            textAlign: TextAlign.center,
                                            // style: Theme.of(context)
                                            //     .textTheme
                                            //     .bodyMedium,
                                            style: TextStyle(
                                                color: isDark == true
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  )
                : Container(
                    color: Theme.of(context).backgroundColor,
                    height: MediaQuery.of(context).size.height * 0.22,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.favorite_rounded,
                            color: maincolor,
                            size: 45,
                          ),
                          Text(
                            "Your favourite channels will appear here",
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.labelLarge,
                            // style: TextStyle(
                            //     fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  )
            : Container(
                decoration: BoxDecoration(
                  color: isDark == true ? Colors.grey.shade900 : Colors.white,
                  borderRadius: const BorderRadius.all(
                    Radius.circular(5),
                  ),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 5),
                child: Column(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 1,
                      height: MediaQuery.of(context).size.height * 0.2,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(0),
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: alldata.length,
                        itemBuilder: (context, index) {
                          return (alldata[index]['channel_category']
                                  .contains(categorylist[j]))
                              ? Container(
                                  color: isDark == true
                                      ? Colors.grey.shade900
                                      : Colors.white,
                                  margin: const EdgeInsets.only(right: 1),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          InkWell(
                                            onTap: () async {
                                              if (status != 'Offline') {
                                                controllerStack.animateToHeight(
                                                    state: PanelState.MAX,
                                                    duration: const Duration(
                                                        milliseconds: 30));
                                                cancel.value = false;
                                                if (idOfChannel.isNotEmpty) {
                                                  print(
                                                      "idOfChannelunsub:${idOfChannel}");
                                                }

                                                await MQTTConnections()
                                                    .unsubscribeToChannel(
                                                        "$idOfChannel");
                                                _radioPlayer.stop();

                                                loader.value = true;
                                                Future.delayed(
                                                    const Duration(seconds: 5),
                                                    () {
                                                  setState(() {
                                                    loader.value = false;
                                                  });
                                                });

                                                print(
                                                    "currentindx:$currentindx");
                                                favdata = alldata[index];

                                                nameOfChannel.value =
                                                    alldata[index]
                                                        ["channel_name"];
                                                descOfChannel.value =
                                                    alldata[index]
                                                        ["channel_description"];
                                                catgOfChannel.value =
                                                    alldata[index]
                                                        ["channel_category"];
                                                idOfChannel.value =
                                                    alldata[index]
                                                        ["channel_id"];
                                                urlOfChannel.value =
                                                    alldata[index]
                                                        ["channel_stream_url"];
                                                imgurlOfChannel.value =
                                                    alldata[index]
                                                        ["channel_image_url"];
                                                setState(() {
                                                  openmini = true;
                                                  nextindex = index;
                                                });
                                                subcount = 1.obs;

                                                // startminiplayerOpen(urlOfChannel);
                                                Future.delayed(
                                                    const Duration(seconds: 2));
                                                var qwe =
                                                    await MQTTConnections()
                                                        .MQTTSubscribeMethod(
                                                            "$idOfChannel");

                                                if (displayfavlist.isNotEmpty) {
                                                  for (int i = 0;
                                                      i < displayfavlist.length;
                                                      i++) {
                                                    if (displayfavlist[i]
                                                            ["channel_id"]
                                                        .toString()
                                                        .contains(
                                                            idOfChannel)) {
                                                      setState(() {
                                                        addFavourite = true;
                                                      });
                                                      break;
                                                    } else {
                                                      setState(() {
                                                        addFavourite = false;
                                                      });
                                                    }
                                                  }
                                                }
                                                print("spdata:${idOfChannel}");
                                                print(
                                                    "favdfgdcg:${displayfavlist}");
                                                Future.delayed(
                                                    const Duration(seconds: 2));

                                                final SharedPreferences
                                                    sharedPreferences =
                                                    await SharedPreferences
                                                        .getInstance();

                                                print(
                                                    "spdata:${sharedPreferences.getString('device_id')} ");

                                                Future.delayed(
                                                    const Duration(seconds: 5),
                                                    () {});
                                                var resp =
                                                    await MQTTConnections()
                                                        .getChannelDetails(
                                                            "$idOfChannel");
                                                print(
                                                    "spdata:${resp["total_number_of_subscribers"]}name${resp["channel_id"]}");
                                                // subcount.value =
                                                //     resp["total_number_of_subscribers"];
                                                print("tacsvvdcvaadcad");
                                                await _radioPlayer.setChannel(
                                                  title: '$nameOfChannel',
                                                  url: '$urlOfChannel',
                                                  imagePath: '$imgurlOfChannel',
                                                );
                                                Future.delayed(
                                                    const Duration(
                                                        milliseconds: 10), () {
                                                  _radioPlayer.play();
                                                });

                                                _radioPlayer.stateStream
                                                    .listen((value) {
                                                  print("sdgxcfhjbkn:$value");
                                                  setState(() {
                                                    isPlaying = value;
                                                  });
                                                });

                                                _radioPlayer.metadataStream
                                                    .listen((value) {
                                                  print("hbshscccs${metadata}");
                                                  setState(() {
                                                    metadata = value;
                                                  });
                                                  print("hbshscccs${metadata}");
                                                });

                                                print(
                                                    "nameOfChannel:${nameOfChannel}");
                                                print(
                                                    "idOfChannel:${idOfChannel}");
                                                print(
                                                    "descOfChannel:${descOfChannel}");
                                              } else {
                                                WidgetsBinding.instance
                                                    .addPostFrameCallback((_) {
                                                  // Add Your Code here.

                                                  ScaffoldMessenger.of(context)
                                                      .showSnackBar(SnackBar(
                                                          behavior:
                                                              SnackBarBehavior
                                                                  .floating,
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(5),
                                                          shape:
                                                              const StadiumBorder(),
                                                          backgroundColor:
                                                              maincolor,
                                                          duration:
                                                              const Duration(
                                                                  seconds: 3),
                                                          content: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceEvenly,
                                                            children: [
                                                              const SizedBox(
                                                                width: 40,
                                                                height: 40,
                                                                child: Image(
                                                                    image: AssetImage(
                                                                        "assets/Raydeo.ONE512.png")),
                                                              ),
                                                              SizedBox(
                                                                width: 250,
                                                                child: Text(
                                                                  "Please check your internet connection and try again",
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: Theme.of(
                                                                          context)
                                                                      .textTheme
                                                                      .labelLarge,
                                                                ),
                                                              )
                                                            ],
                                                          )));
                                                });
                                              }
                                            },
                                            child: Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  .3,
                                              height: MediaQuery.of(context)
                                                      .size
                                                      .height *
                                                  .129,
                                              padding: const EdgeInsets.all(0),
                                              alignment: Alignment.center,
                                              decoration: const BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(15))),
                                              child: Card(
                                                elevation: 5,
                                                shape:
                                                    const RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    15))),
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          12.0),
                                                  child: status != 'Offline'
                                                      ? Image.network(
                                                          "${alldata[index]['channel_image_url']}")
                                                      : const Image(
                                                          image: AssetImage(
                                                              "assets/Raydeo.ONE512.png")),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 15,
                                          ),
                                          SizedBox(
                                            // color:
                                            //     Theme.of(context).backgroundColor,
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                .26,
                                            child: Column(
                                              children: [
                                                Text(
                                                  "${alldata[index]['channel_name']}",
                                                  textAlign: TextAlign.center,
                                                  // style: Theme.of(context)
                                                  //     .textTheme
                                                  //     .titleSmall,
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    color: isDark == true
                                                        ? Colors.white
                                                        : Colors.black,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                )
                              : const SizedBox(
                                  height: 0,
                                );
                        },
                      ),
                    ),
                  ],
                ),
              ),
      );
    } catch (e) {
      print("pie error$e");
      return const Text("NO Data");
    }
  }
}
