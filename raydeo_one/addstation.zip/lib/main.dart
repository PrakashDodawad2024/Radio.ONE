import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:raydeo_one/themes/themeConstant.dart';
import 'package:uni_links/uni_links.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'landingpages/homepage.dart';
import 'mqtt/mqttconnection.dart';
import 'mqtt/mqttregister.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:nowplaying/nowplaying.dart';
import 'package:volume_controller/volume_controller.dart';

int currentindx = 0;
int changeindex = 0;
bool openmini = false;
bool loadingdata = true;
RxString currentPlaying = "".obs;
RxInt subcount = 1.obs;
RxInt curindex = 0.obs;
int nextindex = 0;
RxBool playing = false.obs;
RxBool empty = false.obs;
RxBool otpsent = false.obs;
RxBool isloading = false.obs;
RxBool homepageloader = true.obs;
RxBool loader = false.obs;
RxBool miniplay = false.obs;
RxBool cancel = false.obs;
RxBool tapped = false.obs;
RxBool onplay = false.obs;
RxBool onpause = false.obs;
RxBool tapemail = false.obs;
RxBool shownowplaying = false.obs;
RxBool tapmob = false.obs;
RxBool opennew = false.obs;
RxBool favpage = false.obs;
RxBool nameuser = false.obs;
RxBool copytext = false.obs;
bool verified = accountdetails!.get(
      "MobNoVerified",
    ) ??
    false;
bool addFavourite = false;
List alldata = [];
List favlist = [];
List displayfavlist = [];
String username = accountdetails!.get(
      "username",
    ) ??
    "Your Name";
String mobileNumber = accountdetails!.get(
      "mobileNumber",
    ) ??
    "Mobile Number";
RxList stationdata = [].obs;
List categories = [];
String changename = "";
RxList categorylist = [
  "Newly Added",
  "Favourites",
].obs;
RxList titlelist = [].obs;
RxList viewmorelist = [].obs;
List urls = [];
Color bgColor = Colors.purple;
Color maincolor = const Color.fromARGB(255, 152, 188, 145);
bool? isFirsttime;
bool? isRegistered;
bool Firsttimee = true;
Box? channel;
Box? clientdetailBox;
Box? allmessages;
Box? accountdetails;
Box? statiomessages;
Box? favouritelist;
String selected = "";
RxString nameOfChannel = ''.obs;
RxString descOfChannel = ''.obs;
RxString urlOfChannel = ''.obs;
RxString imgurlOfChannel = ''.obs;
RxString idOfChannel = ''.obs;
RxString catgOfChannel = ''.obs;
RxString catgChannel = 'Newly Added'.obs;
bool isDataConnected = true;
bool _initialURILinkHandled = false;
bool viewmore = false;

bool isDark =
    SchedulerBinding.instance.window.platformBrightness == Brightness.dark;
double volumeListenerValue = 0;
double getVolume = 0;
double setVolumeValue = 0;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp();
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  isFirsttime = sharedPreferences.getBool("isFirsttime") ?? true;
  isRegistered = sharedPreferences.getBool("isRegistered") ?? false;
  await Hive.initFlutter();
  channel = await Hive.openBox("channel");
  clientdetailBox = await Hive.openBox("clientdetailBox");
  allmessages = await Hive.openBox("allmessages");
  statiomessages = await Hive.openBox("statiomessages");
  favouritelist = await Hive.openBox("favouritelist");
  accountdetails = await Hive.openBox("accountdetails");

  initializeDateFormatting().then((_) => SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]).then((value) => runApp(MyApp())));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  StreamSubscription? _streamSubscription;

  @override
  void initState() {
    super.initState();
    deviceThemeListener();
    _initURIHandler();
    _incomingLinkHandler();
    callmqtt();
    VolumeController().listener((volume) {
      setState(() => volumeListenerValue = volume);
    });

    VolumeController().getVolume().then((volume) => setVolumeValue = volume);
  }

  @override
  void dispose() {
    VolumeController().removeListener();
    _streamSubscription?.cancel();
    super.dispose();
  }

  deviceThemeListener() {
    final window = WidgetsBinding.instance.window;
    window.onPlatformBrightnessChanged = () {
      final brightness = window.platformBrightness;
      print("brightness:$brightness");
      if (brightness == Brightness.dark) {
        setState(() {
          isDark = true;
        });
      } else {
        setState(() {
          isDark = false;
        });
      }
    };
  }

  Future<void> _initURIHandler() async {
    if (!_initialURILinkHandled) {
      _initialURILinkHandled = true;
      // Fluttertoast.showToast(
      //     msg: "Invoked _initURIHandler",
      //     toastLength: Toast.LENGTH_SHORT,
      //     gravity: ToastGravity.BOTTOM,
      //     timeInSecForIosWeb: 1,
      //     backgroundColor: Colors.green,
      //     textColor: Colors.white);
      try {
        final initialURI = await getInitialUri();
        // Use the initialURI and warn the user if it is not correct,
        // but keep in mind it could be `null`.
        if (initialURI != null) {
          debugPrint("Initial URI received $initialURI");
          if (!mounted) {
            return;
          }
          setState(() {});
        } else {
          debugPrint("Null Initial URI received");
        }
      } on PlatformException {
        // Platform messages may fail, so we use a try/catch PlatformException.
        // Handle exception by warning the user their action did not succeed
        debugPrint("Failed to receive initial uri");
      } on FormatException catch (err) {
        if (!mounted) {
          return;
        }
        debugPrint('Malformed Initial URI received');
      }
    }
  }

  /// Handle incoming links - the ones that the app will receive from the OS
  /// while already started.
  void _incomingLinkHandler() {
    if (!kIsWeb) {
      // It will handle app links while the app is already started - be it in
      // the foreground or in the background.
      _streamSubscription = uriLinkStream.listen((Uri? uri) {
        if (!mounted) {
          return;
        }
        debugPrint('Received URI: $uri');
        setState(() {});
      }, onError: (Object err) {
        if (!mounted) {
          return;
        }
        debugPrint('Error occurred: $err');
        setState(() {
          if (err is FormatException) {
          } else {}
        });
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.resumed:
        print("APP IS RESUMED!!!");

        print("picker is off");
        MQTTConnectionCommonMethod();

        break;
      case AppLifecycleState.inactive:
        listenerObject?.cancel();

        break;
      case AppLifecycleState.paused:
        listenerObject?.cancel();

        break;
      case AppLifecycleState.detached:
        print("detached");

        listenerObject?.cancel();

        break;
    }
  }

  callmqtt() async {
    if (isRegistered == false) {
      await Mqtt().registerUserMethod();
    } else {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      var connectionDetail = await jsonDecode(
          "${sharedPreferences.getString('allconnectionData')}");
      await MQTTConnections().connectToMQTTMethod(
          connectionDetail['ip_address'],
          connectionDetail['port'],
          connectionDetail['user_name'],
          connectionDetail['password']);
      print(
          "**********************************************************************************************************");
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Radio.ONE',
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      home: AnimatedSplashScreen(
        backgroundColor: const Color.fromARGB(255, 50, 50, 50),
        splashIconSize: 300,
        splash: Center(
          child: Column(
            children: [
              Container(
                  color: const Color.fromARGB(255, 50, 50, 50),
                  padding: const EdgeInsets.all(15),
                  width: 300,
                  height: 300,
                  child: const ClipRRect(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                      child:
                          Image(image: AssetImage("assets/Raydeo.ONE.png")))),
            ],
          ),
        ),
        duration: 300,
        nextScreen: MyHomePage(),
        splashTransition: SplashTransition.fadeTransition,
      ),
    );
  }

  MQTTConnectionCommonMethod() async {
    if (isRegistered == false) {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      var connectionDetail =
          jsonDecode("${sharedPreferences.getString('allconnectionData')}");
      MQTTConnections().connectToMQTTMethod(
          connectionDetail['ip_address'],
          connectionDetail['port'],
          connectionDetail['user_name'],
          connectionDetail['password']);
    }
  }
}
