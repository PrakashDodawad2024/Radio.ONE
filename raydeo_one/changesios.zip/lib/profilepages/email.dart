import 'dart:io' show Platform;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class EmailPage extends StatefulWidget {
  const EmailPage({super.key});

  @override
  State<EmailPage> createState() => _ChangepasswordState();
}

class _ChangepasswordState extends State<EmailPage> {
  TextEditingController emailid = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CupertinoNavigationBar(
        leading: Platform.isAndroid
            ? const Text('')
            : const CupertinoNavigationBarBackButton(
                color: Color.fromARGB(255, 105, 137, 92),
              ),
        // middle: Text('change password'),
      ),
      body: SafeArea(
        child: Container(
            margin: const EdgeInsets.all(20),
            child: Column(
              //mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 10),
                  child: const Text(
                    'Forgot Password?',
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.015,
                ),
                Container(
                    child: const Text(
                  'Enter the email associated with your account, verification code will be sent to your email.',
                  style: TextStyle(fontSize: 17),
                )),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.03,
                ),
                Container(
                  child: const Text(
                    'Email Address',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.015,
                ),
                Container(
                  child: TextFormField(
                    inputFormatters: [
                      FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))
                    ],
                    controller: emailid,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    validator: (text) {
                      if (!text!.isEmail) {
                        return "invalid Email";
                      }
                    },
                    decoration: InputDecoration(
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(5)),
                        borderSide: BorderSide(
                          width: 1,
                          color: Colors.grey.shade600,
                        ),
                      ),
                      errorBorder: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5))),
                      focusedBorder: const OutlineInputBorder(
                        borderSide: BorderSide(
                          width: 1,
                          color: Colors.black,
                        ),
                        // borderRadius: BorderRadius.circular(20)
                      ),
                      enabledBorder: const OutlineInputBorder(
                        borderSide: BorderSide(width: 1, color: Colors.black),
                        // borderRadius: BorderRadius.circular(20)
                      ),

                      hintText: "Enter your mail Id",
                      // labelText: '    Email Id',
                      // labelStyle: TextStyle(
                      //     fontSize: MediaQuery.of(context).size.height*0.02,
                      //     fontWeight: FontWeight.bold,
                      //     color:
                      //         Color.fromARGB(255, 85, 83, 83)),
                      prefixIcon: const Icon(CupertinoIcons.envelope,
                          color: Color.fromARGB(255, 85, 83, 83)),
                    ),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.03,
                ),
                Container(
                  height: 40,
                  width: double.infinity,
                  // alignment: Alignment.center,
                  child: ElevatedButton(
                    onPressed: () {
                      SystemChannels.textInput.invokeMethod('TextInput.hide');
                      // AuthService().resetPassword(emailid.text, context);
                    },
                    style: ButtonStyle(
                      elevation: MaterialStateProperty.all(3),
                      backgroundColor: MaterialStateProperty.all(
                          const Color.fromARGB(255, 105, 137, 92)),
                    ),
                    child: const Text(
                      'Send Verification Code',
                      style: TextStyle(color: Colors.white, fontSize: 17),
                    ),
                  ),
                )
                //           Container(child: FlatButton(onPressed: ()async{
                //              try {
                //   final result=await Amplify.Auth.confirmResetPassword(
                //       username: 'divyashree@mobil80.com',
                //       newPassword: '456789',
                //       confirmationCode: '291533'
                //   );
                //   print('result:${result}');
                // } on AmplifyException catch (e) {
                //   print('error:${e}');
                // }
                //             final result = await Amplify.Auth.resetPassword(
                //   username: 'divyashree@mobil80.com',
                // );
                // print('changed password:${result.isPasswordReset}');
                // },child: Text('Reset'),),)
              ],
            )),
      ),
    );
  }
}
