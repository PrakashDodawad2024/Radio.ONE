import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:ui' as ui;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:double_back_to_close_app/double_back_to_close_app.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:radio_player/radio_player.dart';
import 'package:raydeo_one/widgets/connectivity.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uni_links/uni_links.dart';
import 'package:volume_controller/volume_controller.dart';
import '../backgroundplay/mainplay.dart';
import '../main.dart';
import '../mqtt/mqttconnection.dart';
import '../mqtt/mqttregister.dart';
import '../widgets/chatpage.dart';
import '../widgets/minimusic.dart';
import '../widgets/musicplayer.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:expansion_widget/expansion_widget.dart';
import '../profilepages/profile.dart';
import 'search.dart';
import 'homepage.dart';

final controllerStack = MiniplayerController();
RxBool miniplayerOpen = false.obs;
// RxBool loader = false.obs;
Map favdata = {};
int currentindex = 0;
Map surce = {ConnectivityResult.none: false};
MyConnectivity _connectivity = MyConnectivity.instance;
String status = "Mobile: Online";
RxBool miniplayerOpened = false.obs;
RadioPlayer _radioPlayer = RadioPlayer();
bool isPlaying = false;
int selected = 0;
List<String>? metadata;
RxBool playing = false.obs;
List closeRest = [0];
double _currentSliderSecondaryValue = 0.5;
Uri? _initialURI;
Uri? _currentURI;
Object? _err;
StreamSubscription? _streamSubscription;

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _incomingLinkHandler();
    displayfavlist = favouritelist!.get("favlist") ?? [];

    // initRadioPlayer();

    print("categories:$categorylist");
    _connectivity.initialise();
    _connectivity.myStream.listen((source) {
      if (!mounted) {
        return;
      } else {
        setState(() => surce = source);
      }
    });
  }

  void _incomingLinkHandler() {
    // 1
    if (!kIsWeb) {
      // 2
      _streamSubscription = uriLinkStream.listen((Uri? uri) {
        if (!mounted) {
          return;
        }
        debugPrint('Received URI: $uri');
        setState(() {
          _currentURI = uri;
          _err = null;
        });
        // 3
      }, onError: (Object err) {
        if (!mounted) {
          return;
        }
        debugPrint('Error occurred: $err');
        setState(() {
          _currentURI = null;
          if (err is FormatException) {
            _err = err;
          } else {
            _err = null;
          }
        });
      });
    }
  }

  // void initRadioPlayer() {

  // }

  // connectmqtt() async {
  //   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  //   var connectionDetail =
  //       await jsonDecode("${sharedPreferences.getString('allconnectionData')}");
  //   print(
  //       "connectionDetailconnectionDetail:${sharedPreferences.getString('allconnectionData')}");
  //   await MQTTConnections().connectToMQTTMethod(
  //       connectionDetail['ip_address'],
  //       connectionDetail['port'],
  //       connectionDetail['user_name'],
  //       connectionDetail['password']);
  // }

  int currentIndex = 0;
  String frpStatus = "flutter_radio_stopped";
  static final AudioPlayer _player = AudioPlayer();
  double _volumeListenerValue = 0;
  double _getVolume = 0;

  @override
  void dispose() {
    _streamSubscription?.cancel();
    VolumeController().removeListener();
    super.dispose();
  }

  AudioContext _getAudioContext() {
    return const AudioContext(
        android: AudioContextAndroid(
          isSpeakerphoneOn: false,
          stayAwake: true,
          contentType: AndroidContentType.music,
          usageType: AndroidUsageType.media,
          audioFocus: AndroidAudioFocus.gain,
        ),
        iOS: AudioContextIOS(
            category: AVAudioSessionCategory.soloAmbient,
            options: [
              // AVAudioSessionOptions.defaultToSpeaker,
            ]
            // +
            // [AVAudioSessionOptions.allowAirPlay] +
            // [AVAudioSessionOptions.allowBluetooth] +
            // [AVAudioSessionOptions.allowBluetoothA2DP]
            ));
  }

  startminiplayerOpen(url) {
    playing.value = true;
    _player.play(UrlSource('$url'));
  }

  stopminiplayerOpen() {
    playing.value = false;
    _player.stop();
  }

  // getSegregatedLists() {
  //   print("segrerrere");
  //   return Obx(
  //     () => SingleChildScrollView(
  //       child: Column(
  //         children: [
  //           for (int j = 0; j < categorylist.length; j++)
  //             Column(
  //               mainAxisSize: MainAxisSize.min,
  //               children: [
  //                 SizedBox(
  //                   width: MediaQuery.of(context).size.width * 1,
  //                   height: MediaQuery.of(context).size.height * 0.26,
  //                   //  color: Colors.green.withOpacity(0.5),
  //                   child: ListView.builder(
  //                     shrinkWrap: true,
  //                     scrollDirection: Axis.horizontal,
  //                     itemCount: alldata.length,
  //                     itemBuilder: (context, index) {
  //                       print("checkk:${alldata[index]} ${categorylist[j]}");
  //                       return (alldata[index]['channel_category']
  //                               .contains(categorylist[j]))
  //                           ? Column(
  //                               mainAxisAlignment: MainAxisAlignment.start,
  //                               children: [
  //                                 InkWell(
  //                                   onTap: () async {
  //                                     if (status != 'Offline') {
  //                                       if (idOfChannel != "") {
  //                                         await MQTTConnections()
  //                                             .MQTTUnSubscribeMethod(
  //                                                 "$idOfChannel");
  //                                         controllerStack.animateToHeight(
  //                                             state: PanelState.MAX,
  //                                             duration: const Duration(
  //                                                 milliseconds: 30));
  //                                       }
  //                                       controllerStack.animateToHeight(
  //                                           state: PanelState.MAX,
  //                                           duration: const Duration(
  //                                               milliseconds: 30));

  //                                       // print("called");
  //                                       // print(
  //                                       //     "channel_id:${alldata[index]["channel_id"]}");
  //                                       // print(
  //                                       //     "channel_namesss:${alldata[index]["channel_name"]}");
  //                                       // if (play.value == true)

  //                                       currentindx = alldata[index]
  //                                           ["total_number_of_subscribers"];

  //                                       Mqtt.firsttime!.value = false;
  //                                       nameOfChannel.value =
  //                                           alldata[index]["channel_name"];
  //                                       descOfChannel.value = alldata[index]
  //                                           ["channel_description"];
  //                                       idOfChannel.value =
  //                                           alldata[index]["channel_id"];
  //                                       urlOfChannel.value = alldata[index]
  //                                           ["channel_stream_url"];
  //                                       imgurlOfChannel.value =
  //                                           alldata[index]["channel_image_url"];
  //                                       // startminiplayerOpen(urlOfChannel);

  //                                       await MQTTConnections()
  //                                           .MQTTSubscribeMethod(
  //                                               "$idOfChannel");
  //                                       _radioPlayer.stop();
  //                                       await _radioPlayer.setChannel(
  //                                         title: '$nameOfChannel',
  //                                         url: '$urlOfChannel',
  //                                         imagePath: '$imgurlOfChannel',
  //                                       );
  //                                       Future.delayed(
  //                                           const Duration(milliseconds: 10),
  //                                           () {
  //                                         _radioPlayer.play();
  //                                       });

  //                                       _radioPlayer.stateStream
  //                                           .listen((value) {
  //                                         print("sdgxcfhjbkn:$value");
  //                                         setState(() {
  //                                           isPlaying = value;
  //                                         });
  //                                       });

  //                                       _radioPlayer.metadataStream
  //                                           .listen((value) {
  //                                         setState(() {
  //                                           metadata = value;
  //                                         });
  //                                       });

  //                                       print("nameOfChannel:${nameOfChannel}");
  //                                       print("descOfChannel:${descOfChannel}");
  //                                       print(
  //                                           "firsttime:${Mqtt.firsttime!.value}");
  //                                     } else {
  //                                       _radioPlayer.stop();
  //                                       ScaffoldMessenger.of(context)
  //                                           .showSnackBar(SnackBar(
  //                                               behavior:
  //                                                   SnackBarBehavior.floating,
  //                                               padding:
  //                                                   const EdgeInsets.all(5),
  //                                               shape: const StadiumBorder(),
  //                                               backgroundColor:
  //                                                   const Color.fromARGB(
  //                                                       255, 242, 242, 242),
  //                                               duration:
  //                                                   const Duration(seconds: 3),
  //                                               content: Row(
  //                                                 mainAxisAlignment:
  //                                                     MainAxisAlignment
  //                                                         .spaceEvenly,
  //                                                 children: const [
  //                                                   SizedBox(
  //                                                     width: 40,
  //                                                     height: 40,
  //                                                     child: Image(
  //                                                         image: AssetImage(
  //                                                             "assets/Raydeo.ONE512.png")),
  //                                                   ),
  //                                                   SizedBox(
  //                                                     width: 250,
  //                                                     child: Text(
  //                                                       "Please check your internet connection and try again",
  //                                                       textAlign:
  //                                                           TextAlign.center,
  //                                                       style: TextStyle(
  //                                                           color: Colors.black,
  //                                                           fontWeight:
  //                                                               FontWeight.bold,
  //                                                           fontSize: 14),
  //                                                     ),
  //                                                   )
  //                                                 ],
  //                                               )));
  //                                     }
  //                                   },
  //                                   child: Container(
  //                                     width: MediaQuery.of(context).size.width *
  //                                         .3,
  //                                     height:
  //                                         MediaQuery.of(context).size.height *
  //                                             .2,
  //                                     margin: const EdgeInsets.only(
  //                                         left: 8, right: 20),
  //                                     // padding: const EdgeInsets.all(5),
  //                                     alignment: Alignment.center,
  //                                     decoration: const BoxDecoration(
  //                                         // image: DecorationImage(
  //                                         //   image: NetworkImage(
  //                                         //       "${alldata[index]['channel_image_url']}"),
  //                                         // ),

  //                                         borderRadius: BorderRadius.all(
  //                                             Radius.circular(40))),
  //                                     child: ClipRRect(
  //                                       borderRadius:
  //                                           BorderRadius.circular(12.0),
  //                                       child: status != 'Offline'
  //                                           ? Image.network(
  //                                               "${alldata[index]['channel_image_url']}",
  //                                             )
  //                                           : const Image(
  //                                               image: AssetImage(
  //                                                   "assets/Raydeo.ONE512.png")),
  //                                     ),
  //                                   ),
  //                                 ),
  //                                 SizedBox(
  //                                   width:
  //                                       MediaQuery.of(context).size.width * .3,
  //                                   child: Text(
  //                                     "${alldata[index]['channel_name']}",
  //                                     textAlign: TextAlign.center,
  //                                     style: const TextStyle(
  //                                         color: Colors.black, fontSize: 12),
  //                                   ),
  //                                 ),
  //                                 // SizedBox(
  //                                 //   height: MediaQuery.of(context).size.height *
  //                                 //       0.05,
  //                                 // ),

  //                                 // Align(
  //                                 //   alignment: Alignment.topRight,
  //                                 //   child: Container(
  //                                 //     width: 75,
  //                                 //     height: 35,
  //                                 //     decoration: BoxDecoration(
  //                                 //         color: Colors.black38,
  //                                 //         borderRadius:
  //                                 //             BorderRadius.circular(20)),
  //                                 //     margin: EdgeInsets.only(
  //                                 //         left: MediaQuery.of(context)
  //                                 //                 .size
  //                                 //                 .width *
  //                                 //             0.28,
  //                                 //         top: MediaQuery.of(context)
  //                                 //                 .size
  //                                 //                 .width *
  //                                 //             0.045),
  //                                 //     child: Center(
  //                                 //       child: Padding(
  //                                 //         padding: const EdgeInsets.all(2.0),
  //                                 //         child: Row(
  //                                 //           children: [
  //                                 //             const Icon(
  //                                 //               Icons.remove_red_eye,
  //                                 //               color: Colors.white,
  //                                 //             ),
  //                                 //             Text(
  //                                 //               " ${alldata[index]["total_number_of_subscribers"]}",
  //                                 //               style: const TextStyle(
  //                                 //                   color: Colors.white),
  //                                 //             ),
  //                                 //           ],
  //                                 //         ),
  //                                 //       ),
  //                                 //     ),
  //                                 //   ),
  //                                 // ),
  //                               ],
  //                             )
  //                           : const SizedBox(
  //                               height: 0,
  //                             );
  //                     },
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           if (Mqtt.firsttime!.value == false)
  //             const SizedBox(
  //               height: 130,
  //             )
  //         ],
  //       ),
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    // displayfavlist = data;
    print('status**********:${status}');
    switch (surce.keys.toList()[0]) {
      case ConnectivityResult.none:
        status = "Offline";

        isDataConnected = false;
        _radioPlayer.stop();

        break;
      case ConnectivityResult.mobile:
        status = "Mobile: Online";

        isDataConnected = true;

        break;
      case ConnectivityResult.wifi:
        status = "WiFi: Online";

        isDataConnected = true;

        break;
      case ConnectivityResult.ethernet:
        status = "Ethernet: Online";

        isDataConnected = true;

        break;
    }
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.grey.shade200,
          leading: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text('  '),
              IconButton(
                onPressed: () {
                  // method to show the search bar
                  showSearch(
                      context: context,
                      // delegate to customize the search bar
                      delegate: CustomSearchDelegate(setState: setState));
                },
                icon: Icon(
                  Icons.search,
                  color: maincolor,
                  size: 28,
                ),
              ),
            ],
          ),
          title: const Text(
            'Radio.ONE',
            style: TextStyle(
                color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),
            textAlign: TextAlign.start,
          ),
          centerTitle: true,
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => const Profile(),
                    ));
                  },
                  icon: Icon(
                    Icons.account_circle_rounded,
                    color: maincolor,
                    size: 40,
                  ),
                ),
                Text('    ')
              ],
            ),
          ],
        ),
        resizeToAvoidBottomInset: false,
        body: ValueListenableBuilder(
            valueListenable: allmessages!.listenable(),
            builder: (context, value, child) {
              final allresponse = allmessages!.get("allmessages");
              print("allresponvvbvbse$allresponse");
              if (allresponse != null) {
                final decodeddata = jsonDecode(allresponse["channel_message"]);
                final alldecodeddata = jsonDecode(decodeddata["description"]);
                // print("alldecodeddata${alldecodeddata}");
                alldata = alldecodeddata;
                print("alldaddddta$alldata");
                // if (alldata.length != 0) {
                print("segregating alldata");
                for (int i = 0; i < alldata.length; i++) {
                  if (!categorylist.contains(alldata[i]["channel_category"])) {
                    categorylist.add(alldata[i]["channel_category"]);
                    print("categorylist$categorylist");
                  }
                  if (!titlelist.contains(alldata[i]["channel_name"]) ||
                      !titlelist.contains(alldata[i]["channel_category"])) {
                    titlelist.add(alldata[i]["channel_name"].toString());
                    titlelist.add(alldata[i]["channel_category"].toString());
                    print("titlelist$titlelist");
                  }
                }
                // print("tapped${alldata.contains("$idOfChannel")}");
                // if (alldata.contains("$idOfChannel")) {
                //   // print("tappedcontaines:$tapped");

                //   Mqtt.firsttime!.value = false;

                //   print("tappedcontaines:$tapped");
                // } else {
                //   print("tappedcoes$idOfChannel");
                //   // print("beforeeeee:$tapped");
                //   Mqtt.firsttime!.value = true;
                //   print("tappeddoesnt:$tapped");
                // }
              }

              return DoubleBackToCloseApp(
                snackBar: const SnackBar(
                  duration: Duration(seconds: 5),
                  dismissDirection: DismissDirection.up,
                  shape: StadiumBorder(),
                  showCloseIcon: true,
                  backgroundColor: Colors.red,
                  content: Text('Tap back again to leave'),
                ),
                child: Stack(
                  children: <Widget>[
                    Container(
                      height: MediaQuery.of(context).size.height * 1,
                      padding: const EdgeInsets.only(top: 10),
                      color: Colors.grey.shade200,
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                for (int j = 0; j < categorylist.length; j++)
                                  SizedBox(
                                      width:
                                          MediaQuery.of(context).size.width * 1,
                                      child: (categorylist.isNotEmpty)
                                          ? Card(
                                              color: const Color.fromARGB(
                                                  255, 242, 242, 242),
                                              elevation: 0,
                                              child: getSortedChannels(j),
                                              // ExpansionWidget(
                                              // onExpansionChanged: (value) {
                                              //   if (value == true) {
                                              //     closeRest = [0];
                                              //     closeRest.add(j);
                                              //   }
                                              // },
                                              //     titleBuilder: (animationValue, easeInValue, isExpanded, toggleFunction) =>getSortedChannels() ,
                                              //     // Text(
                                              //     //   '${categorylist[j]}',
                                              //     //   style: const TextStyle(
                                              //     //       fontSize: 16,
                                              //     //       fontWeight:
                                              //     //           FontWeight.bold),
                                              //     // ),
                                              //     // subtitle: Text('Trailing expansion arrow icon'),
                                              //     content: Column(
                                              //       children: [
                                              //         Container(
                                              //           width: MediaQuery.of(
                                              //                       context)
                                              //                   .size
                                              //                   .width *
                                              //               1,
                                              //           height: MediaQuery.of(
                                              //                       context)
                                              //                   .size
                                              //                   .height *
                                              //               0.26,
                                              //           child: ListView.builder(
                                              //             shrinkWrap: true,
                                              //             scrollDirection:
                                              //                 Axis.horizontal,
                                              //             itemCount:
                                              //                 alldata.length,
                                              //             itemBuilder:
                                              //                 (context, index) {
                                              //               print(
                                              //                   "checkk:${alldata[index]} ${categorylist[j]}");
                                              //               return (alldata[index]
                                              //                           [
                                              //                           'channel_category']
                                              //                       .contains(
                                              //                           categorylist[
                                              //                               j]))
                                              //                   ? Column(
                                              //                       mainAxisAlignment:
                                              //                           MainAxisAlignment
                                              //                               .start,
                                              //                       children: [
                                              //                         InkWell(
                                              //                           onTap:
                                              //                               () async {
                                              //                             if (status !=
                                              //                                 'Offline') {
                                              //                               if (idOfChannel !=
                                              //                                   "") {
                                              //                                 await MQTTConnections().MQTTUnSubscribeMethod("$idOfChannel");
                                              //                                 controllerStack.animateToHeight(state: PanelState.MAX, duration: const Duration(milliseconds: 30));
                                              //                               }
                                              //                               controllerStack.animateToHeight(
                                              //                                   state: PanelState.MAX,
                                              //                                   duration: const Duration(milliseconds: 30));
                                              //                               loader.value =
                                              //                                   true;
                                              //                               Future.delayed(const Duration(seconds: 3),
                                              //                                   () {
                                              //                                 setState(() {
                                              //                                   loader.value = false;
                                              //                                 });
                                              //                               });

                                              //                               // print("called");
                                              //                               // print(
                                              //                               //     "channel_id:${alldata[index]["channel_id"]}");
                                              //                               // print(
                                              //                               //     "channel_namesss:${alldata[index]["channel_name"]}");
                                              //                               // if (play.value == true)

                                              //                               currentindx =
                                              //                                   alldata[index]["total_number_of_subscribers"];

                                              //                               Mqtt.firsttime!.value =
                                              //                                   false;
                                              //                               nameOfChannel.value =
                                              //                                   alldata[index]["channel_name"];
                                              //                               descOfChannel.value =
                                              //                                   alldata[index]["channel_description"];
                                              //                               catgOfChannel.value =
                                              //                                   alldata[index]["channel_category"];
                                              //                               idOfChannel.value =
                                              //                                   alldata[index]["channel_id"];
                                              //                               urlOfChannel.value =
                                              //                                   alldata[index]["channel_stream_url"];
                                              //                               imgurlOfChannel.value =
                                              //                                   alldata[index]["channel_image_url"];
                                              //                               // startminiplayerOpen(urlOfChannel);

                                              //                               await MQTTConnections().MQTTSubscribeMethod("$idOfChannel");
                                              //                               _radioPlayer.stop();
                                              //                               await _radioPlayer.setChannel(
                                              //                                 title: '$nameOfChannel',
                                              //                                 url: '$urlOfChannel',
                                              //                                 imagePath: '$imgurlOfChannel',
                                              //                               );
                                              //                               Future.delayed(const Duration(milliseconds: 10),
                                              //                                   () {
                                              //                                 _radioPlayer.play();
                                              //                               });

                                              //                               _radioPlayer.stateStream.listen((value) {
                                              //                                 print("sdgxcfhjbkn:$value");
                                              //                                 setState(() {
                                              //                                   isPlaying = value;
                                              //                                 });
                                              //                               });

                                              //                               _radioPlayer.metadataStream.listen((value) {
                                              //                                 setState(() {
                                              //                                   metadata = value;
                                              //                                 });
                                              //                               });

                                              //                               print("nameOfChannel:${nameOfChannel}");
                                              //                               print("descOfChannel:${descOfChannel}");
                                              //                               print("firsttime:${Mqtt.firsttime!.value}");
                                              //                             } else {
                                              //                               // _radioPlayer
                                              //                               //     .stop();
                                              //                               ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                              //                                   behavior: SnackBarBehavior.floating,
                                              //                                   padding: const EdgeInsets.all(5),
                                              //                                   shape: const StadiumBorder(),
                                              //                                   backgroundColor: const Color.fromARGB(255, 242, 242, 242),
                                              //                                   duration: const Duration(seconds: 3),
                                              //                                   content: Row(
                                              //                                     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                              //                                     children: const [
                                              //                                       SizedBox(
                                              //                                         width: 40,
                                              //                                         height: 40,
                                              //                                         child: Image(image: AssetImage("assets/Raydeo.ONE512.png")),
                                              //                                       ),
                                              //                                       SizedBox(
                                              //                                         width: 250,
                                              //                                         child: Text(
                                              //                                           "Please check your internet connection and try again",
                                              //                                           textAlign: TextAlign.center,
                                              //                                           style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                                              //                                         ),
                                              //                                       )
                                              //                                     ],
                                              //                                   )));
                                              //                             }
                                              //                           },
                                              //                           child:
                                              //                               Container(
                                              //                             width:
                                              //                                 MediaQuery.of(context).size.width * .3,
                                              //                             height:
                                              //                                 MediaQuery.of(context).size.height * .2,
                                              //                             margin: const EdgeInsets.only(
                                              //                                 left: 8,
                                              //                                 right: 20),
                                              //                             // padding: const EdgeInsets.all(5),
                                              //                             alignment:
                                              //                                 Alignment.center,
                                              //                             decoration: const BoxDecoration(
                                              //                                 // image: DecorationImage(
                                              //                                 //   image: NetworkImage(
                                              //                                 //       "${alldata[index]['channel_image_url']}"),
                                              //                                 // ),

                                              //                                 borderRadius: BorderRadius.all(Radius.circular(40))),
                                              //                             child:
                                              //                                 ClipRRect(
                                              //                               borderRadius:
                                              //                                   BorderRadius.circular(12.0),
                                              //                               child: status != 'Offline'
                                              //                                   ? Image.network(
                                              //                                       "${alldata[index]['channel_image_url']}",
                                              //                                     )
                                              //                                   : const Image(image: AssetImage("assets/Raydeo.ONE512.png")),
                                              //                             ),
                                              //                           ),
                                              //                         ),
                                              //                         SizedBox(
                                              //                           width: MediaQuery.of(context).size.width *
                                              //                               .3,
                                              //                           child:
                                              //                               Column(
                                              //                             children: [
                                              //                               Text(
                                              //                                 "${alldata[index]['channel_name']}",
                                              //                                 textAlign: TextAlign.center,
                                              //                                 style: const TextStyle(color: Colors.black, fontSize: 12),
                                              //                               ),
                                              //                               Text(
                                              //                                 "${alldata[index]['channel_category']}",
                                              //                                 textAlign: TextAlign.center,
                                              //                                 style: const TextStyle(color: Colors.black, fontSize: 12),
                                              //                               ),
                                              //                             ],
                                              //                           ),
                                              //                         ),
                                              //                         // SizedBox(
                                              //                         //   height: MediaQuery.of(context).size.height *
                                              //                         //       0.05,
                                              //                         // ),

                                              //                         // Align(
                                              //                         //   alignment: Alignment.topRight,
                                              //                         //   child: Container(
                                              //                         //     width: 75,
                                              //                         //     height: 35,
                                              //                         //     decoration: BoxDecoration(
                                              //                         //         color: Colors.black38,
                                              //                         //         borderRadius:
                                              //                         //             BorderRadius.circular(20)),
                                              //                         //     margin: EdgeInsets.only(
                                              //                         //         left: MediaQuery.of(context)
                                              //                         //                 .size
                                              //                         //                 .width *
                                              //                         //             0.28,
                                              //                         //         top: MediaQuery.of(context)
                                              //                         //                 .size
                                              //                         //                 .width *
                                              //                         //             0.045),
                                              //                         //     child: Center(
                                              //                         //       child: Padding(
                                              //                         //         padding: const EdgeInsets.all(2.0),
                                              //                         //         child: Row(
                                              //                         //           children: [
                                              //                         //             const Icon(
                                              //                         //               Icons.remove_red_eye,
                                              //                         //               color: Colors.white,
                                              //                         //             ),
                                              //                         //             Text(
                                              //                         //               " ${alldata[index]["total_number_of_subscribers"]}",
                                              //                         //               style: const TextStyle(
                                              //                         //                   color: Colors.white),
                                              //                         //             ),
                                              //                         //           ],
                                              //                         //         ),
                                              //                         //       ),
                                              //                         //     ),
                                              //                         //   ),
                                              //                         // ),
                                              //                       ],
                                              //                     )
                                              //                   : const SizedBox(
                                              //                       height: 0,
                                              //                     );
                                              //             },
                                              //           ),
                                              //         ),
                                              //       ],
                                              // )
                                              // ),
                                            )
                                          : const Center(
                                              child:
                                                  CircularProgressIndicator(),
                                            )),
                                miniplayerOpen.value != null
                                    ? SizedBox(
                                        height:
                                            MediaQuery.of(context).size.height *
                                                0.115,
                                      )
                                    : const SizedBox(
                                        height: 0,
                                      )
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Mqtt.firsttime!.value == false
                        ? Miniplayer(
                            controller: controllerStack,
                            backgroundColor: maincolor,
                            minHeight: 100,
                            maxHeight: MediaQuery.of(context).size.height * 1,
                            builder: (height, percentage) => ClipRect(
                                  child: BackdropFilter(
                                      filter: ui.ImageFilter.blur(
                                          sigmaX: 100.0,
                                          sigmaY: 100.0,
                                          tileMode: TileMode.mirror),
                                      child: (height != 100)
                                          ? FutureBuilder(
                                              future: _radioPlayer
                                                  .getArtworkImage(),
                                              builder: (BuildContext context,
                                                  AsyncSnapshot snapshot) {
                                                Image artwork;
                                                if (snapshot.hasData) {
                                                  artwork = snapshot.data;
                                                } else {
                                                  artwork = Image(
                                                      image: NetworkImage(
                                                    '$imgurlOfChannel',
                                                  ));
                                                }

                                                return Obx(
                                                  () => Stack(children: [
                                                    InkWell(
                                                      onTap: () {},
                                                      child: FittedBox(
                                                        child: Container(
                                                          height: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .height *
                                                              0.9,
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width *
                                                              1,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors
                                                                .grey.shade200,
                                                          ),
                                                          child: Column(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceEvenly,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  InkWell(
                                                                    onTap: () {
                                                                      tapped.value =
                                                                          false;
                                                                      print(
                                                                          "tapppppppeddddd");
                                                                      controllerStack.animateToHeight(
                                                                          state: PanelState
                                                                              .MIN,
                                                                          duration:
                                                                              const Duration(milliseconds: 30));
                                                                    },
                                                                    child: Icon(
                                                                      Icons
                                                                          .keyboard_double_arrow_down_rounded,
                                                                      size: 45,
                                                                      color:
                                                                          maincolor,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height *
                                                                    0.025,
                                                              ),
                                                              // Text(
                                                              //   "$nameOfChannel",
                                                              //   textAlign:
                                                              //       TextAlign.center,
                                                              //   style: const TextStyle(
                                                              //       fontSize: 25,
                                                              //       fontWeight:
                                                              //           FontWeight.bold,
                                                              //       color: Colors.white),
                                                              // ),
                                                              // Row(
                                                              //   mainAxisAlignment:
                                                              //       MainAxisAlignment
                                                              //           .spaceAround,
                                                              //   children: [
                                                              //     InkWell(
                                                              //       onTap: () {
                                                              //         // _dialogBuilder(context);
                                                              //         print("tapped");
                                                              //         tapped.value = true;
                                                              //       },
                                                              //       child: Column(
                                                              //         children: const [
                                                              //           Icon(
                                                              //             Icons
                                                              //                 .chat_sharp,
                                                              //             size: 35,
                                                              //             color: Colors
                                                              //                 .white,
                                                              //           ),
                                                              //           Text(
                                                              //             "Live Chat",
                                                              //             style: TextStyle(
                                                              //                 fontSize:
                                                              //                     18,
                                                              //                 fontWeight:
                                                              //                     FontWeight
                                                              //                         .bold,
                                                              //                 color: Colors
                                                              //                     .white),
                                                              //           )
                                                              //         ],
                                                              //       ),
                                                              //     ),
                                                              //     InkWell(
                                                              //       onTap: () {},
                                                              //       child: Column(
                                                              //         children: const [
                                                              //           Icon(
                                                              //             Icons
                                                              //                 .keyboard_voice_rounded,
                                                              //             size: 35,
                                                              //             color: Colors
                                                              //                 .white,
                                                              //           ),
                                                              //           Text(
                                                              //             "Detect Audio",
                                                              //             style: TextStyle(
                                                              //                 fontSize:
                                                              //                     18,
                                                              //                 fontWeight:
                                                              //                     FontWeight
                                                              //                         .bold,
                                                              //                 color: Colors
                                                              //                     .white),
                                                              //           )
                                                              //         ],
                                                              //       ),
                                                              //     ),
                                                              //   ],
                                                              // ),
                                                              Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Column(
                                                                    children: [
                                                                      Text(
                                                                        '$catgOfChannel',
                                                                        softWrap:
                                                                            false,
                                                                        overflow:
                                                                            TextOverflow.fade,
                                                                        style: const TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            fontSize: 16),
                                                                      ),
                                                                      const SizedBox(
                                                                        height:
                                                                            10,
                                                                      ),
                                                                      Text(
                                                                        '$nameOfChannel',
                                                                        softWrap:
                                                                            false,
                                                                        overflow:
                                                                            TextOverflow.fade,
                                                                        style: const TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            fontSize: 24),
                                                                      ),
                                                                      const SizedBox(
                                                                        height:
                                                                            8,
                                                                      ),
                                                                      if (status !=
                                                                          'Offline')
                                                                        Container(
                                                                          decoration: BoxDecoration(
                                                                              color: const Color.fromARGB(255, 242, 242, 242),
                                                                              borderRadius: BorderRadius.circular(20)),
                                                                          child:
                                                                              Padding(
                                                                            padding:
                                                                                const EdgeInsets.all(2.0),
                                                                            child:
                                                                                Row(
                                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                                              children: [
                                                                                const Icon(
                                                                                  Icons.remove_red_eye,
                                                                                  color: Colors.black,
                                                                                ),
                                                                                Obx(
                                                                                  () => Text(
                                                                                    " ${subcount}",
                                                                                    style: const TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height *
                                                                    0.025,
                                                              ),

                                                              // Text(
                                                              //   '$nameOfChannel',
                                                              //   style: const TextStyle(
                                                              //       fontSize:
                                                              //           25,
                                                              //       fontWeight:
                                                              //           FontWeight
                                                              //               .bold,
                                                              //       color: Colors
                                                              //           .white),
                                                              // ),
                                                              Stack(
                                                                children: [
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child:
                                                                        Container(
                                                                      decoration: BoxDecoration(
                                                                          //color: Colors.yellow,
                                                                          borderRadius: BorderRadius.circular(20)),
                                                                      width: MediaQuery.of(context)
                                                                              .size
                                                                              .width *
                                                                          .8,
                                                                      height: MediaQuery.of(context)
                                                                              .size
                                                                              .width *
                                                                          .8,
                                                                      child:
                                                                          ClipRRect(
                                                                        borderRadius:
                                                                            BorderRadius.circular(15),
                                                                        child: status !=
                                                                                'Offline'
                                                                            ? Image(
                                                                                image: NetworkImage(
                                                                                  '$imgurlOfChannel',
                                                                                ),
                                                                                fit: BoxFit.fill,
                                                                              )
                                                                            : const Image(image: AssetImage("assets/Raydeo.ONE512.png")),
                                                                      ),
                                                                    ),
                                                                  ),

                                                                  // if (status !=
                                                                  //     'Offline')
                                                                  //   Align(
                                                                  //     alignment:
                                                                  //         Alignment
                                                                  //             .center,
                                                                  //     child:
                                                                  //         Container(
                                                                  //       decoration: BoxDecoration(
                                                                  //           color: const Color.fromARGB(
                                                                  //               255,
                                                                  //               242,
                                                                  //               242,
                                                                  //               242),
                                                                  //           borderRadius:
                                                                  //               BorderRadius.circular(20)),
                                                                  //       margin: EdgeInsets.only(
                                                                  //           left: MediaQuery.of(context).size.width *
                                                                  //               0.7,
                                                                  //           top: MediaQuery.of(context).size.width *
                                                                  //               0.01,
                                                                  //           right:
                                                                  //               MediaQuery.of(context).size.width * 0.11),
                                                                  //       child:
                                                                  //           Padding(
                                                                  //         padding:
                                                                  //             const EdgeInsets.all(2.0),
                                                                  //         child:
                                                                  //             Row(
                                                                  //           mainAxisAlignment:
                                                                  //               MainAxisAlignment.center,
                                                                  //           children: [
                                                                  //             const Icon(
                                                                  //               Icons.remove_red_eye,
                                                                  //               color: Colors.black,
                                                                  //             ),
                                                                  //             Obx(
                                                                  //               () => Text(
                                                                  //                 " ${subcount}",
                                                                  //                 style: const TextStyle(color: Colors.black),
                                                                  //               ),
                                                                  //             ),
                                                                  //           ],
                                                                  //         ),
                                                                  //       ),
                                                                  //     ),
                                                                  //   ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height *
                                                                    0.025,
                                                              ),

                                                              Container(
                                                                decoration: BoxDecoration(
                                                                    color: Colors
                                                                        .black,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            20)),
                                                                width: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    .8,
                                                                height: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height *
                                                                    .18,
                                                                child: Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .center,
                                                                  children: [
                                                                    // Slider(
                                                                    //   inactiveColor:
                                                                    //       Colors
                                                                    //           .blueGrey,
                                                                    //   activeColor:
                                                                    //       Colors
                                                                    //           .white,
                                                                    //   value:
                                                                    //       _currentSliderSecondaryValue,
                                                                    //   label: _currentSliderSecondaryValue
                                                                    //       .round()
                                                                    //       .toString(),
                                                                    //   onChanged:
                                                                    //       (double
                                                                    //           value) {
                                                                    //     setState(
                                                                    //         () {
                                                                    //       _currentSliderSecondaryValue =
                                                                    //           value;
                                                                    //     });
                                                                    //   },
                                                                    // ),
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceEvenly,
                                                                      children: [
                                                                        IconButton(
                                                                            onPressed:
                                                                                () {
                                                                              Share.share(
                                                                                'mobil80://radiooneinternetradio.com/$idOfChannel',
                                                                              );
                                                                            },
                                                                            icon:
                                                                                Icon(
                                                                              Icons.share_rounded,
                                                                              color: maincolor,
                                                                              size: 35,
                                                                            )),
                                                                        InkWell(
                                                                            onTap:
                                                                                () {
                                                                              print("qwerty");
                                                                              if (status != 'Offline') {
                                                                                setState(() {
                                                                                  isPlaying ? _radioPlayer.pause() : _radioPlayer.play();
                                                                                });
                                                                              } else {
                                                                                // _radioPlayer.stop();
                                                                                WidgetsBinding.instance.addPostFrameCallback((_) {
                                                                                  // Add Your Code here.

                                                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                                                      behavior: SnackBarBehavior.floating,
                                                                                      padding: const EdgeInsets.all(5),
                                                                                      shape: const StadiumBorder(),
                                                                                      backgroundColor: const Color.fromARGB(255, 242, 242, 242),
                                                                                      duration: const Duration(seconds: 3),
                                                                                      content: Row(
                                                                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                        children: const [
                                                                                          SizedBox(
                                                                                            width: 40,
                                                                                            height: 40,
                                                                                            child: Image(image: AssetImage("assets/Raydeo.ONE512.png")),
                                                                                          ),
                                                                                          SizedBox(
                                                                                            width: 250,
                                                                                            child: Text(
                                                                                              "Please check your internet connection and try again",
                                                                                              textAlign: TextAlign.center,
                                                                                              style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                                                                                            ),
                                                                                          )
                                                                                        ],
                                                                                      )));
                                                                                });
                                                                              }
                                                                            },
                                                                            child:
                                                                                Container(
                                                                              height: 50,
                                                                              width: 50,
                                                                              decoration: BoxDecoration(shape: BoxShape.circle, color: maincolor),
                                                                              child: isPlaying
                                                                                  ? loader.value == true
                                                                                      ? const Center(
                                                                                          child: CircularProgressIndicator(
                                                                                          color: Colors.black,
                                                                                        ))
                                                                                      : const Icon(
                                                                                          Icons.pause_rounded,
                                                                                          color: Colors.black,
                                                                                          size: 35,
                                                                                        )
                                                                                  : const Icon(
                                                                                      Icons.play_arrow_rounded,
                                                                                      color: Colors.black,
                                                                                      size: 35,
                                                                                    ),
                                                                            )),
                                                                        IconButton(
                                                                            onPressed:
                                                                                () async {
                                                                              if (displayfavlist.isNotEmpty) {
                                                                                if (addFavourite == true) {
                                                                                  favlist = favouritelist!.get(
                                                                                        "favlist",
                                                                                      ) ??
                                                                                      [];
                                                                                  print("favlistsecondlist${favlist.length}");

                                                                                  for (int x = 0; x < favlist.length; x++) {
                                                                                    print("channel_name : ${favlist[x]["channel_name"]}");
                                                                                    if (favlist[x]["channel_name"].toString() == "$nameOfChannel") {
                                                                                      print("matched  ##################");
                                                                                      setState(() {
                                                                                        favlist.removeAt(x);
                                                                                        addFavourite = !addFavourite;
                                                                                        favouritelist!.put("favlist", []);
                                                                                        favouritelist!.put("favlist", favlist);
                                                                                      });
                                                                                    }
                                                                                  }
                                                                                  print("favlistsecondlist${favlist.length}");
                                                                                  setState(() {
                                                                                    displayfavlist = favouritelist!.get("favlist") ?? [];
                                                                                  });
                                                                                } else {
                                                                                  setState(() {
                                                                                    favlist = favouritelist!.get(
                                                                                          "favlist",
                                                                                        ) ??
                                                                                        [];
                                                                                    favouritelist!.put("favlist", []);

                                                                                    favlist.add(favdata);
                                                                                    favouritelist!.put("favlist", favlist);
                                                                                    addFavourite = !addFavourite;
                                                                                  });
                                                                                  setState(() {
                                                                                    displayfavlist = favouritelist!.get("favlist") ?? [];
                                                                                  });
                                                                                }
                                                                              } else {
                                                                                setState(() {
                                                                                  favlist = favouritelist!.get(
                                                                                        "favlist",
                                                                                      ) ??
                                                                                      [];
                                                                                  favouritelist!.put("favlist", []);

                                                                                  favlist.add(favdata);
                                                                                  favouritelist!.put("favlist", favlist);
                                                                                  addFavourite = !addFavourite;
                                                                                });
                                                                                setState(() {
                                                                                  displayfavlist = favouritelist!.get("favlist") ?? [];
                                                                                });
                                                                                // print("favlistfavlist${favouritelist!.values}");
                                                                              }
                                                                            },
                                                                            icon: addFavourite == true
                                                                                ? const Icon(
                                                                                    Icons.favorite,
                                                                                    color: Colors.red,
                                                                                    size: 35,
                                                                                  )
                                                                                : Icon(
                                                                                    Icons.favorite_border_rounded,
                                                                                    color: maincolor,
                                                                                    size: 35,
                                                                                  )),
                                                                      ],
                                                                    ),

                                                                    // Slider(
                                                                    //   activeColor: Colors.white,
                                                                    //   min: 0,
                                                                    //   max: 1,
                                                                    //   onChanged: (double value) {
                                                                    //     _setVolumeValue = value;
                                                                    //     VolumeController()
                                                                    //         .setVolume(_setVolumeValue);
                                                                    //     setState(() {});
                                                                    //   },
                                                                    //   value: _setVolumeValue,
                                                                    // ),
                                                                  ],
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                height: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height *
                                                                    0.025,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    tapped == true
                                                        ? Align(
                                                            alignment: Alignment
                                                                .bottomCenter,
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(5.0),
                                                              child: InkWell(
                                                                onTap: () {},
                                                                child:
                                                                    Container(
                                                                  color: const Color
                                                                          .fromARGB(
                                                                      239,
                                                                      186,
                                                                      185,
                                                                      185),
                                                                  height: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .height *
                                                                      0.95,
                                                                  width: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .height *
                                                                      1,
                                                                  child:
                                                                      const ChatPage(),
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                        : const SizedBox(
                                                            height: 0,
                                                          ),
                                                    if (loader.value == true)
                                                      const Opacity(
                                                        opacity: 0.5,
                                                        child: ModalBarrier(
                                                            dismissible: false,
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    if (loader.value == true)
                                                      Center(
                                                        child: Container(
                                                          width: 50,
                                                          height: 50,
                                                          decoration:
                                                              const BoxDecoration(
                                                                  shape: BoxShape
                                                                      .circle),
                                                          child:
                                                              CircularProgressIndicator(
                                                            color: maincolor,
                                                            strokeWidth: 5,
                                                          ),
                                                        ),
                                                      ),
                                                  ]),
                                                );
                                              })
                                          : FutureBuilder(
                                              future: _radioPlayer
                                                  .getArtworkImage(),
                                              builder: (BuildContext context,
                                                  AsyncSnapshot snapshot) {
                                                Image artwork;
                                                if (snapshot.hasData) {
                                                  artwork = snapshot.data;
                                                } else {
                                                  artwork = Image(
                                                      image: NetworkImage(
                                                    '$imgurlOfChannel',
                                                    // fit: BoxFit.cover,
                                                  ));
                                                }
                                                return Obx(
                                                  () => Stack(children: [
                                                    Container(
                                                      color: Colors.black12,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 5.0,
                                                                left: 5,
                                                                bottom: 5),
                                                        child: Container(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width *
                                                              1,
                                                          decoration: BoxDecoration(
                                                              color: Colors.grey
                                                                  .shade200,
                                                              borderRadius:
                                                                  const BorderRadius
                                                                          .all(
                                                                      Radius.circular(
                                                                          15))),
                                                          // padding: const EdgeInsets.only(
                                                          //     bottom: 30),

                                                          // child: Text('$height, $percentage'),
                                                          child: Column(
                                                            children: [
                                                              const SizedBox(
                                                                height: 5,
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .keyboard_double_arrow_up_rounded,
                                                                size: 26,
                                                                color:
                                                                    maincolor,
                                                              ),
                                                              Row(
                                                                children: [
                                                                  const SizedBox(
                                                                    width: 20,
                                                                  ),
                                                                  Container(
                                                                    decoration:
                                                                        BoxDecoration(
                                                                            //color: Colors.yellow,
                                                                            borderRadius:
                                                                                BorderRadius.circular(10)),
                                                                    width: MediaQuery.of(context)
                                                                            .size
                                                                            .width *
                                                                        .14,
                                                                    height: MediaQuery.of(context)
                                                                            .size
                                                                            .width *
                                                                        .14,
                                                                    child:
                                                                        ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10),
                                                                      child: status !=
                                                                              'Offline'
                                                                          ? Image(
                                                                              image: NetworkImage(
                                                                                '$imgurlOfChannel',
                                                                              ),
                                                                              fit: BoxFit.fill,
                                                                            )
                                                                          : const Image(
                                                                              image: AssetImage("assets/Raydeo.ONE512.png")),
                                                                    ),
                                                                  ),
                                                                  const SizedBox(
                                                                    width: 10,
                                                                  ),

                                                                  Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Text(
                                                                        '$nameOfChannel',
                                                                        style: const TextStyle(
                                                                            fontSize:
                                                                                16,
                                                                            color:
                                                                                Colors.black),
                                                                      ),
                                                                      Text(
                                                                        '$catgOfChannel',
                                                                        style: const TextStyle(
                                                                            fontSize:
                                                                                14,
                                                                            color:
                                                                                Colors.black),
                                                                      ),

                                                                      // Text(
                                                                      //   metadata?[
                                                                      //           1] ??
                                                                      //       '',
                                                                      //   softWrap:
                                                                      //       false,
                                                                      //   overflow:
                                                                      //       TextOverflow
                                                                      //           .fade,
                                                                      //   style: const TextStyle(
                                                                      //   fontSize:
                                                                      //       16,
                                                                      //   color: Colors
                                                                      //       .white),
                                                                      // ),
                                                                    ],
                                                                  ),
                                                                  // Text(
                                                                  //   '$nameOfChannel',
                                                                  // style: const TextStyle(
                                                                  //     fontSize:
                                                                  //         16,
                                                                  //     color: Colors
                                                                  //         .white),
                                                                  // ),
                                                                  const Spacer(),
                                                                  Padding(
                                                                    padding:
                                                                        const EdgeInsets.all(
                                                                            5.0),
                                                                    child: InkWell(
                                                                        onTap: () {
                                                                          if (status !=
                                                                              'Offline') {
                                                                            miniplayerOpen.value =
                                                                                !miniplayerOpen.value;
                                                                            setState(() {
                                                                              print("tapppingggggg$isPlaying");

                                                                              isPlaying ? _radioPlayer.pause() : _radioPlayer.play();
                                                                            });
                                                                          } else {
                                                                            // _radioPlayer
                                                                            //     .stop();
                                                                            WidgetsBinding.instance.addPostFrameCallback((_) {
                                                                              // Add Your Code here.

                                                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                                                  behavior: SnackBarBehavior.floating,
                                                                                  padding: const EdgeInsets.all(5),
                                                                                  shape: const StadiumBorder(),
                                                                                  backgroundColor: const Color.fromARGB(255, 242, 242, 242),
                                                                                  duration: const Duration(seconds: 3),
                                                                                  content: Row(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: const [
                                                                                      SizedBox(
                                                                                        width: 40,
                                                                                        height: 40,
                                                                                        child: Image(image: AssetImage("assets/Raydeo.ONE512.png")),
                                                                                      ),
                                                                                      SizedBox(
                                                                                        width: 250,
                                                                                        child: Text(
                                                                                          "Please check your internet connection and try again",
                                                                                          textAlign: TextAlign.center,
                                                                                          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  )));
                                                                            });
                                                                          }
                                                                        },
                                                                        child: Container(
                                                                          height:
                                                                              50,
                                                                          width:
                                                                              50,
                                                                          decoration: BoxDecoration(
                                                                              shape: BoxShape.circle,
                                                                              color: maincolor),
                                                                          child: isPlaying
                                                                              ? loader.value == true
                                                                                  ? const Center(
                                                                                      child: CircularProgressIndicator(
                                                                                      color: Colors.black,
                                                                                    ))
                                                                                  : const Icon(
                                                                                      Icons.pause_rounded,
                                                                                      color: Colors.black,
                                                                                      size: 35,
                                                                                    )
                                                                              : const Icon(
                                                                                  Icons.play_arrow_rounded,
                                                                                  color: Colors.black,
                                                                                  size: 35,
                                                                                ),

                                                                          //  Icon(
                                                                          //     (playing.value ==
                                                                          //             true)
                                                                          //         ? Icons
                                                                          //             .pause
                                                                          //         : Icons
                                                                          //             .play_arrow_rounded,
                                                                          //     color: Colors
                                                                          //         .white,
                                                                          //     size: 45,
                                                                          //   ),
                                                                        )),
                                                                  ),
                                                                  const SizedBox(
                                                                    width: 10,
                                                                  ),
                                                                ],
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    // if (loader.value == true)
                                                    //   const Opacity(
                                                    //     opacity: 0.5,
                                                    //     child: ModalBarrier(
                                                    //         dismissible: false,
                                                    //         color: Colors.white),
                                                    //   ),
                                                    // if (loader.value == true)
                                                    //   Center(
                                                    //     child: Container(
                                                    //       width: 50,
                                                    //       height: 50,
                                                    //       decoration:
                                                    //           const BoxDecoration(
                                                    //               shape: BoxShape
                                                    //                   .circle),
                                                    //       child:
                                                    //           const CircularProgressIndicator(
                                                    //         color: Colors.blue,
                                                    //         strokeWidth: 5,
                                                    //       ),
                                                    //     ),
                                                    //   ),
                                                  ]),
                                                );
                                              })),
                                ))
                        : const SizedBox(
                            height: 0,
                          ),
                  ],
                ),
              );
            }),
      ),
    );
  }

  updateCurrentStatus(status) {
    frpStatus = status;
  }

  getSortedChannels(j) {
    try {
      bool checkPieOpenClose = (closeRest.contains(j)) ? true : false;
      return ExpansionWidget(
        onSaveState: (isExpanded) => checkPieOpenClose = isExpanded,
        onExpansionChanged: (value) {
          if (value == true) {
            setState(() {
              closeRest = [];
              closeRest.add(j);
            });
          }
        },
        onRestoreState: () => checkPieOpenClose,
        maintainState: true,
        duration: const Duration(milliseconds: 350),
        // initiallyExpanded:
        //     (jsonDecode(widget.decodedItem['description']).length == 1)
        //         ? true
        //         : false,
        titleBuilder:
            (animationValue, easeInValue, isExpanded, toggleFunction) {
          return GestureDetector(
            onTap: () {
              toggleFunction(animated: true);
            },
            child: Container(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(
                  Radius.circular(5),
                ),
                color: Colors.white,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
              child: Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "${categorylist[j]}",
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                  ),
                  // Transform.rotate(
                  //   angle: math.pi * animationValue + 1.55,
                  //   alignment: Alignment.center,
                  //   child: const Icon(
                  //     Icons.arrow_forward_ios,
                  //     size: 18,
                  //     color: Colors.black,
                  //   ),
                  // ),
                ],
              ),
            ),
          );
        },
        content: categorylist[j] == "Favourites"
            ? displayfavlist.isNotEmpty
                ? Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(
                          Radius.circular(5),
                        ),
                        color: Colors.white),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                    child: Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 1,
                          height: MediaQuery.of(context).size.height * 0.22,
                          child: ListView.builder(
                            padding: const EdgeInsets.all(0),
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                            itemCount: displayfavlist.length,
                            itemBuilder: (context, index) {
                              //print("checkk:${alldata[index]} ${categorylist[j]}");
                              return Container(
                                // color: Colors.amber,
                                // margin: const EdgeInsets.only(right: 1),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        if (status != 'Offline') {
                                          if (idOfChannel.isNotEmpty)
                                            await MQTTConnections()
                                                .unsubscribeToChannel(
                                                    "$idOfChannel");

                                          Mqtt.firsttime!.value = false;
                                          controllerStack.animateToHeight(
                                              state: PanelState.MAX,
                                              duration: const Duration(
                                                  milliseconds: 30));
                                          loader.value = true;
                                          Future.delayed(
                                              const Duration(seconds: 3), () {
                                            setState(() {
                                              loader.value = false;
                                            });
                                          });

                                          print("currentindx:$currentindx");
                                          favdata = displayfavlist[index];

                                          nameOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_name"];
                                          descOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_description"];
                                          catgOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_category"];
                                          idOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_id"];
                                          urlOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_stream_url"];
                                          imgurlOfChannel.value =
                                              displayfavlist[index]
                                                  ["channel_image_url"];
                                          subcount = 1.obs;
                                          // startminiplayerOpen(urlOfChannel);
                                          Future.delayed(
                                              const Duration(seconds: 2));
                                          var qwe = await MQTTConnections()
                                              .MQTTSubscribeMethod(
                                                  "$idOfChannel");
                                          _radioPlayer.stop();
                                          if (displayfavlist.isNotEmpty) {
                                            for (int i = 0;
                                                i < displayfavlist.length;
                                                i++) {
                                              if (displayfavlist[i]
                                                      ["channel_id"]
                                                  .toString()
                                                  .contains(idOfChannel)) {
                                                setState(() {
                                                  addFavourite = true;
                                                });
                                                break;
                                              } else {
                                                setState(() {
                                                  addFavourite = false;
                                                });
                                              }
                                            }
                                          }
                                          print("spdata:${idOfChannel}");
                                          print("favdfgdcg:${displayfavlist}");
                                          Future.delayed(
                                              const Duration(seconds: 2));

                                          final SharedPreferences
                                              sharedPreferences =
                                              await SharedPreferences
                                                  .getInstance();

                                          print(
                                              "spdata:${sharedPreferences.getString('device_id')} ");

                                          Future.delayed(
                                              const Duration(seconds: 5),
                                              () {});
                                          var resp = await MQTTConnections()
                                              .getChannelDetails(
                                                  "$idOfChannel");
                                          print(
                                              "spdata:${resp["total_number_of_subscribers"]}name${resp["channel_id"]}");
                                          // subcount.value =
                                          //     resp["total_number_of_subscribers"];
                                          print("tacsvvdcvaadcad");
                                          await _radioPlayer.setChannel(
                                            title: '$nameOfChannel',
                                            url: '$urlOfChannel',
                                            imagePath: '$imgurlOfChannel',
                                          );
                                          Future.delayed(
                                              const Duration(milliseconds: 10),
                                              () {
                                            _radioPlayer.play();
                                          });

                                          _radioPlayer.stateStream
                                              .listen((value) {
                                            print("sdgxcfhjbkn:$value");
                                            setState(() {
                                              isPlaying = value;
                                            });
                                          });

                                          _radioPlayer.metadataStream
                                              .listen((value) {
                                            setState(() {
                                              metadata = value;
                                            });
                                          });

                                          print(
                                              "nameOfChannel:${nameOfChannel}");
                                          print("idOfChannel:${idOfChannel}");
                                          print(
                                              "descOfChannel:${descOfChannel}");
                                          print(
                                              "firsttime:${Mqtt.firsttime!.value}");
                                        } else {
                                          // _radioPlayer
                                          //     .stop();
                                          WidgetsBinding.instance
                                              .addPostFrameCallback((_) {
                                            // Add Your Code here.

                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(SnackBar(
                                                    behavior: SnackBarBehavior
                                                        .floating,
                                                    padding:
                                                        const EdgeInsets.all(5),
                                                    shape:
                                                        const StadiumBorder(),
                                                    backgroundColor:
                                                        const Color.fromARGB(
                                                            255, 242, 242, 242),
                                                    duration: const Duration(
                                                        seconds: 3),
                                                    content: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: const [
                                                        SizedBox(
                                                          width: 40,
                                                          height: 40,
                                                          child: Image(
                                                              image: AssetImage(
                                                                  "assets/Raydeo.ONE512.png")),
                                                        ),
                                                        SizedBox(
                                                          width: 250,
                                                          child: Text(
                                                            "Please check your internet connection and try again",
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                fontSize: 14),
                                                          ),
                                                        )
                                                      ],
                                                    )));
                                          });
                                        }
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                .3,
                                        height:
                                            MediaQuery.of(context).size.height *
                                                .129,
                                        padding: const EdgeInsets.all(0),
                                        alignment: Alignment.center,
                                        decoration: const BoxDecoration(
                                            // border: Border.all(
                                            //     color: Colors.blueGrey, width: 1),
                                            // image: DecorationImage(
                                            //   image: NetworkImage(
                                            //       "${alldata[index]['channel_image_url']}"),
                                            // ),

                                            borderRadius: BorderRadius.all(
                                                Radius.circular(15))),
                                        child: Card(
                                          elevation: 5,
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(15))),
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(12.0),
                                            child: status != 'Offline'
                                                ? Image.network(
                                                    "${displayfavlist[index]['channel_image_url']}")
                                                : const Image(
                                                    image: AssetImage(
                                                        "assets/Raydeo.ONE512.png")),
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          .26,
                                      child: Column(
                                        children: [
                                          Text(
                                            "${displayfavlist[index]['channel_name']}",
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(
                                                color: Colors.black,
                                                fontSize: 12),
                                          ),
                                          Text(
                                            "${displayfavlist[index]['channel_category']}",
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(
                                                color: Colors.black,
                                                fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  )
                : Container(
                    color: Colors.white,
                    height: MediaQuery.of(context).size.height * 0.22,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.favorite_rounded,
                            color: maincolor,
                            size: 45,
                          ),
                          const Text(
                            "There's no favourite channels yet?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const Text(
                            "Add some...!",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  )
            : Container(
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(5),
                    ),
                    color: Colors.white),
                padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 5),
                child: Column(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 1,
                      height: MediaQuery.of(context).size.height * 0.22,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(0),
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: alldata.length,
                        itemBuilder: (context, index) {
                          //print("checkk:${alldata[index]} ${categorylist[j]}");
                          return (alldata[index]['channel_category']
                                  .contains(categorylist[j]))
                              ? Container(
                                  // color: Colors.amber,
                                  // margin: const EdgeInsets.only(right: 1),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      InkWell(
                                        onTap: () async {
                                          if (status != 'Offline') {
                                            if (idOfChannel.isNotEmpty)
                                              print(
                                                  "idOfChannelunsub:${idOfChannel}");

                                            await MQTTConnections()
                                                .unsubscribeToChannel(
                                                    "$idOfChannel");

                                            Mqtt.firsttime!.value = false;
                                            controllerStack.animateToHeight(
                                                state: PanelState.MAX,
                                                duration: const Duration(
                                                    milliseconds: 30));
                                            loader.value = true;
                                            Future.delayed(
                                                const Duration(seconds: 3), () {
                                              setState(() {
                                                loader.value = false;
                                              });
                                            });

                                            print("currentindx:$currentindx");
                                            favdata = alldata[index];

                                            nameOfChannel.value =
                                                alldata[index]["channel_name"];
                                            descOfChannel.value = alldata[index]
                                                ["channel_description"];
                                            catgOfChannel.value = alldata[index]
                                                ["channel_category"];
                                            idOfChannel.value =
                                                alldata[index]["channel_id"];
                                            urlOfChannel.value = alldata[index]
                                                ["channel_stream_url"];
                                            imgurlOfChannel.value =
                                                alldata[index]
                                                    ["channel_image_url"];
                                            subcount = 1.obs;
                                            // startminiplayerOpen(urlOfChannel);
                                            Future.delayed(
                                                const Duration(seconds: 2));
                                            var qwe = await MQTTConnections()
                                                .MQTTSubscribeMethod(
                                                    "$idOfChannel");
                                            _radioPlayer.stop();
                                            if (favlist.isNotEmpty) {
                                              for (int i = 0;
                                                  i < favlist.length;
                                                  i++) {
                                                if (favlist[i]["channel_id"]
                                                    .toString()
                                                    .contains(idOfChannel)) {
                                                  setState(() {
                                                    addFavourite = true;
                                                  });
                                                  break;
                                                } else {
                                                  setState(() {
                                                    addFavourite = false;
                                                  });
                                                }
                                              }
                                            }
                                            print("spdata:${idOfChannel}");
                                            print(
                                                "favdfgdcg:${displayfavlist}");
                                            Future.delayed(
                                                const Duration(seconds: 2));

                                            final SharedPreferences
                                                sharedPreferences =
                                                await SharedPreferences
                                                    .getInstance();

                                            print(
                                                "spdata:${sharedPreferences.getString('device_id')} ");

                                            Future.delayed(
                                                const Duration(seconds: 5),
                                                () {});
                                            var resp = await MQTTConnections()
                                                .getChannelDetails(
                                                    "$idOfChannel");
                                            print(
                                                "spdata:${resp["total_number_of_subscribers"]}name${resp["channel_id"]}");
                                            // subcount.value =
                                            //     resp["total_number_of_subscribers"];
                                            print("tacsvvdcvaadcad");
                                            await _radioPlayer.setChannel(
                                              title: '$nameOfChannel',
                                              url: '$urlOfChannel',
                                              imagePath: '$imgurlOfChannel',
                                            );
                                            Future.delayed(
                                                const Duration(
                                                    milliseconds: 10), () {
                                              _radioPlayer.play();
                                            });

                                            _radioPlayer.stateStream
                                                .listen((value) {
                                              print("sdgxcfhjbkn:$value");
                                              setState(() {
                                                isPlaying = value;
                                              });
                                            });

                                            _radioPlayer.metadataStream
                                                .listen((value) {
                                              setState(() {
                                                metadata = value;
                                              });
                                            });

                                            print(
                                                "nameOfChannel:${nameOfChannel}");
                                            print("idOfChannel:${idOfChannel}");
                                            print(
                                                "descOfChannel:${descOfChannel}");
                                            print(
                                                "firsttime:${Mqtt.firsttime!.value}");
                                          } else {
                                            // _radioPlayer
                                            //     .stop();
                                            WidgetsBinding.instance
                                                .addPostFrameCallback((_) {
                                              // Add Your Code here.

                                              ScaffoldMessenger.of(context)
                                                  .showSnackBar(SnackBar(
                                                      behavior: SnackBarBehavior
                                                          .floating,
                                                      padding:
                                                          const EdgeInsets.all(
                                                              5),
                                                      shape:
                                                          const StadiumBorder(),
                                                      backgroundColor:
                                                          const Color.fromARGB(
                                                              255,
                                                              242,
                                                              242,
                                                              242),
                                                      duration: const Duration(
                                                          seconds: 3),
                                                      content: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: const [
                                                          SizedBox(
                                                            width: 40,
                                                            height: 40,
                                                            child: Image(
                                                                image: AssetImage(
                                                                    "assets/Raydeo.ONE512.png")),
                                                          ),
                                                          SizedBox(
                                                            width: 250,
                                                            child: Text(
                                                              "Please check your internet connection and try again",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontSize: 14),
                                                            ),
                                                          )
                                                        ],
                                                      )));
                                            });
                                          }
                                        },
                                        child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              .3,
                                          height: MediaQuery.of(context)
                                                  .size
                                                  .height *
                                              .129,
                                          padding: const EdgeInsets.all(0),
                                          alignment: Alignment.center,
                                          decoration: const BoxDecoration(
                                              // border: Border.all(
                                              //     color: Colors.blueGrey, width: 1),
                                              // image: DecorationImage(
                                              //   image: NetworkImage(
                                              //       "${alldata[index]['channel_image_url']}"),
                                              // ),

                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(15))),
                                          child: Card(
                                            elevation: 5,
                                            shape: const RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(15))),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(12.0),
                                              child: status != 'Offline'
                                                  ? Image.network(
                                                      "${alldata[index]['channel_image_url']}")
                                                  : const Image(
                                                      image: AssetImage(
                                                          "assets/Raydeo.ONE512.png")),
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                .26,
                                        child: Column(
                                          children: [
                                            Text(
                                              "${alldata[index]['channel_name']}",
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 12),
                                            ),
                                            Text(
                                              "${alldata[index]['channel_category']}",
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 12),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : const SizedBox(
                                  height: 0,
                                );
                        },
                      ),
                    ),
                  ],
                ),
              ),
      );
    } catch (e) {
      print("pie error$e");
      return const Text("NO Data");
    }
  }
}

// if (miniplayerOpen.value != null)
//   Miniplayer(
//       controller: controllerStack,
//       backgroundColor: bgColor,
//       minHeight: 120,
//       maxHeight: MediaQuery.of(context).size.height * 1,
//       builder: (height, percentage) {
//         print("percentage:$percentage");
//         if (percentage > 0.2) {
//           return GestureDetector(
//             child: FittedBox(
//                 child: Container(
//               width: MediaQuery.of(context).size.width * 1,
//               height: MediaQuery.of(context).size.height * 1,
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   begin: Alignment.bottomCenter,
//                   end: Alignment.topCenter,
//                   colors: [
//                     Colors.black.withOpacity(0.9),
//                     Colors.black.withOpacity(0.7),
//                     Colors.black.withOpacity(0.5),
//                     Colors.black.withOpacity(0.3),
//                   ],
//                 ),
//               ),
//               child: Center(
//                 child: musicplayer(
//                     widget.frpSource,
//                     flutterRadioPlayer,
//                     addSourceFunction,
//                     context,
//                     updateCurrentStatus,
//                     setState),
//               ),
//             )),
//           );
//         } else {
//           return minimusic(widget.frpSource, flutterRadioPlayer,
//               addSourceFunction, updateCurrentStatus, setState);
//         }
//       }),
// if (miniplayerOpen.value != null)
//   firsttime != true
//       ? Miniplayer(
//           elevation: 0,
//           controller: controllerStack,
//           backgroundColor: Colors.purple,
//           minHeight: 110,
//           maxHeight: MediaQuery.of(context).size.height * 1,
// builder: (height, percentage) {
//   print("percentage:$percentage");
//   if (percentage > 0.2) {
//     return GestureDetector(
//       // onTap: () {
//       //   print("sddddddddddddddddddd");
//       //   miniplayerOpen.value =
//       //       !miniplayerOpen.value;
// controllerStack.animateToHeight(
//     state: PanelState.MIN,
//     duration:
//         const Duration(milliseconds: 500));
//       //   minimusic(
//       //       widget.frpSource,
//       //       flutterRadioPlayer,
//       //       addSourceFunction,
//       //       updateCurrentStatus,
//       //       setState);
//       // },
//       // onVerticalDragDown: (DragDownDetails) {
//       //   miniplayerOpen.value =
//       //       !miniplayerOpen.value;
//       //   print("123456");
//       //   minimusic(
//       //       widget.frpSource,
//       //       flutterRadioPlayer,
//       //       addSourceFunction,
//       //       updateCurrentStatus,
//       //       setState);
//       // },
//       child: FittedBox(
//           child: Container(
//         width: MediaQuery.of(context).size.width * 1,
//         height: MediaQuery.of(context).size.height * 1,
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.bottomCenter,
//             end: Alignment.topCenter,
//             colors: [
//               Colors.black.withOpacity(0.9),
//               Colors.black.withOpacity(0.7),
//               Colors.black.withOpacity(0.5),
//               Colors.black.withOpacity(0.3),
//             ],
//           ),
//         ),
//         child: Center(
//           child: musicplayer(
//               widget.frpSource,
//               widget.flutterRadioPlayers,
//               addSourceFunction,
//               context,
//               updateCurrentStatus,
//               setState),
//         ),
//       )),
//     );
//   } else {
//     return minimusic(
//         widget.frpSource,
//         widget.flutterRadioPlayers,
//         addSourceFunction,
//         updateCurrentStatus,
//         setState);
//   }
// }

//           //  ClipRect(
//           //   child: BackdropFilter(
//           //     filter: ui.ImageFilter.blur(
//           //       sigmaX: 20.0,
//           //       sigmaY: 20.0,
//           //     ),
//           //     child: (height != 110)
//           //         ? GestureDetector(
//           //             // onTap: () {
//           //             //   print("sddddddddddddddddddd");
//           //             //   miniplayerOpen.value =
//           //             //       !miniplayerOpen.value;
//           //             //   controllerStack.animateToHeight(
//           //             //       state: PanelState.MIN,
//           //             //       duration:
//           //             //           const Duration(milliseconds: 500));
//           //             //   minimusic(
//           //             //       widget.frpSource,
//           //             //       flutterRadioPlayer,
//           //             //       addSourceFunction,
//           //             //       updateCurrentStatus,
//           //             //       setState);
//           //             // },
//           //             // onVerticalDragDown: (DragDownDetails) {
//           //             //   miniplayerOpen.value =
//           //             //       !miniplayerOpen.value;
//           //             //   print("123456");
//           //             //   minimusic(
//           //             //       widget.frpSource,
//           //             //       flutterRadioPlayer,
//           //             //       addSourceFunction,
//           //             //       updateCurrentStatus,
//           //             //       setState);
//           //             // },
//           //             child: FittedBox(
//           //                 child: Container(
//           //               width:
//           //                   MediaQuery.of(context).size.width * 1,
//           //               height:
//           //                   MediaQuery.of(context).size.height * 1,
//           //               decoration: BoxDecoration(
//           //                 gradient: LinearGradient(
//           //                   begin: Alignment.bottomCenter,
//           //                   end: Alignment.topCenter,
//           //                   colors: [
//           //                     Colors.black.withOpacity(0.9),
//           //                     Colors.black.withOpacity(0.7),
//           //                     Colors.black.withOpacity(0.5),
//           //                     Colors.black.withOpacity(0.3),
//           //                   ],
//           //                 ),
//           //               ),
//           //               child: Center(
//           //                 child: musicplayer(
//           //                     widget.frpSource,
//           //                     widget.flutterRadioPlayers,
//           //                     addSourceFunction,
//           //                     context,
//           //                     updateCurrentStatus,
//           //                     setState),
//           //               ),
//           //             )),
//           //           )
//           //         : minimusic(
//           //             widget.frpSource,
//           //             widget.flutterRadioPlayers,
//           //             addSourceFunction,
//           //             updateCurrentStatus,
//           //             setState),
//           //   ),
//           // ),
//           )
//       : SizedBox(
//           height: 0,
//         ),
// if (loadingdata == true)
//   const Opacity(
//     opacity: 0.5,
//     child: ModalBarrier(
//         dismissible: false, color: Colors.white),
//   ),
// if (loadingdata == true)
//   Center(
//     child: Container(
//       width: 50,
//       height: 50,
//       decoration:
//           const BoxDecoration(shape: BoxShape.circle),
//       child: const CircularProgressIndicator(
//         color: Colors.blue,
//         strokeWidth: 5,
//       ),
//     ),
//   ),

// startminiplayerOpen() async {
//   playing.value = true;
//   //print("playing..$urlOfChannel");
//   widget.flutterRadioPlayers.playOrPause();
//   resetNowPlayingInfo();
// }

// stopminiplayerOpen() {
//   playing.value = false;
//   widget.flutterRadioPlayers.stop();
//   resetNowPlayingInfo();
// }

// getlocationname() async {
//   final SharedPreferences sharedPreferences =
//       await SharedPreferences.getInstance();
//   List<Placemark> addresses = await placemarkFromCoordinates(2.11, 21.0);
//   Placemark placeMark = addresses[0];
//   String? name = placeMark.name;
//   String? subLocality = placeMark.subLocality;
//   String? locality = placeMark.locality;
//   String? administrativeArea = placeMark.administrativeArea;
//   String? postalCode = placeMark.postalCode;
//   String? country = placeMark.country;
//   String address =
//       "${name}, ${subLocality}, ${locality}, ${administrativeArea} ${postalCode}, ${country}";
//   print('MY ADDRESSSSSSSS${address}');
//   print(addresses);

//   var first = addresses.first;
//   print("${first.name} : ${first..administrativeArea}");
//   sharedPreferences.setString('address', subLocality!);
// }
