import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_player_event.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:get/get.dart';
import 'package:raydeo_one/widgets/chatpage.dart';
import 'package:volume_controller/volume_controller.dart';

import '../landingpages/homepage.dart';
import '../main.dart';
import 'minimusic.dart';

double _setVolumeValue = 0;

Widget musicplayer(FRPSource frpSource, FlutterRadioPlayer flutterRadioPlayer,
    addSourceFunction, context, updateCurrentStatus, setState) {
  String latestPlaybackStatus = "flutter_radio_stopped";

  double volume = 0.5;
  final nowPlayingTextController = TextEditingController();
  return StreamBuilder(
    stream: flutterRadioPlayer.frpEventStream,
    builder: (context, snapshot) {
      // FRPPlayerEvents frpEvent =
      //     FRPPlayerEvents.fromJson(jsonDecode(snapshot.data as String));
      // if (kDebugMode) {
      //   print("====== EVENT START =====");
      //   print("Playback status: ${frpEvent.playbackStatus}");
      //   print("Icy details: ${frpEvent.icyMetaDetails}");
      //   print("Other: ${frpEvent.data}");
      //   print("====== EVENT END =====");
      // }
      // if (frpEvent.playbackStatus != null) {
      //   latestPlaybackStatus = frpEvent.playbackStatus!;
      //   updateCurrentStatus(latestPlaybackStatus);
      // }
      // if (frpEvent.icyMetaDetails != null) {
      //   currentPlaying.value = frpEvent.icyMetaDetails!;
      //   nowPlayingTextController.text = frpEvent.icyMetaDetails!;
      // }
      // var statusIcon = const Icon(
      //   Icons.pause_circle_filled,
      //   size: 45,
      //   color: Colors.white,
      // );
      // switch (frpEvent.playbackStatus) {
      //   case "flutter_radio_playing":
      //     statusIcon = const Icon(
      //       Icons.pause_circle_filled,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      //   case "flutter_radio_paused":
      //     statusIcon = const Icon(
      //       Icons.play_circle_filled,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      //   case "flutter_radio_loading":
      //     statusIcon = const Icon(
      //       Icons.refresh_rounded,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      //   case "flutter_radio_stopped":
      //     statusIcon = const Icon(
      //       Icons.play_circle_filled,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      // }
      return Obx(() => Stack(
            children: [
              InkWell(
                onTap: () {
                  tapped.value = false;
                  print("tapppppppeddddd");
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 1,
                  height: MediaQuery.of(context).size.height * 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(
                        Icons.keyboard_double_arrow_down_rounded,
                        size: 45,
                        color: Colors.white,
                      ),
                      Text(
                        "$nameOfChannel",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          InkWell(
                            onTap: () {
                              // _dialogBuilder(context);
                              print("tapped");
                              tapped.value = true;
                            },
                            child: Column(
                              children: [
                                Icon(
                                  Icons.chat_sharp,
                                  size: 35,
                                  color: Colors.white,
                                ),
                                Text(
                                  "Live Chat",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white),
                                )
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: () {},
                            child: Column(
                              children: [
                                Icon(
                                  Icons.keyboard_voice_rounded,
                                  size: 35,
                                  color: Colors.white,
                                ),
                                Text(
                                  "Detect Audio",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                      Stack(
                        children: [
                          Center(
                            child: Container(
                              decoration: BoxDecoration(
                                  color: bgColor,
                                  borderRadius: BorderRadius.circular(20)),
                              width: MediaQuery.of(context).size.width * .8,
                              height: MediaQuery.of(context).size.width * .8,
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.black38,
                                  borderRadius: BorderRadius.circular(20)),
                              margin: EdgeInsets.only(
                                  left: MediaQuery.of(context).size.width * 0.7,
                                  right:
                                      MediaQuery.of(context).size.width * 0.1),
                              child: Padding(
                                padding: const EdgeInsets.all(2.0),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.remove_red_eye,
                                      color: Colors.white,
                                    ),
                                    Text(
                                      " ${currentindx}",
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(20)),
                        width: MediaQuery.of(context).size.width * .85,
                        height: MediaQuery.of(context).size.height * .15,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                                padding: const EdgeInsets.all(1.0),
                                child: (snapshot.hasData)
                                    ? IconButton(
                                        onPressed: () async {
                                          //play.value = !play.value;

                                          flutterRadioPlayer.playOrPause();
                                          resetNowPlayingInfo();
                                        },
                                        icon: Icon(snapshot.data!.contains(
                                                "flutter_radio_paused")
                                            ? Icons.play_arrow_rounded
                                            : Icons
                                                .pause_circle_filled_rounded),
                                        iconSize: 45,
                                        color: Colors.white,
                                      )
                                    : IconButton(
                                        onPressed: () async {
                                          onplay.value = !onplay.value;

                                          flutterRadioPlayer.playOrPause();
                                          resetNowPlayingInfo();
                                        },
                                        icon: Icon(
                                            Icons.pause_circle_filled_rounded),
                                        iconSize: 45,
                                        color: Colors.white,
                                      )),
                            // Padding(
                            //   padding: const EdgeInsets.all(2.0),
                            //   child: IconButton(
                            //     onPressed: () async {
                            //       play.value = !play.value;
                            //       flutterRadioPlayer.playOrPause();
                            // resetNowPlayingInfo();
                            //     },
                            //     icon: Icon(play == false
                            //         ? Icons.pause_circle_filled_rounded
                            //         : Icons.play_arrow_rounded),
                            // iconSize: 45,
                            // color: Colors.white,
                            //   ),
                            // ),
                            Slider(
                              activeColor: Colors.white,
                              min: 0,
                              max: 1,
                              onChanged: (double value) {
                                _setVolumeValue = value;
                                VolumeController().setVolume(_setVolumeValue);
                                setState(() {});
                              },
                              value: _setVolumeValue,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              tapped == true
                  ? Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: InkWell(
                          onTap: () {},
                          child: Container(
                            color: Color.fromARGB(239, 186, 185, 185),
                            height: MediaQuery.of(context).size.height * 0.88,
                            width: MediaQuery.of(context).size.height * 1,
                            child: ChatPage(),
                          ),
                        ),
                      ),
                    )
                  : SizedBox(
                      height: 0,
                    )
              // if (frpEvent.playbackStatus == "flutter_radio_loading")
              //   const Opacity(
              //     opacity: 0.5,
              //     child: ModalBarrier(dismissible: false, color: Colors.white),
              //   ),
              // if (frpEvent.playbackStatus == "flutter_radio_loading")
              //   Center(
              //     child: Container(
              //       width: 50,
              //       height: 50,
              //       decoration: const BoxDecoration(shape: BoxShape.circle),
              //       child: CircularProgressIndicator(
              //         color: Colors.blue,
              //         strokeWidth: 5,
              //       ),
              //     ),
              //   ),
            ],
          ));
      // : Center(
      //     child: CircularProgressIndicator(),
      //   );
      // }
      // return SizedBox(
      //   height: 0,
      // );
    },
  );
}

Future<void> _dialogBuilder(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        // title: const Text('RadioOne Live Chat'),
        content: Container(
          height: MediaQuery.of(context).size.height * 0.5,
          color: Colors.black45,
          child: const Text(
            'A dialog is a type of modal window that\n'
            'appears in front of app content to\n'
            'provide critical information, or prompt\n'
            'for a decision to be made.',
            textAlign: TextAlign.justify,
          ),
        ),
        actions: <Widget>[
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              // mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Container(
                        padding: EdgeInsets.only(
                          left: 10,
                          bottom: 10,
                        ),
                        height: 60,
                        width: double.infinity,
                        color: Colors.white,
                        child: Row(
                          children: <Widget>[
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                  color: Colors.lightBlue,
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Icon(
                                  Icons.insert_emoticon,
                                  color: Colors.white,
                                  size: 25,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            Expanded(
                              child: TextField(
                                decoration: InputDecoration(
                                    hintText: "Write message...",
                                    hintStyle: TextStyle(color: Colors.black54),
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: BorderSide(
                                          width: 2,
                                          color: Colors.black,
                                        ))),
                              ),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            FloatingActionButton(
                              onPressed: () {},
                              child: Icon(
                                Icons.send,
                                color: Colors.white,
                                size: 18,
                              ),
                              backgroundColor: Colors.green,
                              elevation: 0,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      );
    },
  );
}

void resetNowPlayingInfo() {
  currentPlaying.value = "";
}
