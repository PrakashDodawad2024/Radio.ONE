import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_player_event.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:get/get.dart';
import 'package:miniplayer/miniplayer.dart';
import 'dart:math' as math;
import '../landingpages/homepage.dart';
import '../main.dart';

Widget minimusic(FRPSource frpSource, FlutterRadioPlayer flutterRadioPlayer,
    addSourceFunction, updateCurrentStatus, setState) {
  String latestPlaybackStatus = "flutter_radio_stopped";
  print("bncajc");
  double volume = 0.5;
  final nowPlayingTextController = TextEditingController();
  return StreamBuilder(
    stream: flutterRadioPlayer.frpEventStream,
    builder: (context, snapshot) {
      if (kDebugMode) {
        final decoded = jsonDecode("${snapshot.data}");
        print("stream:${snapshot.data}");
        print("decoded:${decoded["currentSource"]["title"]}");
      }

      // FRPPlayerEvents frpEvent =
      //     FRPPlayerEvents.fromJson(jsonDecode(snapshot.data as String));
      // if (kDebugMode) {
      //   print("====== EVENT START =====");
      //   print("Playback status: ${frpEvent.playbackStatus}");
      //   print("Icy details: ${frpEvent.icyMetaDetails}");
      //   print("Other: ${frpEvent.data}");
      //   print("====== EVENT END =====");
      // }
      // if (frpEvent.playbackStatus != null) {
      //   latestPlaybackStatus = frpEvent.playbackStatus!;
      //   updateCurrentStatus(latestPlaybackStatus);
      // }
      // if (frpEvent.icyMetaDetails != null) {
      //   currentPlaying.value = frpEvent.icyMetaDetails!;
      //   nowPlayingTextController.text = frpEvent.icyMetaDetails!;
      // }
      // var statusIcon = const Icon(
      //   Icons.pause_circle_filled,
      //   size: 45,
      //   color: Colors.white,
      // );
      // switch (frpEvent.playbackStatus) {
      //   case "flutter_radio_playing":
      //     statusIcon = const Icon(
      //       Icons.pause_circle_filled,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      //   case "flutter_radio_paused":
      //     statusIcon = const Icon(
      //       Icons.play_circle_filled,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      //   case "flutter_radio_loading":
      //     statusIcon = const Icon(
      //       Icons.refresh_rounded,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      //   case "flutter_radio_stopped":
      //     statusIcon = const Icon(
      //       Icons.play_circle_filled,
      //       size: 45,
      //       color: Colors.white,
      //     );
      //     break;
      // }

      return
          // snapshot.hasData
          // frpEvent.playbackStatus == "flutter_radio_playing" ||
          //         frpEvent.playbackStatus == "flutter_radio_paused" ||
          //         frpEvent.playbackStatus == "flutter_radio_stopped"
          // ?
          //   Obx(
          // () =>
          Stack(
        children: [
          InkWell(
            onTap: () {
              miniplayerOpen.value = !miniplayerOpen.value;
              controllerStack.animateToHeight(
                  state: PanelState.MAX,
                  duration: const Duration(milliseconds: 500));
            },
            child: Container(
              height: 110,
              //color: Colors.yellow,
              child: Column(
                children: [
                  Container(
                    //  padding: EdgeInsets.only(bottom: 30),
                    color: Colors.grey.shade800.withOpacity(0.5),
                    // child: Text('$height, $percentage'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const Icon(
                          Icons.keyboard_double_arrow_up_rounded,
                          size: 30,
                          color: Colors.blueGrey,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              const SizedBox(
                                width: 20,
                              ),
                              Container(
                                height: 55,
                                width: 55,
                                color: Color(
                                        (math.Random().nextDouble() * 0xFFFFFF)
                                            .toInt())
                                    .withOpacity(1.0),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Obx(
                                () => Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.45,
                                      child: Text(
                                        "${nameOfChannel}",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    //  Text("$descOfChannel"),
                                  ],
                                ),
                              ),
                              const Spacer(),
                              Padding(
                                  padding: const EdgeInsets.all(1.0),
                                  child: (snapshot.hasData)
                                      ? IconButton(
                                          onPressed: () async {
                                            //play.value = !play.value;
                                            flutterRadioPlayer.playOrPause();
                                            resetNowPlayingInfo();
                                          },
                                          icon: Icon(snapshot.data!.contains(
                                                  "flutter_radio_paused")
                                              ? Icons.play_arrow_rounded
                                              : Icons
                                                  .pause_circle_filled_rounded),
                                          iconSize: 40,
                                          color: Colors.white,
                                        )
                                      : IconButton(
                                          onPressed: () async {
                                            onplay.value = !onplay.value;
                                            flutterRadioPlayer.playOrPause();
                                            resetNowPlayingInfo();
                                          },
                                          icon: Icon(Icons
                                              .pause_circle_filled_rounded),
                                          iconSize: 40,
                                          color: Colors.white,
                                        )),
                              const SizedBox(
                                width: 20,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          // if (frpEvent.playbackStatus == "flutter_radio_loading")
          //   const Opacity(
          //     opacity: 0.5,
          //     child: ModalBarrier(dismissible: false, color: Colors.white),
          //   ),
          // if (frpEvent.playbackStatus == "flutter_radio_loading")
          //   Center(
          //     child: Container(
          //       width: 50,
          //       height: 50,
          //       decoration: const BoxDecoration(shape: BoxShape.circle),
          //       child: CircularProgressIndicator(
          //         color: Colors.blue,
          //         strokeWidth: 5,
          //       ),
          //     ),
          //   ),
        ],
      );
      // );
      // : Center(
      //     child: CircularProgressIndicator(
      //       color: Colors.black,
      //     ),
      //   );

      // return SizedBox(
      //   height: 60,
      //   child: Text("test"),
      // );
    },
  );
}

void resetNowPlayingInfo() {
  currentPlaying.value = "";
}
