import 'dart:convert';
import 'dart:math' as math;
import 'dart:math';
import 'dart:ui' as ui;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:volume_controller/volume_controller.dart';
import '../backgroundplay/frp_player.dart';
import '../backgroundplay/mainplay.dart';
import '../main.dart';
import '../mqtt/mqttconnection.dart';
import '../mqtt/mqttregister.dart';
import '../widgets/allchannel.dart';
import '../widgets/chatpage.dart';
import '../widgets/minimusic.dart';
import '../widgets/musicplayer.dart';

final controllerStack = MiniplayerController();
RxBool miniplayerOpen = false.obs;
RxBool loader = false.obs;
int currentindex = 0;
RxBool miniplayerOpened = false.obs;

RxBool playing = false.obs;

class MyHomePage extends StatefulWidget {
  final FlutterRadioPlayer flutterRadioPlayers;
  final FRPSource frpSource;
  final bool useIcyData;

  const MyHomePage({
    Key? key,
    required this.flutterRadioPlayers,
    required this.frpSource,
    required this.useIcyData,
  }) : super(key: key);
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    AudioPlayer.global.setGlobalAudioContext(_getAudioContext());
    widget.flutterRadioPlayers.useIcyData(widget.useIcyData);
    print("categories:$categorylist");
    //  connectmqtt();
  }

  connectmqtt() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var connectionDetail =
        await jsonDecode("${sharedPreferences.getString('allconnectionData')}");
    print(
        "connectionDetailconnectionDetail:${sharedPreferences.getString('allconnectionData')}");
    await MQTTConnections().connectToMQTTMethod(
        connectionDetail['ip_address'],
        connectionDetail['port'],
        connectionDetail['user_name'],
        connectionDetail['password']);
  }

  int currentIndex = 0;
  String frpStatus = "flutter_radio_stopped";
  static final AudioPlayer _player = AudioPlayer();
  double _volumeListenerValue = 0;
  double _getVolume = 0;

  @override
  void dispose() {
    VolumeController().removeListener();
    super.dispose();
  }

  AudioContext _getAudioContext() {
    return const AudioContext(
        android: AudioContextAndroid(
          isSpeakerphoneOn: false,
          stayAwake: true,
          contentType: AndroidContentType.music,
          usageType: AndroidUsageType.media,
          audioFocus: AndroidAudioFocus.gain,
        ),
        iOS: AudioContextIOS(
            category: AVAudioSessionCategory.soloAmbient,
            options: [
              // AVAudioSessionOptions.defaultToSpeaker,
            ]
            // +
            // [AVAudioSessionOptions.allowAirPlay] +
            // [AVAudioSessionOptions.allowBluetooth] +
            // [AVAudioSessionOptions.allowBluetoothA2DP]
            ));
  }

  startminiplayerOpen(url) {
    playing.value = true;
    _player.play(UrlSource('$url'));
  }

  stopminiplayerOpen() {
    playing.value = false;
    _player.stop();
  }

  getSegregatedLists() {
    print("segrerrere");
    return Obx(
      () => SingleChildScrollView(
        child: Column(
          children: [
            for (int j = 0; j < categorylist.length; j++)
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 20),
                    width: MediaQuery.of(context).size.width * 1,
                    child: Text(
                      "${categorylist[j]}",
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.bold),
                      textAlign: TextAlign.start,
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 1,
                    height: MediaQuery.of(context).size.height * 0.24,
                    //  color: Colors.green.withOpacity(0.5),
                    child: ListView.builder(
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemCount: alldata.length,
                      itemBuilder: (context, index) {
                        // print("checkk:${alldata[index]} ${categorylist[j]}");
                        return (alldata[index]['channel_category']
                                .contains(categorylist[j]))
                            ? Stack(
                                children: [
                                  InkWell(
                                    onTap: () async {
                                      if (idOfChannel != "") {
                                        await MQTTConnections()
                                            .MQTTUnSubscribeMethod(
                                                "$idOfChannel");
                                        controllerStack.animateToHeight(
                                            state: PanelState.MAX,
                                            duration: const Duration(
                                                milliseconds: 500));
                                      }
                                      controllerStack.animateToHeight(
                                          state: PanelState.MAX,
                                          duration: const Duration(
                                              milliseconds: 500));
                                      loader.value = true;
                                      Future.delayed(const Duration(seconds: 3),
                                          () {
                                        setState(() {
                                          loader.value = false;
                                        });
                                      });

                                      print("called");
                                      print(
                                          "channel_id:${alldata[index]["channel_id"]}");
                                      print(
                                          "channel_namesss:${alldata[index]["channel_name"]}");
                                      // if (play.value == true)
                                      onplay.value = false;
                                      currentindex = index;
                                      currentindx = alldata[index]
                                          ["total_number_of_subscribers"];
                                      //selected = allmedia[index].description!;
                                      print(
                                          "mediaItem.description:${selected}");
                                      // flutterRadioPlayer
                                      //     .addMediaSources(widget.frpSource);
                                      // flutterRadioPlayer.seekToMediaSource(
                                      //     index, true);
                                      // flutterRadioPlayer.useIcyData(true);
                                      // miniplayerOpen.value =
                                      //     !miniplayerOpen.value;

                                      Mqtt.firsttime!.value = false;
                                      nameOfChannel.value =
                                          alldata[index]["channel_name"];
                                      descOfChannel.value =
                                          alldata[index]["channel_description"];
                                      idOfChannel.value =
                                          alldata[index]["channel_id"];
                                      urlOfChannel.value =
                                          alldata[index]["channel_stream_url"];
                                      imgurlOfChannel.value =
                                          alldata[index]["channel_image_url"];
                                      startminiplayerOpen(urlOfChannel);
                                      await MQTTConnections()
                                          .MQTTSubscribeMethod(
                                              "${alldata[index]["channel_id"]}");

                                      print(
                                          "frpSources:${widget.frpSource.mediaSources!.isEmpty}");
                                      print("nameOfChannel:${nameOfChannel}");
                                      print("descOfChannel:${descOfChannel}");
                                      print(
                                          "firsttime:${Mqtt.firsttime!.value}");

                                      // ontapchannel();
                                      // } else {
                                      //   await MQTTConnections()
                                      //       .MQTTSubscribeMethod(
                                      //           "${alldata[index]["channel_id"]}");

                                      //   print("called");
                                      //   print(
                                      //       "channel_id:${alldata[index]["channel_id"]}");
                                      //   print(
                                      //       "channel_namesss:${alldata[index]["channel_name"]}");
                                      //   // if (play.value == true)
                                      //   onplay.value = false;
                                      //   currentindex = index;
                                      //   currentindx = alldata[index]
                                      //       ["total_number_of_subscribers"];
                                      //   //selected = allmedia[index].description!;
                                      //   print(
                                      //       "mediaItem.description:${selected}");
                                      //   // flutterRadioPlayer
                                      //   //     .addMediaSources(widget.frpSource);
                                      //   // flutterRadioPlayer.seekToMediaSource(
                                      //   //     index, true);
                                      //   // flutterRadioPlayer.useIcyData(true);
                                      //   miniplayerOpen.value =
                                      //       !miniplayerOpen.value;

                                      //   firsttime.value = false;
                                      //   nameOfChannel.value =
                                      //       alldata[index]["channel_name"];
                                      //   descOfChannel.value = alldata[index]
                                      //       ["channel_description"];
                                      //   idOfChannel.value =
                                      //       alldata[index]["channel_id"];
                                      //   urlOfChannel.value = alldata[index]
                                      //       ["channel_stream_url"];
                                      //   imgurlOfChannel.value =
                                      //       alldata[index]["channel_image_url"];
                                      //   startminiplayerOpen(urlOfChannel);

                                      //   print(
                                      //       "frpSources:${widget.frpSource.mediaSources!.isEmpty}");
                                      //   print("nameOfChannel:${nameOfChannel}");
                                      //   print("descOfChannel:${descOfChannel}");
                                      //   print("firsttime:${firsttime}");

                                      //   controllerStack.animateToHeight(
                                      //       state: PanelState.MAX,
                                      //       duration: const Duration(
                                      //           milliseconds: 500));
                                      // }
                                    },
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          .35,
                                      height:
                                          MediaQuery.of(context).size.height *
                                              .24,
                                      margin: const EdgeInsets.all(8),
                                      // padding: const EdgeInsets.all(5),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          // color: Color(
                                          //         (math.Random().nextDouble() *
                                          //                 0xFFFFFF)
                                          //             .toInt())
                                          //     .withOpacity(1.0),
                                          borderRadius:
                                              BorderRadius.circular(15)),
                                      child: Image(
                                        image: NetworkImage(
                                            "${alldata[index]['channel_image_url']}"),
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                  // Align(
                                  //   alignment: Alignment.topRight,
                                  //   child: Container(
                                  //     width: 75,
                                  //     height: 35,
                                  //     decoration: BoxDecoration(
                                  //         color: Colors.black38,
                                  //         borderRadius:
                                  //             BorderRadius.circular(20)),
                                  //     margin: EdgeInsets.only(
                                  //         left: MediaQuery.of(context)
                                  //                 .size
                                  //                 .width *
                                  //             0.28,
                                  //         top: MediaQuery.of(context)
                                  //                 .size
                                  //                 .width *
                                  //             0.045),
                                  //     child: Center(
                                  //       child: Padding(
                                  //         padding: const EdgeInsets.all(2.0),
                                  //         child: Row(
                                  //           children: [
                                  //             const Icon(
                                  //               Icons.remove_red_eye,
                                  //               color: Colors.white,
                                  //             ),
                                  //             Text(
                                  //               " ${alldata[index]["total_number_of_subscribers"]}",
                                  //               style: const TextStyle(
                                  //                   color: Colors.white),
                                  //             ),
                                  //           ],
                                  //         ),
                                  //       ),
                                  //     ),
                                  //   ),
                                  // ),
                                ],
                              )
                            : const SizedBox(
                                height: 0,
                              );
                      },
                    ),
                  ),
                ],
              ),
            if (Mqtt.firsttime!.value == false)
              const SizedBox(
                height: 130,
              )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: ValueListenableBuilder(
          valueListenable: allmessages!.listenable(),
          builder: (context, value, child) {
            final allresponse = allmessages!.get("allmessages");
            print("allresponvvbvbse$allresponse");
            if (allresponse != null) {
              final decodeddata = jsonDecode(allresponse["channel_message"]);
              final alldecodeddata = jsonDecode(decodeddata["description"]);
              // print("alldecodeddata${alldecodeddata}");
              alldata = alldecodeddata;
              print("alldaddddta$alldata");
              // if (alldata.length != 0) {
              print("segregating alldata");
              for (int i = 0; i < alldata.length; i++) {
                if (!categorylist.contains(alldata[i]["channel_category"])) {
                  categorylist.add(alldata[i]["channel_category"]);
                  print("categorylist$categorylist");
                }
              }
              // print("tapped${alldata.contains("$idOfChannel")}");
              // if (alldata.contains("$idOfChannel")) {
              //   // print("tappedcontaines:$tapped");

              //   Mqtt.firsttime!.value = false;

              //   print("tappedcontaines:$tapped");
              // } else {
              //   print("tappedcoes$idOfChannel");
              //   // print("beforeeeee:$tapped");
              //   Mqtt.firsttime!.value = true;
              //   print("tappeddoesnt:$tapped");
              // }
            }

            return MiniplayerWillPopScope(
              onWillPop: () async {
                return false;
              },
              child: Obx(
                () => Stack(
                  children: <Widget>[
                    Container(
                      height: MediaQuery.of(context).size.height * 1,
                      padding: const EdgeInsets.only(top: 30),
                      color: Color.fromARGB(255, 50, 50, 50),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(
                                  height: 45,
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 20, right: 20),
                                  width: MediaQuery.of(context).size.width * 1,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'Radio One',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 38,
                                            fontWeight: FontWeight.bold),
                                        textAlign: TextAlign.start,
                                      ),
                                      const Spacer(),
                                      GestureDetector(
                                        onTap: () {
                                          // Navigator.of(context).push(MaterialPageRoute(
                                          //   builder: (context) => playback(),
                                          // ));
                                        },
                                        child: const Icon(
                                          Icons.radio,
                                          color: Colors.white,
                                          size: 60,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Container(
                                    height: miniplayerOpen.value != null
                                        ? MediaQuery.of(context).size.height *
                                                1 -
                                            160
                                        : 120,
                                    child: (categorylist.isNotEmpty)
                                        ? getSegregatedLists()
                                        : const Center(
                                            child: CircularProgressIndicator(),
                                          )),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Mqtt.firsttime!.value == false
                        ? Miniplayer(
                            controller: controllerStack,
                            backgroundColor: bgColor,
                            minHeight: 120,
                            maxHeight: MediaQuery.of(context).size.height * 1,
                            builder: (height, percentage) => ClipRect(
                                child: (height != 120)
                                    ? Obx(
                                        () => Stack(children: [
                                          InkWell(
                                            onTap: () {
                                              tapped.value = false;
                                              print("tapppppppeddddd");
                                              controllerStack.animateToHeight(
                                                  state: PanelState.MIN,
                                                  duration: const Duration(
                                                      milliseconds: 500));
                                            },
                                            child: FittedBox(
                                              child: Container(
                                                height: MediaQuery.of(context)
                                                        .size
                                                        .height *
                                                    1,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    1,
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    begin:
                                                        Alignment.bottomCenter,
                                                    end: Alignment.topCenter,
                                                    colors: [
                                                      Colors.black
                                                          .withOpacity(0.9),
                                                      Colors.black
                                                          .withOpacity(0.7),
                                                      Colors.black
                                                          .withOpacity(0.5),
                                                      Colors.black
                                                          .withOpacity(0.3),
                                                    ],
                                                  ),
                                                ),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    const Icon(
                                                      Icons
                                                          .keyboard_double_arrow_down_rounded,
                                                      size: 45,
                                                      color: Colors.white,
                                                    ),
                                                    // Text(
                                                    //   "$nameOfChannel",
                                                    //   textAlign:
                                                    //       TextAlign.center,
                                                    //   style: const TextStyle(
                                                    //       fontSize: 25,
                                                    //       fontWeight:
                                                    //           FontWeight.bold,
                                                    //       color: Colors.white),
                                                    // ),
                                                    // Row(
                                                    //   mainAxisAlignment:
                                                    //       MainAxisAlignment
                                                    //           .spaceAround,
                                                    //   children: [
                                                    //     InkWell(
                                                    //       onTap: () {
                                                    //         // _dialogBuilder(context);
                                                    //         print("tapped");
                                                    //         tapped.value = true;
                                                    //       },
                                                    //       child: Column(
                                                    //         children: const [
                                                    //           Icon(
                                                    //             Icons
                                                    //                 .chat_sharp,
                                                    //             size: 35,
                                                    //             color: Colors
                                                    //                 .white,
                                                    //           ),
                                                    //           Text(
                                                    //             "Live Chat",
                                                    //             style: TextStyle(
                                                    //                 fontSize:
                                                    //                     18,
                                                    //                 fontWeight:
                                                    //                     FontWeight
                                                    //                         .bold,
                                                    //                 color: Colors
                                                    //                     .white),
                                                    //           )
                                                    //         ],
                                                    //       ),
                                                    //     ),
                                                    //     InkWell(
                                                    //       onTap: () {},
                                                    //       child: Column(
                                                    //         children: const [
                                                    //           Icon(
                                                    //             Icons
                                                    //                 .keyboard_voice_rounded,
                                                    //             size: 35,
                                                    //             color: Colors
                                                    //                 .white,
                                                    //           ),
                                                    //           Text(
                                                    //             "Detect Audio",
                                                    //             style: TextStyle(
                                                    //                 fontSize:
                                                    //                     18,
                                                    //                 fontWeight:
                                                    //                     FontWeight
                                                    //                         .bold,
                                                    //                 color: Colors
                                                    //                     .white),
                                                    //           )
                                                    //         ],
                                                    //       ),
                                                    //     ),
                                                    //   ],
                                                    // ),
                                                    Text(
                                                      '$nameOfChannel',
                                                      style: const TextStyle(
                                                          fontSize: 25,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.white),
                                                    ),
                                                    Stack(
                                                      children: [
                                                        Align(
                                                          alignment:
                                                              Alignment.center,
                                                          child: Container(
                                                            decoration:
                                                                BoxDecoration(
                                                                    //color: Colors.yellow,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            20)),
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width *
                                                                .8,
                                                            height: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width *
                                                                .8,
                                                            child: Image(
                                                              image: NetworkImage(
                                                                  "$imgurlOfChannel"),
                                                              fit: BoxFit.fill,
                                                            ),
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment:
                                                              Alignment.center,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                                color: Colors
                                                                    .black38,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            20)),
                                                            margin: EdgeInsets.only(
                                                                left: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.7,
                                                                right: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.1),
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(2.0),
                                                              child: Row(
                                                                children: [
                                                                  const Icon(
                                                                    Icons
                                                                        .remove_red_eye,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                  Text(
                                                                    " ${currentindx}",
                                                                    style: const TextStyle(
                                                                        color: Colors
                                                                            .white),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors.black
                                                              .withOpacity(0.5),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      20)),
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              .85,
                                                      height:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .height *
                                                              .15,
                                                      child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          InkWell(
                                                            onTap: () {
                                                              if (playing
                                                                      .value ==
                                                                  true) {
                                                                stopminiplayerOpen();
                                                              } else {
                                                                startminiplayerOpen(
                                                                    urlOfChannel);
                                                                loader.value =
                                                                    true;
                                                                Future.delayed(
                                                                    const Duration(
                                                                        seconds:
                                                                            3),
                                                                    () {
                                                                  setState(() {
                                                                    loader.value =
                                                                        false;
                                                                  });
                                                                });
                                                              }
                                                            },
                                                            child: Obx(
                                                              () => Icon(
                                                                (playing.value ==
                                                                        true)
                                                                    ? Icons
                                                                        .pause
                                                                    : Icons
                                                                        .play_arrow_rounded,
                                                                color: Colors
                                                                    .white,
                                                                size: 60,
                                                              ),
                                                            ),
                                                          ),
                                                          // Slider(
                                                          //   activeColor: Colors.white,
                                                          //   min: 0,
                                                          //   max: 1,
                                                          //   onChanged: (double value) {
                                                          //     _setVolumeValue = value;
                                                          //     VolumeController()
                                                          //         .setVolume(_setVolumeValue);
                                                          //     setState(() {});
                                                          //   },
                                                          //   value: _setVolumeValue,
                                                          // ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          tapped == true
                                              ? Align(
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            5.0),
                                                    child: InkWell(
                                                      onTap: () {},
                                                      child: Container(
                                                        color: const Color
                                                                .fromARGB(
                                                            239, 186, 185, 185),
                                                        height: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .height *
                                                            0.95,
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .height *
                                                            1,
                                                        child: const ChatPage(),
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              : const SizedBox(
                                                  height: 0,
                                                ),
                                          if (loader.value == true)
                                            const Opacity(
                                              opacity: 0.5,
                                              child: ModalBarrier(
                                                  dismissible: false,
                                                  color: Colors.white),
                                            ),
                                          if (loader.value == true)
                                            Center(
                                              child: Container(
                                                width: 50,
                                                height: 50,
                                                decoration: const BoxDecoration(
                                                    shape: BoxShape.circle),
                                                child:
                                                    CircularProgressIndicator(
                                                  color: Colors.blue,
                                                  strokeWidth: 5,
                                                ),
                                              ),
                                            ),
                                        ]),
                                      )
                                    : Stack(children: [
                                        Container(
                                          padding:
                                              const EdgeInsets.only(bottom: 30),
                                          color: Colors.grey.shade800
                                              .withOpacity(0.5),
                                          // child: Text('$height, $percentage'),
                                          child: Column(
                                            children: [
                                              const Icon(
                                                Icons
                                                    .keyboard_double_arrow_up_rounded,
                                                size: 30,
                                                color: Colors.blueGrey,
                                              ),
                                              Row(
                                                children: [
                                                  const SizedBox(
                                                    width: 20,
                                                  ),
                                                  Container(
                                                    height: 55,
                                                    width: 55,
                                                    // color: Colors.purple,
                                                    child: Image(
                                                      image: NetworkImage(
                                                          "$imgurlOfChannel"),
                                                      fit: BoxFit.fill,
                                                    ),
                                                  ),
                                                  const SizedBox(
                                                    width: 10,
                                                  ),
                                                  Text(
                                                    '$nameOfChannel',
                                                    style: const TextStyle(
                                                        fontSize: 16,
                                                        color: Colors.white),
                                                  ),
                                                  const Spacer(),
                                                  InkWell(
                                                    onTap: () {
                                                      miniplayerOpen.value =
                                                          !miniplayerOpen.value;
                                                      if (playing.value ==
                                                          true) {
                                                        stopminiplayerOpen();
                                                      } else {
                                                        startminiplayerOpen(
                                                            urlOfChannel);
                                                        loader.value = true;
                                                        Future.delayed(
                                                            const Duration(
                                                                seconds: 3),
                                                            () {
                                                          setState(() {
                                                            loader.value =
                                                                false;
                                                          });
                                                        });
                                                      }
                                                    },
                                                    child: Obx(
                                                      () => Icon(
                                                        (playing.value == true)
                                                            ? Icons.pause
                                                            : Icons
                                                                .play_arrow_rounded,
                                                        color: Colors.white,
                                                        size: 55,
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        if (loader.value == true)
                                          const Opacity(
                                            opacity: 0.5,
                                            child: ModalBarrier(
                                                dismissible: false,
                                                color: Colors.white),
                                          ),
                                        if (loader.value == true)
                                          Center(
                                            child: Container(
                                              width: 50,
                                              height: 50,
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle),
                                              child:
                                                  const CircularProgressIndicator(
                                                color: Colors.blue,
                                                strokeWidth: 5,
                                              ),
                                            ),
                                          ),
                                      ])),
                          )
                        : const SizedBox(
                            height: 0,
                          ),
                  ],
                ),
              ),
            );
          }),
    );
  }

  addSourceFunction() {
    return widget.flutterRadioPlayers.addMediaSources(widget.frpSource);
  }

  updateCurrentStatus(status) {
    frpStatus = status;
  }

  ontapplay() {}

  void resetNowPlayingInfo() {
    currentPlaying.value = "";
  }

  ontapchannel() {
    setState(() {
      bgColor = Color((math.Random().nextDouble() * 0xFFFFFF).toInt())
          .withOpacity(1.0);
      print("startminiplayerOpen");
      widget.flutterRadioPlayers.addMediaSources(widget.frpSource);
      print("ontapchannelhomme${widget.frpSource.mediaSources!.length}");

      loader.value = true;
      Future.delayed(const Duration(seconds: 3), () {
        setState(() {
          loader.value = false;
        });
      });
    });
    controllerStack.animateToHeight(
        state: PanelState.MAX, duration: const Duration(milliseconds: 500));
  }
}
                    // if (miniplayerOpen.value != null)
                    //   Miniplayer(
                    //       controller: controllerStack,
                    //       backgroundColor: bgColor,
                    //       minHeight: 120,
                    //       maxHeight: MediaQuery.of(context).size.height * 1,
                    //       builder: (height, percentage) {
                    //         print("percentage:$percentage");
                    //         if (percentage > 0.2) {
                    //           return GestureDetector(
                    //             child: FittedBox(
                    //                 child: Container(
                    //               width: MediaQuery.of(context).size.width * 1,
                    //               height: MediaQuery.of(context).size.height * 1,
                    //               decoration: BoxDecoration(
                    //                 gradient: LinearGradient(
                    //                   begin: Alignment.bottomCenter,
                    //                   end: Alignment.topCenter,
                    //                   colors: [
                    //                     Colors.black.withOpacity(0.9),
                    //                     Colors.black.withOpacity(0.7),
                    //                     Colors.black.withOpacity(0.5),
                    //                     Colors.black.withOpacity(0.3),
                    //                   ],
                    //                 ),
                    //               ),
                    //               child: Center(
                    //                 child: musicplayer(
                    //                     widget.frpSource,
                    //                     flutterRadioPlayer,
                    //                     addSourceFunction,
                    //                     context,
                    //                     updateCurrentStatus,
                    //                     setState),
                    //               ),
                    //             )),
                    //           );
                    //         } else {
                    //           return minimusic(widget.frpSource, flutterRadioPlayer,
                    //               addSourceFunction, updateCurrentStatus, setState);
                    //         }
                    //       }),
                    // if (miniplayerOpen.value != null)
                    //   firsttime != true
                    //       ? Miniplayer(
                    //           elevation: 0,
                    //           controller: controllerStack,
                    //           backgroundColor: Colors.purple,
                    //           minHeight: 110,
                    //           maxHeight: MediaQuery.of(context).size.height * 1,
                    // builder: (height, percentage) {
                    //   print("percentage:$percentage");
                    //   if (percentage > 0.2) {
                    //     return GestureDetector(
                    //       // onTap: () {
                    //       //   print("sddddddddddddddddddd");
                    //       //   miniplayerOpen.value =
                    //       //       !miniplayerOpen.value;
                    // controllerStack.animateToHeight(
                    //     state: PanelState.MIN,
                    //     duration:
                    //         const Duration(milliseconds: 500));
                    //       //   minimusic(
                    //       //       widget.frpSource,
                    //       //       flutterRadioPlayer,
                    //       //       addSourceFunction,
                    //       //       updateCurrentStatus,
                    //       //       setState);
                    //       // },
                    //       // onVerticalDragDown: (DragDownDetails) {
                    //       //   miniplayerOpen.value =
                    //       //       !miniplayerOpen.value;
                    //       //   print("123456");
                    //       //   minimusic(
                    //       //       widget.frpSource,
                    //       //       flutterRadioPlayer,
                    //       //       addSourceFunction,
                    //       //       updateCurrentStatus,
                    //       //       setState);
                    //       // },
                    //       child: FittedBox(
                    //           child: Container(
                    //         width: MediaQuery.of(context).size.width * 1,
                    //         height: MediaQuery.of(context).size.height * 1,
                    //         decoration: BoxDecoration(
                    //           gradient: LinearGradient(
                    //             begin: Alignment.bottomCenter,
                    //             end: Alignment.topCenter,
                    //             colors: [
                    //               Colors.black.withOpacity(0.9),
                    //               Colors.black.withOpacity(0.7),
                    //               Colors.black.withOpacity(0.5),
                    //               Colors.black.withOpacity(0.3),
                    //             ],
                    //           ),
                    //         ),
                    //         child: Center(
                    //           child: musicplayer(
                    //               widget.frpSource,
                    //               widget.flutterRadioPlayers,
                    //               addSourceFunction,
                    //               context,
                    //               updateCurrentStatus,
                    //               setState),
                    //         ),
                    //       )),
                    //     );
                    //   } else {
                    //     return minimusic(
                    //         widget.frpSource,
                    //         widget.flutterRadioPlayers,
                    //         addSourceFunction,
                    //         updateCurrentStatus,
                    //         setState);
                    //   }
                    // }

                    //           //  ClipRect(
                    //           //   child: BackdropFilter(
                    //           //     filter: ui.ImageFilter.blur(
                    //           //       sigmaX: 20.0,
                    //           //       sigmaY: 20.0,
                    //           //     ),
                    //           //     child: (height != 110)
                    //           //         ? GestureDetector(
                    //           //             // onTap: () {
                    //           //             //   print("sddddddddddddddddddd");
                    //           //             //   miniplayerOpen.value =
                    //           //             //       !miniplayerOpen.value;
                    //           //             //   controllerStack.animateToHeight(
                    //           //             //       state: PanelState.MIN,
                    //           //             //       duration:
                    //           //             //           const Duration(milliseconds: 500));
                    //           //             //   minimusic(
                    //           //             //       widget.frpSource,
                    //           //             //       flutterRadioPlayer,
                    //           //             //       addSourceFunction,
                    //           //             //       updateCurrentStatus,
                    //           //             //       setState);
                    //           //             // },
                    //           //             // onVerticalDragDown: (DragDownDetails) {
                    //           //             //   miniplayerOpen.value =
                    //           //             //       !miniplayerOpen.value;
                    //           //             //   print("123456");
                    //           //             //   minimusic(
                    //           //             //       widget.frpSource,
                    //           //             //       flutterRadioPlayer,
                    //           //             //       addSourceFunction,
                    //           //             //       updateCurrentStatus,
                    //           //             //       setState);
                    //           //             // },
                    //           //             child: FittedBox(
                    //           //                 child: Container(
                    //           //               width:
                    //           //                   MediaQuery.of(context).size.width * 1,
                    //           //               height:
                    //           //                   MediaQuery.of(context).size.height * 1,
                    //           //               decoration: BoxDecoration(
                    //           //                 gradient: LinearGradient(
                    //           //                   begin: Alignment.bottomCenter,
                    //           //                   end: Alignment.topCenter,
                    //           //                   colors: [
                    //           //                     Colors.black.withOpacity(0.9),
                    //           //                     Colors.black.withOpacity(0.7),
                    //           //                     Colors.black.withOpacity(0.5),
                    //           //                     Colors.black.withOpacity(0.3),
                    //           //                   ],
                    //           //                 ),
                    //           //               ),
                    //           //               child: Center(
                    //           //                 child: musicplayer(
                    //           //                     widget.frpSource,
                    //           //                     widget.flutterRadioPlayers,
                    //           //                     addSourceFunction,
                    //           //                     context,
                    //           //                     updateCurrentStatus,
                    //           //                     setState),
                    //           //               ),
                    //           //             )),
                    //           //           )
                    //           //         : minimusic(
                    //           //             widget.frpSource,
                    //           //             widget.flutterRadioPlayers,
                    //           //             addSourceFunction,
                    //           //             updateCurrentStatus,
                    //           //             setState),
                    //           //   ),
                    //           // ),
                    //           )
                    //       : SizedBox(
                    //           height: 0,
                    //         ),
                    // if (loadingdata == true)
                    //   const Opacity(
                    //     opacity: 0.5,
                    //     child: ModalBarrier(
                    //         dismissible: false, color: Colors.white),
                    //   ),
                    // if (loadingdata == true)
                    //   Center(
                    //     child: Container(
                    //       width: 50,
                    //       height: 50,
                    //       decoration:
                    //           const BoxDecoration(shape: BoxShape.circle),
                    //       child: const CircularProgressIndicator(
                    //         color: Colors.blue,
                    //         strokeWidth: 5,
                    //       ),
                    //     ),
                    //   ),
    
  // startminiplayerOpen() async {
  //   playing.value = true;
  //   //print("playing..$urlOfChannel");
  //   widget.flutterRadioPlayers.playOrPause();
  //   resetNowPlayingInfo();
  // }

  // stopminiplayerOpen() {
  //   playing.value = false;
  //   widget.flutterRadioPlayers.stop();
  //   resetNowPlayingInfo();
  // }

 
  // getlocationname() async {
  //   final SharedPreferences sharedPreferences =
  //       await SharedPreferences.getInstance();
  //   List<Placemark> addresses = await placemarkFromCoordinates(2.11, 21.0);
  //   Placemark placeMark = addresses[0];
  //   String? name = placeMark.name;
  //   String? subLocality = placeMark.subLocality;
  //   String? locality = placeMark.locality;
  //   String? administrativeArea = placeMark.administrativeArea;
  //   String? postalCode = placeMark.postalCode;
  //   String? country = placeMark.country;
  //   String address =
  //       "${name}, ${subLocality}, ${locality}, ${administrativeArea} ${postalCode}, ${country}";
  //   print('MY ADDRESSSSSSSS${address}');
  //   print(addresses);

  //   var first = addresses.first;
  //   print("${first.name} : ${first..administrativeArea}");
  //   sharedPreferences.setString('address', subLocality!);
  // }

