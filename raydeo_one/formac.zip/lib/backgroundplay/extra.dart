// [5:23 pm, 14/04/2023] Rehaan Bro Mobil80: import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:dio/dio.dart';
// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter_shazam_kit/flutter_shazam_kit.dart';
// import 'package:flutter_shazam_kit/models/detecting_state.dart';
// import 'package:get/get.dart';
// import 'package:miniplayer/miniplayer.dart';
// import 'package:volume_controller/volume_controller.dart';
// import '../main.dart';
// import 'dart:ui' as ui;

// class RadioApp extends StatefulWidget {
//   RadioApp();
//   @override
//   _RadioAppState createState() => _RadioAppState();
// }

// class _RadioAppState extends State<RadioApp> {
//   bool _isPlaying = false;
//   bool detecting = false;

//   final _flutterShazamKitPlugin = FlutterShazamKit();
//   DetectState _state =…
// [5:43 pm, 14/04/2023] Rehaan Bro Mobil80: import 'dart:math';

// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_shazam_kit/flutter_shazam_kit.dart';
// import 'package:get/get.dart';
// import 'package:miniplayer/miniplayer.dart';
// import 'dart:ui' as ui;

// import 'package:volume_controller/volume_controller.dart';

// class MyHomePage extends StatefulWidget {
//   @override
//   State<MyHomePage> createState() => _MyHomePageState();
// }

// class _MyHomePageState extends State<MyHomePage> {
//   RxBool miniplayerOpen = false.obs;
//   RxBool playing = false.obs;

//   final controllerStack = MiniplayerController();

//   Color bgColor = Colors.purple;

//   final _random = new Random();

//   static final AudioPlayer _player = AudioPlayer();

//   double _volumeListenerValue = 0;
//   double _getVolume = 0;
//   double _setVolumeValue = 0;

//   final _flutterShazamKitPlugin = FlutterShazamKit();

// // generate a random index based on the list length
//   final titleList = [
//     'Top Picks',
//     'Recently Listened to',
//     'International',
//     'Hindi Stations'
//   ];

//   List stationNames = [
//     {"name": 'Radio Mirchi', "color": Colors.red},
//     {"name": 'BBC Radio One', "color": Colors.amber},
//     {"name": 'Tropical Beats FM', "color": Colors.purple},
//     {"name": 'Fever FM', "color": Colors.green},
//   ];

//   List stationNames1 = [
//     {"name": 'R&B FM', "color": Colors.brown},
//     {"name": 'Big FM', "color": Colors.cyan},
//     {"name": 'Jazz FM', "color": Colors.white},
//     {"name": 'All India Radio', "color": Colors.red},
//   ];

//   List stationNames2 = [
//     {"name": 'Radio One', "color": Colors.blue},
//     {"name": 'Hip-Hop Beats FM', "color": Colors.pink},
//     {"name": 'BBC Radio One', "color": Colors.green},
//     {"name": 'Red FM', "color": Colors.brown},
//   ];

//   List stationNames3 = [
//     {"name": 'Radio City', "color": Colors.indigo},
//     {"name": 'Hit FM', "color": Colors.yellow},
//     {"name": 'Soho Radio', "color": Colors.teal},
//     {"name": 'Worldwide FM', "color": Colors.brown},
//   ];

//   @override
//   void initState() {
//     // AudioPlayer.global.setGlobalAudioContext(_getAudioContext());
//     // VolumeController().listener((volume) {
//     //   setState(() => _volumeListenerValue = volume);
//     // });

//     // _flutterShazamKitPlugin.configureShazamKitSession().then((value) {
//     //   // startDetection();
//     //   _flutterShazamKitPlugin.onMatchResultDiscovered((result) {
//     //     if (result is Matched) {
//     //       print(result.mediaItems);
//     //       // setState(() {
//     //       //   _mediaItems.insertAll(0, result.mediaItems);
//     //       // });
//     //     } else if (result is NoMatch) {}
//     //   });
//     //   _flutterShazamKitPlugin.onDetectStateChanged((state) {
//     //     setState(() {
//     //       // _state = state;
//     //     });
//     //   });
//     //   _flutterShazamKitPlugin.onError((error) {
//     //     print(error.message);
//     //   });
//     // });

//     // VolumeController().getVolume().then((volume) => _setVolumeValue = volume);
//     // TODO: implement initState
//     super.initState();
//   }

//   @override
//   void dispose() {
//     VolumeController().removeListener();
//     super.dispose();
//   }

//   startDetection() {
//     _flutterShazamKitPlugin.startDetectionWithMicrophone();
//   }

//   AudioContext _getAudioContext() {
//     return AudioContext(
//         android: AudioContextAndroid(
//           isSpeakerphoneOn: false,
//           stayAwake: true,
//           contentType: AndroidContentType.music,
//           usageType: AndroidUsageType.media,
//           audioFocus: AndroidAudioFocus.gain,
//         ),
//         iOS: AudioContextIOS(
//             category: AVAudioSessionCategory.soloAmbient,
//             options: [
//               // AVAudioSessionOptions.defaultToSpeaker,
//             ]
//             // +
//             // [AVAudioSessionOptions.allowAirPlay] +
//             // [AVAudioSessionOptions.allowBluetooth] +
//             // [AVAudioSessionOptions.allowBluetoothA2DP]
//             ));
//   }

//   startminiplayerOpen() {
//     playing.value = true;
//     _player
//         .play(UrlSource('http://stream.live.vc.bbcmedia.co.uk/bbc_radio_one'));

//     startDetection();
//   }

//   stopminiplayerOpen() {
//     playing.value = false;
//     _player.stop();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MiniplayerWillPopScope(
//       onWillPop: () async {
//         //  NavigatorState navigator = _navigatorKey.currentState;
//         // if (!navigator.canPop()) return true;
//         // navigator.pop();

//         return false;
//       },
//       child: Obx(
//         () => Scaffold(
//           body: Stack(
//             children: <Widget>[
//               Container(
//                 padding: EdgeInsets.only(top: 30),
//                 color: Colors.black,
//                 height: MediaQuery.of(context).size.height * 1,
//                 child: SingleChildScrollView(
//                   child: Column(
//                     children: [
//                       for (int i = 0; i < 4; i++)
//                         Column(mainAxisSize: MainAxisSize.min, children: [
//                           if (i == 0)
//                             SizedBox(
//                               height: 50,
//                             ),
//                           if (i == 0)
//                             Container(
//                               margin: EdgeInsets.only(left: 20),
//                               width: MediaQuery.of(context).size.width * 1,
//                               child: Text(
//                                 'Radio One',
//                                 style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 38,
//                                     fontWeight: FontWeight.bold),
//                                 textAlign: TextAlign.start,
//                               ),
//                             ),
//                           SizedBox(
//                             height: 20,
//                           ),
//                           Container(
//                             margin: EdgeInsets.only(left: 20),
//                             width: MediaQuery.of(context).size.width * 1,
//                             child: Text(
//                               '${titleList[i]}',
//                               style: TextStyle(
//                                   color: Colors.white,
//                                   fontSize: 25,
//                                   fontWeight: FontWeight.bold),
//                               textAlign: TextAlign.start,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 10,
//                           ),
//                           Container(
//                             margin: EdgeInsets.only(left: 10),
//                             height: MediaQuery.of(context).size.height * .2,
//                             child: ListView.builder(
//                                 shrinkWrap: true,
//                                 scrollDirection: Axis.horizontal,
//                                 itemCount: 4,
//                                 itemBuilder: (BuildContext ctx, index) {
//                                   return InkWell(
//                                     onTap: () {
//                                       // startminiplayerOpen();
//                                       setState(() {
//                                         bgColor = (i == 0)
//                                             ? (stationNames[index]['color'])
//                                             : (i == 1)
//                                                 ? (stationNames1[index]
//                                                     ['color'])
//                                                 : (i == 2)
//                                                     ? (stationNames2[index]
//                                                         ['color'])
//                                                     : (stationNames3[index]
//                                                         ['color']);
//                                       });

//                                       controllerStack.animateToHeight(
//                                           state: PanelState.MAX,
//                                           duration:
//                                               Duration(milliseconds: 500));
//                                     },
//                                     child: Container(
//                                       width: MediaQuery.of(context).size.width *
//                                           .4,
//                                       margin: EdgeInsets.all(8),
//                                       padding: EdgeInsets.all(5),
//                                       alignment: Alignment.center,
//                                       decoration: BoxDecoration(
//                                           color: (i == 0)
//                                               ? (stationNames[index]['color'])
//                                               : (i == 1)
//                                                   ? (stationNames1[index]
//                                                       ['color'])
//                                                   : (i == 2)
//                                                       ? (stationNames2[index]
//                                                           ['color'])
//                                                       : (stationNames3[index]
//                                                           ['color']),
//                                           borderRadius:
//                                               BorderRadius.circular(15)),
//                                       child: Text(
//                                         (i == 0)
//                                             ? "${stationNames[index]['name']}"
//                                             : (i == 1)
//                                                 ? "${stationNames1[index]['name']}"
//                                                 : (i == 2)
//                                                     ? "${stationNames2[index]['name']}"
//                                                     : "${stationNames3[index]['name']}",
//                                         style: TextStyle(
//                                             fontSize: 20,
//                                             fontWeight: FontWeight.bold),
//                                         textAlign: TextAlign.center,
//                                       ),
//                                     ),
//                                   );
//                                 }),
//                           ),
//                         ]),
//                       if (miniplayerOpen.value != null)
//                         SizedBox(
//                           height: 130,
//                         )
//                     ],
//                   ),
//                 ),
//               ),
//               if (miniplayerOpen.value != null)
//                 Miniplayer(
//                   controller: controllerStack,
//                   backgroundColor: bgColor,
//                   minHeight: 120,
//                   maxHeight: MediaQuery.of(context).size.height * 1,
//                   builder: (height, percentage) => ClipRect(
//                     child: BackdropFilter(
//                       filter: ui.ImageFilter.blur(
//                         sigmaX: 20.0,
//                         sigmaY: 20.0,
//                       ),
//                       child: (height != 120)
//                           ? Container(
//                               decoration: BoxDecoration(
//                                 gradient: LinearGradient(
//                                   begin: Alignment.bottomCenter,
//                                   end: Alignment.topCenter,
//                                   colors: [
//                                     Colors.black.withOpacity(0.9),
//                                     Colors.black.withOpacity(0.7),
//                                     Colors.black.withOpacity(0.5),
//                                     Colors.black.withOpacity(0.3),
//                                   ],
//                                 ),
//                               ),
//                               child: Column(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.spaceEvenly,
//                                 children: [
//                                   Text(
//                                     'BBC RADIO ONE',
//                                     style: TextStyle(
//                                         fontSize: 25,
//                                         fontWeight: FontWeight.bold,
//                                         color: Colors.white),
//                                   ),
//                                   Container(
//                                     decoration: BoxDecoration(
//                                         color: Colors.yellow,
//                                         borderRadius:
//                                             BorderRadius.circular(20)),
//                                     width:
//                                         MediaQuery.of(context).size.width * .8,
//                                     height:
//                                         MediaQuery.of(context).size.width * .8,
//                                   ),
//                                   Container(
//                                     decoration: BoxDecoration(
//                                         color: Colors.black.withOpacity(0.5),
//                                         borderRadius:
//                                             BorderRadius.circular(20)),
//                                     width:
//                                         MediaQuery.of(context).size.width * .85,
//                                     height: MediaQuery.of(context).size.height *
//                                         .15,
//                                     child: Column(
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.spaceEvenly,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             if (playing.value == true) {
//                                               stopminiplayerOpen();
//                                             } else {
//                                               startminiplayerOpen();
//                                             }
//                                           },
//                                           child: Obx(
//                                             () => Icon(
//                                               (playing.value == true)
//                                                   ? Icons.stop_rounded
//                                                   : Icons.play_arrow_rounded,
//                                               color: Colors.white,
//                                               size: 60,
//                                             ),
//                                           ),
//                                         ),
//                                         Slider(
//                                           activeColor: Colors.white,
//                                           min: 0,
//                                           max: 1,
//                                           onChanged: (double value) {
//                                             _setVolumeValue = value;
//                                             VolumeController()
//                                                 .setVolume(_setVolumeValue);
//                                             setState(() {});
//                                           },
//                                           value: _setVolumeValue,
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             )
//                           : Container(
//                               padding: EdgeInsets.only(bottom: 30),
//                               color: Colors.grey.shade800.withOpacity(0.5),
//                               // child: Text('$height, $percentage'),
//                               child: Row(
//                                 children: [
//                                   SizedBox(
//                                     width: 20,
//                                   ),
//                                   Container(
//                                     height: 55,
//                                     width: 55,
//                                     color: Colors.purple,
//                                   ),
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//                                   Text(
//                                     'The Reminder - The Weeknd',
//                                     style: TextStyle(
//                                         fontSize: 16, color: Colors.white),
//                                   ),
//                                   Spacer(),
//                                   InkWell(
//                                     onTap: () {
//                                       miniplayerOpen.value =
//                                           !miniplayerOpen.value;
//                                     },
//                                     child: Icon(
//                                       (miniplayerOpen.value == true)
//                                           ? Icons.stop_rounded
//                                           : Icons.play_arrow_rounded,
//                                       color: Colors.white,
//                                       size: 55,
//                                     ),
//                                   )
//                                 ],
//                               ),
//                             ),
//                     ),
//                   ),
//                 ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }