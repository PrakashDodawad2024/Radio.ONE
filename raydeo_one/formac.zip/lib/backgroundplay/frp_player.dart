// import 'package:flutter/material.dart';
// import 'package:flutter_radio_player/flutter_radio_player.dart';
// import 'package:flutter_radio_player/models/frp_source_modal.dart';
// import 'package:get/get.dart';
// import 'package:miniplayer/miniplayer.dart';
// import 'package:raydeo_one/widgets/minimusic.dart';
// import '../landingpages/homepage.dart';
// import '../main.dart';
// import '../widgets/musicplayer.dart';
// import 'frp_controls.dart';
// import 'dart:ui' as ui;

// // RxBool miniplayerOpen = false.obs;

// // int currentindex = 0;
// // RxBool miniplayerOpened = false.obs;
// // Color bgColor = Colors.purple;
// // RxBool playing = false.obs;
// // RxBool loader = false.obs;

// RxList category = [].obs;

// RxList url = [].obs;

// class FRPlayer extends StatefulWidget {
//   final FlutterRadioPlayer flutterRadioPlayer;
//   final FRPSource frpSource;
//   final bool useIcyData;

//   const FRPlayer({
//     Key? key,
//     required this.flutterRadioPlayer,
//     required this.frpSource,
//     required this.useIcyData,
//   }) : super(key: key);

//   @override
//   State<FRPlayer> createState() => _FRPlayerState();
// }

// class _FRPlayerState extends State<FRPlayer> {
//   int currentIndex = 0;
//   String frpStatus = "flutter_radio_stopped";

//   @override
//   void initState() {
//     super.initState();
//     widget.flutterRadioPlayer.useIcyData(widget.useIcyData);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
      // resizeToAvoidBottomInset: false,
//       body: Stack(
//         children: [
//           MyHomePage(
//             flutterRadioPlayers: widget.flutterRadioPlayer,
//             frpSource: widget.frpSource,
//           ),

//           // Obx(() => firsttime == false
//           //     ? Miniplayer(
//           //         elevation: 0,
//           //         controller: controllerStack,
//           //         backgroundColor: bgColor,
//           //         minHeight: 110,
//           //         maxHeight: MediaQuery.of(context).size.height * 1,
//           //         builder: (height, percentage) => ClipRect(
//           //           child: BackdropFilter(
//           //             filter: ui.ImageFilter.blur(
//           //               sigmaX: 20.0,
//           //               sigmaY: 20.0,
//           //             ),
//           //             child: (height != 110)
//           //                 ? FittedBox(
//           //                     child: Container(
//           //                     width: MediaQuery.of(context).size.width * 1,
//           //                     height: MediaQuery.of(context).size.height * 1,
//           //                     decoration: BoxDecoration(
//           //                       gradient: LinearGradient(
//           //                         begin: Alignment.bottomCenter,
//           //                         end: Alignment.topCenter,
//           //                         colors: [
//           //                           Colors.black.withOpacity(0.9),
//           //                           Colors.black.withOpacity(0.7),
//           //                           Colors.black.withOpacity(0.5),
//           //                           Colors.black.withOpacity(0.3),
//           //                         ],
//           //                       ),
//           //                     ),
//           //                     child: musicplayer(
//           //                         widget.flutterRadioPlayer,
//           //                         addSourceFunction,
//           //                         updateCurrentStatus,
//           //                         setState),
//           //                   ))
//           //                 : minimusic(widget.flutterRadioPlayer,
//           //                     addSourceFunction, updateCurrentStatus, setState),
//           //           ),
//           //         ),
//           //       )
//           //     : SizedBox(
//           //         height: 0,
//           //       ))
//         ],
//       ),
//     );
//   }

//   // addSourceFunction() {
//   //   return widget.flutterRadioPlayer.addMediaSources(widget.frpSource);
//   // }

//   // updateCurrentStatus(status) {
//   //   frpStatus = status;
//   // }

//   // startminiplayerOpen() async {
//   //   playing.value = true;
//   //   //print("playing..$urlOfChannel");
//   //   widget.flutterRadioPlayer.playOrPause();
//   //   resetNowPlayingInfo();
//   // }

//   // stopminiplayerOpen() {
//   //   playing.value = false;
//   //   widget.flutterRadioPlayer.stop();
//   //   resetNowPlayingInfo();
//   // }

//   // ontapplay() {
//   //   if (playing.value == true) {
//   //     stopminiplayerOpen();
//   //     loader.value = false;
//   //   } else {
//   //     print("startminiplayerOpen");
//   //     loader.value = true;
//   //     startminiplayerOpen();
//   //     Future.delayed(const Duration(seconds: 5), () {
//   //       setState(() {
//   //         loader.value = false;
//   //       });
//   //     });
//   //   }
//   // }

//   // void resetNowPlayingInfo() {
//   //   currentPlaying2 = "N/A";
//   // }

//   // ontapmini() {
//   //   miniplayerOpen.value = !miniplayerOpen.value;
//   //   // if (playing.value == true) {
//   //   //   stopminiplayerOpen();
//   //   //   loader.value = false;
//   //   // } else {
//   //   //   print("startminiplayerOpen");
//   //   //   loader.value = true;
//   //   //   Future.delayed(const Duration(seconds: 5), () {
//   //   //     setState(() {
//   //   //       loader.value = false;
//   //   //     });
//   //   //   });
//   //   //   startminiplayerOpen();
//   //   // }
//   // }
// }
