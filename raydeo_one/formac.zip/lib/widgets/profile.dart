import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:raydeo_one/main.dart';
import 'package:url_launcher/url_launcher.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.arrow_back,
                color: Color.fromARGB(255, 152, 188, 145),
              )),
          automaticallyImplyLeading: false,
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text(
            'Profile',
            style: TextStyle(color: Colors.black, fontSize: 25),
          ),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.07,
                child: ListTile(
                    leading: const Icon(
                      Icons.account_circle,
                      size: 25,
                      color: Color.fromARGB(255, 152, 188, 145),
                    ),
                    title: const Text(
                      'Name',
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: IconButton(
                        onPressed: () {},
                        icon: const Icon(
                          Icons.edit,
                          color: Color.fromARGB(255, 152, 188, 145),
                        ))),
              ),
              const Divider(
                thickness: 1,
              ),
              Container(
                height: MediaQuery.of(context).size.height * 0.07,
                child: ListTile(
                  leading: const Icon(
                    Icons.phone_android,
                    size: 25,
                    color: Color.fromARGB(255, 152, 188, 145),
                  ),
                  title: const Text(
                    'Mobile Number',
                    style: TextStyle(fontSize: 16),
                  ),
                  trailing: TextButton(
                    onPressed: () {
                      tapmob.value = true;
                    },
                    child: const Text(
                      "Verify",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
              const Divider(
                thickness: 1,
              ),
              Container(
                height: MediaQuery.of(context).size.height * 0.07,
                child: ListTile(
                  leading: const Icon(
                    Icons.email_rounded,
                    size: 25,
                    color: Color.fromARGB(255, 152, 188, 145),
                  ),
                  title: Text(
                    'Email',
                    style: TextStyle(fontSize: 16),
                  ),
                  trailing: TextButton(
                    onPressed: () {
                      tapemail.value = true;
                    },
                    child: const Text(
                      "Verify",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
              const Divider(
                thickness: 1,
              ),
              InkWell(
                onTap: () async {
                  try {
                    await launchUrl(
                        Uri.parse("https://www.bugtrakr.com/PrivacyPolicy/"),
                        mode: LaunchMode.externalApplication);
                  } catch (e) {
                    print('url launcher error:${e}');
                  }
                },
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.07,
                  child: const ListTile(
                    leading: Icon(
                      Icons.privacy_tip_rounded,
                      color: Color.fromARGB(255, 152, 188, 145),
                    ),
                    title: Text(
                      "Privacy",
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: IconButton(
                        onPressed: null,
                        icon: Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Color.fromARGB(255, 152, 188, 145),
                        )),
                  ),
                ),
              ),
              const Divider(
                thickness: 1,
              ),
              InkWell(
                onTap: () async {
                  try {
                    await launchUrl(Uri.parse("https://www.bugtrakr.com/FAQs/"),
                        mode: LaunchMode.externalApplication);
                  } catch (e) {
                    print('url launcher error:${e}');
                  }
                },
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.07,
                  child: const ListTile(
                    leading: Icon(
                      Icons.question_answer_rounded,
                      color: Color.fromARGB(255, 152, 188, 145),
                    ),
                    title: Text(
                      "FAQ",
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: IconButton(
                      onPressed: null,
                      icon: Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: Color.fromARGB(255, 152, 188, 145),
                      ),
                    ),
                  ),
                ),
              ),
              const Divider(
                thickness: 1,
              ),
              const SizedBox(
                height: 220,
              ),
              const Spacer(),
              const Center(
                child: Text(
                  "App Version - 1.0.0",
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(
                height: 30,
              )
            ],
          ),
        ));
  }
}
