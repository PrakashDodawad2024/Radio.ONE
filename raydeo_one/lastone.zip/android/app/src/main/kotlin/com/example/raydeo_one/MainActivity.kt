package com.mobil80.radio.ONE

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
