const amplifyconfig = ''' {
    "UserAgent": "aws-amplify-cli/2.0",
    "Version": "1.0",
    "api": {
        "plugins": {
            "awsAPIPlugin": {
                "radio_one_mobile": {
                    "endpointType": "GraphQL",
                    "endpoint": "https://jfulirzfyjhjfe5mws7ngc4l3m.appsync-api.ap-south-1.amazonaws.com/graphql",
                    "region": "ap-south-1",
                    "authorizationType": "API_KEY",
                    "apiKey": "da2-jvridw454zazpday5yoprwf3rq"
                }
            }
        }
    }
}''';