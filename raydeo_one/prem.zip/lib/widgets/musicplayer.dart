import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:radio_player/radio_player.dart';
import 'package:share_plus/share_plus.dart';
import '../landingpages/homepage.dart';
import '../main.dart';
import 'chatpage.dart';

Widget MusicPlayer(appBarHeight, setState) {
  RadioPlayer _radioPlayer = RadioPlayer();
  return FutureBuilder(
      future: _radioPlayer.getArtworkImage(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        Image artwork;
        if (snapshot.hasData) {
          artwork = snapshot.data;
        } else {
          artwork = Image(
              image: NetworkImage(
            '$imgurlOfChannel',
          ));
        }

        return Obx(
          () => Stack(children: [
            InkWell(
              onTap: () {},
              child: Container(
                height: MediaQuery.of(context).size.height -
                    (appBarHeight + MediaQuery.of(context).viewPadding.top),
                width: MediaQuery.of(context).size.width * 1,
                decoration: BoxDecoration(
                  color: isDark == true ? Colors.grey.shade900 : Colors.white,
                  // color: Theme.of(context).backgroundColor,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          onTap: () {
                            tapped.value = false;
                            displayfavlist =
                                favouritelist!.get("favlist") ?? [];
                            controllerStack.animateToHeight(
                                state: PanelState.MIN,
                                duration: const Duration(milliseconds: 30));
                            print("tapppppppeddddd");
                          },
                          child: Icon(
                            Icons.keyboard_double_arrow_down_rounded,
                            size: 35,
                            color: maincolor,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.025,
                    ),
                    // Text(
                    //   "$nameOfChannel",
                    //   textAlign:
                    //       TextAlign.center,
                    //   style: const TextStyle(
                    //       fontSize: 25,
                    //       fontWeight:
                    //           FontWeight.bold,
                    //       color: Colors.white),
                    // ),
                    // Row(
                    //   mainAxisAlignment:
                    //       MainAxisAlignment
                    //           .spaceAround,
                    //   children: [
                    //     InkWell(
                    //       onTap: () {
                    //         // _dialogBuilder(context);
                    //         print("tapped");
                    //         tapped.value = true;
                    //       },
                    //       child: Column(
                    //         children: const [
                    //           Icon(
                    //             Icons
                    //                 .chat_sharp,
                    //             size: 35,
                    //             color: Colors
                    //                 .white,
                    //           ),
                    //           Text(
                    //             "Live Chat",
                    //             style: TextStyle(
                    //                 fontSize:
                    //                     18,
                    //                 fontWeight:
                    //                     FontWeight
                    //                         .bold,
                    //                 color: Colors
                    //                     .white),
                    //           )
                    //         ],
                    //       ),
                    //     ),
                    //     InkWell(
                    //       onTap: () {},
                    //       child: Column(
                    //         children: const [
                    //           Icon(
                    //             Icons
                    //                 .keyboard_voice_rounded,
                    //             size: 35,
                    //             color: Colors
                    //                 .white,
                    //           ),
                    //           Text(
                    //             "Detect Audio",
                    //             style: TextStyle(
                    //                 fontSize:
                    //                     18,
                    //                 fontWeight:
                    //                     FontWeight
                    //                         .bold,
                    //                 color: Colors
                    //                     .white),
                    //           )
                    //         ],
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          children: [
                            Text(
                              '$catgOfChannel',
                              softWrap: false,
                              overflow: TextOverflow.fade,
                              style: TextStyle(
                                  color: isDark == true
                                      ? Colors.white
                                      : Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Text(
                              '$nameOfChannel',
                              softWrap: false,
                              overflow: TextOverflow.fade,
                              style: TextStyle(
                                  color: isDark == true
                                      ? Colors.white
                                      : Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 24),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            if (status != 'Offline')
                              Container(
                                decoration: BoxDecoration(
                                    // color: isDark == true
                                    //     ? Colors.white
                                    //     : Colors.black,
                                    borderRadius: BorderRadius.circular(20)),
                                child: Padding(
                                  padding: const EdgeInsets.all(2.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.remove_red_eye,
                                        color: isDark == true
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                      Obx(
                                        () => Text(
                                          " ${subcount}",
                                          style: TextStyle(
                                              color: isDark == true
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.025,
                    ),

                    // Text(
                    //   '$nameOfChannel',
                    //   style: const TextStyle(
                    //       fontSize:
                    //           25,
                    //       fontWeight:
                    //           FontWeight
                    //               .bold,
                    //       color: Colors
                    //           .white),
                    // ),
                    Stack(
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            decoration: BoxDecoration(
                                //color: Colors.yellow,
                                borderRadius: BorderRadius.circular(20)),
                            width: MediaQuery.of(context).size.width * .8,
                            height: MediaQuery.of(context).size.width * .8,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(15),
                              child: status != 'Offline'
                                  ? Image(
                                      image: NetworkImage(
                                        '$imgurlOfChannel',
                                      ),
                                      fit: BoxFit.fill,
                                    )
                                  : const Image(
                                      image: AssetImage(
                                          "assets/Raydeo.ONE512.png")),
                            ),
                          ),
                        ),

                        // if (status !=
                        //     'Offline')
                        //   Align(
                        //     alignment:
                        //         Alignment
                        //             .center,
                        //     child:
                        //         Container(
                        //       decoration: BoxDecoration(
                        //           color: const Color.fromARGB(
                        //               255,
                        //               242,
                        //               242,
                        //               242),
                        //           borderRadius:
                        //               BorderRadius.circular(20)),
                        //       margin: EdgeInsets.only(
                        //           left: MediaQuery.of(context).size.width *
                        //               0.7,
                        //           top: MediaQuery.of(context).size.width *
                        //               0.01,
                        //           right:
                        //               MediaQuery.of(context).size.width * 0.11),
                        //       child:
                        //           Padding(
                        //         padding:
                        //             const EdgeInsets.all(2.0),
                        //         child:
                        //             Row(
                        //           mainAxisAlignment:
                        //               MainAxisAlignment.center,
                        //           children: [
                        //             const Icon(
                        //               Icons.remove_red_eye,
                        //               color: Colors.black,
                        //             ),
                        //             Obx(
                        //               () => Text(
                        //                 " ${subcount}",
                        //                 style: const TextStyle(color: Colors.black),
                        //               ),
                        //             ),
                        //           ],
                        //         ),
                        //       ),
                        //     ),
                        //   ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.025,
                    ),

                    Container(
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(20)),
                      width: MediaQuery.of(context).size.width * .8,
                      height: MediaQuery.of(context).size.height * .18,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Slider(
                          //   inactiveColor:
                          //       Colors
                          //           .blueGrey,
                          //   activeColor:
                          //       Colors
                          //           .white,
                          //   value:
                          //       _currentSliderSecondaryValue,
                          //   label: _currentSliderSecondaryValue
                          //       .round()
                          //       .toString(),
                          //   onChanged:
                          //       (double
                          //           value) {
                          //     setState(
                          //         () {
                          //       _currentSliderSecondaryValue =
                          //           value;
                          //     });
                          //   },
                          // ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              IconButton(
                                  onPressed: () {
                                    Share.share(
                                      'mobil80://radiooneinternetradio.com/$idOfChannel',
                                    );
                                  },
                                  icon: Icon(
                                    Icons.share_rounded,
                                    color: maincolor,
                                    size: 35,
                                  )),
                              InkWell(
                                  onTap: () {
                                    print("qwerty");
                                    if (status != 'Offline') {
                                      setState(() {
                                        isPlaying
                                            ? _radioPlayer.pause()
                                            : _radioPlayer.play();
                                      });
                                    } else {
                                      // _radioPlayer.stop();
                                      WidgetsBinding.instance
                                          .addPostFrameCallback((_) {
                                        // Add Your Code here.

                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                                behavior:
                                                    SnackBarBehavior.floating,
                                                padding:
                                                    const EdgeInsets.all(5),
                                                shape: const StadiumBorder(),
                                                backgroundColor:
                                                    const Color.fromARGB(
                                                        255, 242, 242, 242),
                                                duration:
                                                    const Duration(seconds: 3),
                                                content: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: const [
                                                    SizedBox(
                                                      width: 40,
                                                      height: 40,
                                                      child: Image(
                                                          image: AssetImage(
                                                              "assets/Raydeo.ONE512.png")),
                                                    ),
                                                    SizedBox(
                                                      width: 250,
                                                      child: Text(
                                                        "Please check your internet connection and try again",
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 14),
                                                      ),
                                                    )
                                                  ],
                                                )));
                                      });
                                    }
                                  },
                                  child: Container(
                                    height: 50,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: maincolor),
                                    child: isPlaying
                                        ? loader.value == true
                                            ? Center(
                                                child:
                                                    CircularProgressIndicator(
                                                color: isDark == true
                                                    ? Colors.white
                                                    : Colors.black,
                                              ))
                                            : Icon(
                                                Icons.pause_rounded,
                                                color: isDark == true
                                                    ? Colors.white
                                                    : Colors.black,
                                                size: 35,
                                              )
                                        : Icon(
                                            Icons.play_arrow_rounded,
                                            color: isDark == true
                                                ? Colors.white
                                                : Colors.black,
                                            size: 35,
                                          ),
                                  )),
                              IconButton(
                                  onPressed: () async {
                                    if (displayfavlist.isNotEmpty) {
                                      if (addFavourite == true) {
                                        favlist = favouritelist!.get(
                                              "favlist",
                                            ) ??
                                            [];
                                        print(
                                            "favlistsecondlist${favlist.length}");

                                        for (int x = 0;
                                            x < favlist.length;
                                            x++) {
                                          print(
                                              "channel_name : ${favlist[x]["channel_name"]}");
                                          if (favlist[x]["channel_name"]
                                                  .toString() ==
                                              "$nameOfChannel") {
                                            setState(() {
                                              print(
                                                  "matched  ##################");
                                              favlist.removeAt(x);
                                              favouritelist!.put("favlist", []);
                                              favouritelist!
                                                  .put("favlist", favlist);
                                              addFavourite = !addFavourite;
                                              displayfavlist = favouritelist!
                                                      .get("favlist") ??
                                                  [];
                                            });
                                          }
                                        }
                                      } else {
                                        setState(() {
                                          favlist = favouritelist!.get(
                                                "favlist",
                                              ) ??
                                              [];
                                          favouritelist!.put("favlist", []);

                                          favlist.add(favdata);
                                          favouritelist!
                                              .put("favlist", favlist);
                                          addFavourite = !addFavourite;
                                          displayfavlist =
                                              favouritelist!.get("favlist") ??
                                                  [];
                                        });
                                      }
                                    } else {
                                      setState(() {
                                        favlist = favouritelist!.get(
                                              "favlist",
                                            ) ??
                                            [];
                                        favouritelist!.put("favlist", []);

                                        favlist.add(favdata);
                                        favouritelist!.put("favlist", favlist);
                                        addFavourite = !addFavourite;
                                      });
                                      setState(() {
                                        displayfavlist =
                                            favouritelist!.get("favlist") ?? [];
                                      });

                                      // print("favlistfavlist${favouritelist!.values}");
                                    }
                                  },
                                  icon: addFavourite == true
                                      ? const Icon(
                                          Icons.favorite,
                                          color: Colors.red,
                                          size: 35,
                                        )
                                      : Icon(
                                          Icons.favorite_border_rounded,
                                          color: maincolor,
                                          size: 35,
                                        )),
                            ],
                          ),

                          // Slider(
                          //   activeColor: Colors.white,
                          //   min: 0,
                          //   max: 1,
                          //   onChanged: (double value) {
                          //     _setVolumeValue = value;
                          //     VolumeController()
                          //         .setVolume(_setVolumeValue);
                          //     setState(() {});
                          //   },
                          //   value: _setVolumeValue,
                          // ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.025,
                    ),
                  ],
                ),
              ),
            ),
            // Align(
            //   alignment:
            //       Alignment.topRight,
            //   child: InkWell(
            //     onTap: () {
            //       setState(() {
            //         _radioPlayer.stop();
            //       });
            // controllerStack.animateToHeight(
            //     state: PanelState
            //         .MIN,
            //     duration:
            //         const Duration(
            //             milliseconds:
            //                 30));
            //       Mqtt.firsttime!
            //               .value ==
            //           Mqtt.firsttime!
            //               .value;
            //       setState(() {});
            //     },
            //     child: Container(
            //       padding:
            //           EdgeInsets.only(
            //         right: MediaQuery.of(
            //                     context)
            //                 .size
            //                 .height *
            //             0.025,
            //         top: MediaQuery.of(
            //                     context)
            //                 .size
            //                 .height *
            //             0.015,
            //       ),
            //       child: Icon(
            //         Icons
            //             .cancel_rounded,
            //         color: Colors
            //             .red.shade400,
            //         size: 30,
            //       ),
            //     ),
            //   ),
            // ),
            tapped == true
                ? Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: InkWell(
                        onTap: () {},
                        child: Container(
                          color: const Color.fromARGB(239, 186, 185, 185),
                          height: MediaQuery.of(context).size.height * 0.95,
                          width: MediaQuery.of(context).size.height * 1,
                          child: const ChatPage(),
                        ),
                      ),
                    ),
                  )
                : const SizedBox(
                    height: 0,
                  ),
            if (loader.value == true)
              const Opacity(
                opacity: 0.5,
                child: ModalBarrier(dismissible: false, color: Colors.white),
              ),
            if (loader.value == true)
              Center(
                child: Container(
                  width: 50,
                  height: 50,
                  decoration: const BoxDecoration(shape: BoxShape.circle),
                  child: CircularProgressIndicator(
                    color: maincolor,
                    strokeWidth: 5,
                  ),
                ),
              ),
          ]),
        );
      });
}
