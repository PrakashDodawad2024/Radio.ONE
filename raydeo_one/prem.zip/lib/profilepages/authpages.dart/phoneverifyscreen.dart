import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:raydeo_one/main.dart';
import 'firebaseauth.dart';

class PhoneVerifyScreen extends StatefulWidget {
  final cc;
  final phoneNumber;
  final verificationID;

  const PhoneVerifyScreen(
    this.cc,
    this.phoneNumber,
    this.verificationID,
  );

  @override
  State<PhoneVerifyScreen> createState() => _PhoneVerifyScreenState();
}

class _PhoneVerifyScreenState extends State<PhoneVerifyScreen> {
  String enteredOTP = '';
  bool verificationStarted = false;
  bool isloading1 = false;
  final TextEditingController phoneNumnerController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool? otpSent;
  bool isloading = false;
  bool _isOTPSent = false;
  bool _isPhoneNumberValid = false;
  bool ontapped = true;
  String phoneNumber = "";
  var countryCode;

  String? _currentAddress;
  String? currentAddress;

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;
    return Form(
      child: Scaffold(
        backgroundColor: Colors.white,
        //resizeToAvoidBottomInset: false,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          // leading: BackButton(color: maincolor),
          backgroundColor: Colors.white,
          elevation: 0,
        ),
        body: SingleChildScrollView(
          child: Container(
            height: screenSize.height * 0.9,
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                // SizedBox(
                //   height: screenSize.height * 0.05,
                // ),
                Container(
                  child: Center(
                    child: Column(
                      children: [
                        Container(
                          width: 180,
                          height: 180,
                          child: ClipRRect(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15)),
                              child: Image(
                                  image: AssetImage(
                                      "assets/Raydeo.ONESqLogo.jpg"))),
                        ),
                        SizedBox(
                          height: screenSize.height * 0.03,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RichText(
                              text: TextSpan(
                                text: 'Radio.ONE ',
                                style:
                                    TextStyle(fontSize: 30, color: maincolor),
                                children: const <TextSpan>[],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(
                  height: screenSize.height * 0.03,
                ),

                Column(
                  children: [
                    Text.rich(
                      TextSpan(
                        text: 'Enter the OTP sent ',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                        children: <TextSpan>[
                          TextSpan(
                            text: '${widget.cc}${widget.phoneNumber}',
                            style: new TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline),
                          ),
                        ],
                      ),
                    ),
                    // TextButton(
                    //     onPressed: () {
                    //       opennew.value = true;
                    //     },
                    //     child: Text("Change number?"))
                  ],
                ),
                opennew == true
                    ? Column(
                        children: [
                          Container(
                            // padding: const EdgeInsets.symmetric(horizontal: 30),
                            child: IntlPhoneField(
                              dropdownIcon: const Icon(
                                Icons.arrow_drop_down_rounded,
                                color: Colors.black,
                              ),
                              flagsButtonMargin: const EdgeInsets.all(5),
                              dropdownDecoration: BoxDecoration(
                                  // border: Border.all(color: Colors.grey.shade300),
                                  color: Colors.white,
                                  shape: BoxShape.rectangle,
                                  borderRadius: BorderRadius.circular(30)),
                              autovalidateMode: AutovalidateMode.disabled,
                              dropdownTextStyle: const TextStyle(fontSize: 16),
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                  isCollapsed: true,
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 14),
                                  border: OutlineInputBorder(
                                    borderSide:
                                        BorderSide(color: Colors.grey.shade300),
                                  ),
                                  enabledBorder: const OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: maincolor),
                                  ),
                                  filled: true,
                                  hintText: "Phone Number",
                                  hintStyle: TextStyle(color: maincolor),
                                  labelStyle: TextStyle(color: maincolor),
                                  labelText: "Phone Number"),
                              controller: phoneNumnerController,
                              initialCountryCode: "IN",
                              autofocus: false,
                              onChanged: (phone) {
                                countryCode = phone.countryCode;
                              },
                              onTap: () {
                                setState(() {
                                  ontapped = false;
                                });

                                // _formKey.currentState!.reset();
                              },
                              validator: (number) {
                                if (ontapped = true) {
                                  if (number == null) {
                                    return "Required Number";
                                  } else {
                                    return null;
                                  }
                                }

                                return null;
                              },
                            ),
                          ),
                          const SizedBox(height: 40.0),
                          Container(
                            width: double.infinity,
                            // padding: EdgeInsets.all(5),
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: maincolor),
                                child: isloading == true
                                    ? const CircularProgressIndicator(
                                        color: Colors.white,
                                      )
                                    : const Text(
                                        'Send OTP',
                                        style: TextStyle(color: Colors.black),
                                      ),
                                onPressed: () {
                                  FirebaseConfiguration()
                                      .phoneNumberVerification(countryCode,
                                          phoneNumnerController.text, context);
                                  setState(() {
                                    _isOTPSent = true;
                                  });
                                  setState(() {
                                    isloading = true;
                                  });
                                  Timer(
                                    const Duration(seconds: 8),
                                    () {
                                      setState(() {
                                        isloading = false;
                                      });
                                    },
                                  );
                                }),
                          )
                        ],
                      )
                    : SizedBox(
                        height: 0,
                      ),
                SizedBox(
                  height: screenSize.height * 0.05,
                ),
                PinCodeTextField(
                  autoFocus: true,
                  pinTheme: PinTheme(
                    activeColor: Colors
                        .green, //themecolor (color displayed after entering)
                    fieldHeight: 25,
                    //gap between field and the text
                    fieldWidth: 34, // width of each field
                    inactiveColor: Theme.of(context)
                        .primaryColorLight, // color of the fields after the selected field
                    selectedColor: Theme.of(context)
                        .primaryColorDark, //colo of the selected field
                  ),
                  appContext: context,
                  length: 6,
                  onChanged: (value) {
                    enteredOTP = value;
                  },
                  onCompleted: (value) {
                    setState(() {
                      verificationStarted = true;
                    });
                    verifyotp();
                  },
                ),

                SizedBox(
                  height: screenSize.height * 0.07,
                ),
                // verificationStarted == true
                //     ? LoadingAnimationWidget.hexagonDots(
                //         color: maincolor, size: 40)
                //     : SizedBox(
                //         height: 0,
                //       ),
                SizedBox(
                  height: screenSize.height * 0.03,
                ),
                (verificationStarted == true)
                    ? Container(
                        alignment: Alignment.center,
                        child: Text(
                          "Authenticating...",
                          style: TextStyle(
                            color: Theme.of(context).primaryColorDark,
                            fontSize: 16,
                          ),
                        ),
                      )
                    : SizedBox(
                        height: 0,
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  verifyotp() async {
    var res = await FirebaseConfiguration().verifyOTP(
      widget.cc,
      widget.phoneNumber,
      enteredOTP,
      widget.verificationID,
      context,
    );
    if (res == "SUCESS") {
      setState(() {
        verificationStarted = false;
      });
    }
  }
}
