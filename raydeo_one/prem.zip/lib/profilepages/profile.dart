import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:raydeo_one/landingpages/homepage.dart';
import 'package:raydeo_one/main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'email.dart';
import 'mobilenumber.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final _formKey = GlobalKey<FormState>();
  bool verified = accountdetails!.get(
        "MobNoVerified",
      ) ??
      false;
  String mobileNumber = accountdetails!.get(
        "mobileNumber",
      ) ??
      "Mobile Number";

  bottommodalsheet() async {
    if (!mounted) return false;
    return showModalBottomSheet<void>(
      isScrollControlled: true,
      isDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (BuildContext context,
            StateSetter setState /*You can rename this!*/) {
          return Padding(
            padding: MediaQuery.of(context).viewInsets,
            child: Container(
              height: 180,
              // color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(left: 24),
                          child: const Text(
                            'Enter Your Name',
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * .025,
                    ),
                    Container(
                      margin: const EdgeInsets.only(left: 20, right: 60),
                      padding: const EdgeInsets.all(1),
                      width: double.infinity,
                      child: TextFormField(
                        maxLength: 25,
                        initialValue: username,
                        onChanged: (value) {
                          changename = value;
                        },
                        decoration: const InputDecoration(
                          counterText: "",
                          isDense: true,
                          // border: InputBorder.none,
                        ),
                        validator: (name) {
                          if (name!.isEmpty || name == "") {
                            return "Required Name";
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * .015,
                    ),
                    Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        child: TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Cancel',
                              style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w500,
                                  color: maincolor),
                            )),
                      ),
                      Container(
                        child: TextButton(
                            onPressed: () async {
                              FocusManager.instance.primaryFocus!.unfocus();
                              if (_formKey.currentState!.validate()) {
                                Navigator.of(context).pop();
                              }
                            },
                            child: Text('Ok',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w500,
                                  color: maincolor,
                                ))),
                      ),
                    ])
                  ],
                ),
              ),
            ),
          );
        });
      },
    ).then((value) async {
      if (_formKey.currentState!.validate()) {
        if (changename != username) {
          setState(() {
            if (changename.isNotEmpty) {
              username = changename.trim();
              accountdetails!.put("username", username);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                backgroundColor: Colors.green,
                content: Text('Profile Updated Succesfully'),
              ));
            } else {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                backgroundColor: Colors.red,
                content: Text('Name shouldn\'t be empty '),
              ));
            }
          });
        } else {
          return null;
        }
      }
      if (mounted) {
        await Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const Profile()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Scaffold(
          backgroundColor: Theme.of(context).backgroundColor,
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            leading: IconButton(
                onPressed: () {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => MyHomePage(),
                  ));
                },
                icon: Icon(
                  Icons.arrow_back,
                  color: maincolor,
                )),
            automaticallyImplyLeading: false,
            // backgroundColor: Colors.transparent,
            elevation: 0,
            title: Text('Profile',
                style: Theme.of(context).textTheme.headlineSmall),
            centerTitle: true,
          ),
          body: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                    height: MediaQuery.of(context).size.height * 0.07,
                    child: ListTile(
                        leading: const Icon(
                          Icons.account_circle,
                          size: 25,
                        ),
                        title: Text(
                          '$username',
                          style: const TextStyle(fontSize: 16),
                        ),
                        trailing: TextButton(
                          onPressed: () {
                            bottommodalsheet();
                          },
                          child: Text(
                            "EDIT",
                            style: TextStyle(
                                color: maincolor, fontWeight: FontWeight.bold),
                          ),
                        ))),
                const Divider(
                  thickness: 1,
                ),
                Container(
                  height: MediaQuery.of(context).size.height * 0.07,
                  child: ListTile(
                    leading: const Icon(
                      Icons.phone_android,
                      size: 25,
                    ),
                    title: Text(
                      '$mobileNumber',
                      style: const TextStyle(fontSize: 16),
                    ),
                    trailing: verified == true
                        ? Text(
                            "Verified",
                            style: TextStyle(
                                color: maincolor, fontWeight: FontWeight.bold),
                          )
                        : TextButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) =>
                                      MobileNumberVerificationScreen()));
                            },
                            child: Text(
                              "Verify",
                              style: TextStyle(
                                  color: maincolor,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                  ),
                ),
                // const Divider(
                //   thickness: 1,
                // ),
                // Container(
                //   height: MediaQuery.of(context).size.height * 0.07,
                //   child: ListTile(
                //     leading: Icon(
                //       Icons.email_rounded,
                //       size: 25,
                //       color: maincolor,
                //     ),
                //     title: const Text(
                //       'Email',
                //       style: TextStyle(fontSize: 16),
                //     ),
                //     trailing: TextButton(
                //       onPressed: () {
                //         Navigator.of(context).push(MaterialPageRoute(
                //             builder: (context) => EmailPage()));
                //       },
                //       child: const Text(
                //         "Verify",
                //         style: TextStyle(
                //             color: Colors.green, fontWeight: FontWeight.bold),
                //       ),
                //     ),
                //   ),
                // ),
                const Divider(
                  thickness: 1,
                ),
                InkWell(
                  onTap: () async {
                    try {
                      await launchUrl(
                          Uri.parse("https://www.bugtrakr.com/PrivacyPolicy/"),
                          mode: LaunchMode.externalApplication);
                    } catch (e) {
                      print('url launcher error:${e}');
                    }
                  },
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.07,
                    child: ListTile(
                      leading: const Icon(
                        Icons.privacy_tip_rounded,
                      ),
                      title: const Text(
                        "Privacy",
                        style: TextStyle(fontSize: 16),
                      ),
                      trailing: IconButton(
                          onPressed: null,
                          icon: Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: maincolor,
                          )),
                    ),
                  ),
                ),
                const Divider(
                  thickness: 1,
                ),
                InkWell(
                  onTap: () async {
                    try {
                      await launchUrl(
                          Uri.parse("https://www.bugtrakr.com/FAQs/"),
                          mode: LaunchMode.externalApplication);
                    } catch (e) {
                      print('url launcher error:${e}');
                    }
                  },
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.07,
                    child: ListTile(
                      leading: const Icon(
                        Icons.question_answer_rounded,
                      ),
                      title: const Text(
                        "FAQ",
                        style: TextStyle(fontSize: 16),
                      ),
                      trailing: IconButton(
                        onPressed: null,
                        icon: Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: maincolor,
                        ),
                      ),
                    ),
                  ),
                ),
                const Divider(
                  thickness: 1,
                ),
                const SizedBox(
                  height: 220,
                ),
                const Spacer(),
                const Center(
                  child: Text(
                    "App Version - 1.0.0",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(
                  height: 30,
                )
              ],
            ),
          )),
    );
  }
}
