package com.example.raydeo_one

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
