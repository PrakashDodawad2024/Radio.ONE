// import 'dart:convert';
// import 'dart:math' as math;
// import 'dart:math';
// import 'dart:ui' as ui;
// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:miniplayer/miniplayer.dart';
// import 'package:raydeo_one/widgets/minimusic.dart';
// import 'package:volume_controller/volume_controller.dart';
// import '../main.dart';
// import '../mqtt/mqttregister.dart';
// import '../widgets/allchannel.dart';
// import '../widgets/musicplayer.dart';

// int currentindex = 0;
// RxBool miniplayerOpen = false.obs;
// RxBool playing = false.obs;
// RxBool loader = false.obs;
// RxList alldata = [].obs;
// RxList category = [].obs;
// RxList recent = [].obs;
// RxList newrelease = [].obs;
// RxList kannada = [].obs;
// RxList BBCOne = [].obs;
// RxList trending = [].obs;
// RxList url = [].obs;

// class MyHomePage extends StatefulWidget {
//   @override
//   State<MyHomePage> createState() => _MyHomePageState();
// }

// class _MyHomePageState extends State<MyHomePage> {
//   final controllerStack = MiniplayerController();
//   final _random = Random();
//   static final AudioPlayer _player = AudioPlayer();
//   double _volumeListenerValue = 0;
//   double _getVolume = 0;

//   @override
//   void initState() {
//     AudioPlayer.global.setGlobalAudioContext(_getAudioContext());
//     super.initState();
//     callmqtt();
//   }

//   callmqtt() async {
//     await Mqtt().registerUserMethod();
//     final allresponse = await allmessages!.get("allmessages");
//     if (allresponse != null) {
//       final decodeddata = jsonDecode(allresponse["channel_message"]);
//       final alldecodeddata = jsonDecode(decodeddata["description"]);
//       print("alldecodeddata${alldecodeddata}");
//       alldata.value = alldecodeddata;
//       print("alldata$alldata");
//       if (alldata != []) {
//         for (int i = 0; i < alldata.length; i++) {
//           category.add(alldata[i]["channel_category"]);
//           url.add(alldata[i]["channel_stream_url"]);
//         }
//         for (int j = 0; j < alldata.length; j++) {
//           if (alldata[j]["channel_category"] == "Recently Played") {
//             recent.add(alldata[j]);
//           } else if (alldata[j]["channel_category"] == "New Releases") {
//             newrelease.add(alldata[j]);
//           } else if (alldata[j]["channel_category"] == "BBC Radio One") {
//             BBCOne.add(alldata[j]);
//           } else if (alldata[j]["channel_category"] == "Kannada Channel") {
//             kannada.add(alldata[j]);
//           } else {
//             trending.add(alldata[j]);
//           }
//         }
//       }
//     }
//   }

//   @override
//   void dispose() {
//     VolumeController().removeListener();
//     super.dispose();
//   }

//   AudioContext _getAudioContext() {
//     return const AudioContext(
//       android: AudioContextAndroid(
//         isSpeakerphoneOn: false,
//         stayAwake: true,
//         contentType: AndroidContentType.music,
//         usageType: AndroidUsageType.media,
//         audioFocus: AndroidAudioFocus.gain,
//       ),
//       iOS: AudioContextIOS(
//         category: AVAudioSessionCategory.soloAmbient,
//         options: [],
//       ),
//     );
//   }

//   startminiplayerOpen(urlOfChannel) {
//     playing.value = true;

//     print("playing..$urlOfChannel");
//     _player.play(UrlSource(urlOfChannel));
//   }

//   stopminiplayerOpen() {
//     playing.value = false;
//     _player.stop();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return alldata == []
//         ? const Center(
//             child: CircularProgressIndicator(
//               backgroundColor: Colors.blue,
//             ),
//           )
//         :
//         //  MiniplayerWillPopScope(
//         // onWillPop:() async => false,
//         // child:
//         Obx(
//             () => Scaffold(
//               body: Stack(
//                 children: <Widget>[
//                   Container(
//                     padding: const EdgeInsets.only(top: 30),
//                     color: Colors.black,
//                     height: MediaQuery.of(context).size.height * 1,
//                     child: SingleChildScrollView(
//                       child: Column(
//                         children: [
//                           const SizedBox(
//                             height: 45,
//                           ),
//                           Container(
//                             margin: const EdgeInsets.only(left: 20, right: 20),
//                             width: MediaQuery.of(context).size.width * 1,
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.start,
//                               children: const [
//                                 Text(
//                                   'Radio One',
//                                   style: TextStyle(
//                                     color: Colors.lightBlue,
//                                     fontSize: 38,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                   textAlign: TextAlign.start,
//                                 ),
//                                 Spacer(),
//                                 Icon(
//                                   Icons.radio,
//                                   color: Colors.lightBlue,
//                                   size: 60,
//                                 ),
//                               ],
//                             ),
//                           ),
//                           const SizedBox(
//                             height: 20,
//                           ),
//                           category.length != 0
//                               ? Container(
//                                   margin: const EdgeInsets.only(left: 20),
//                                   width: MediaQuery.of(context).size.width * 1,
//                                   child: const Text(
//                                     'Recently Played',
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                       fontSize: 25,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                     textAlign: TextAlign.start,
//                                   ),
//                                 )
//                               : const SizedBox(
//                                   height: 0,
//                                 ),
//                           Container(
//                             // margin: const EdgeInsets.only(left: 10),
//                             height: MediaQuery.of(context).size.height * .24,
//                             child: MyListViewBuilder(
//                                 setState, recent, ontapchannel, context),
//                           ),
//                           category.length != 0
//                               ? Container(
//                                   margin: const EdgeInsets.only(left: 20),
//                                   width: MediaQuery.of(context).size.width * 1,
//                                   child: const Text(
//                                     'New Releases',
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                       fontSize: 25,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                     textAlign: TextAlign.start,
//                                   ),
//                                 )
//                               : const SizedBox(
//                                   height: 0,
//                                 ),
//                           Container(
//                             height: MediaQuery.of(context).size.height * .24,
//                             child: MyListViewBuilder(
//                                 setState, newrelease, ontapchannel, context),
//                           ),
//                           category.length != 0
//                               ? Container(
//                                   margin: const EdgeInsets.only(left: 20),
//                                   width: MediaQuery.of(context).size.width * 1,
//                                   child: const Text(
//                                     'BBC Radio One',
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                       fontSize: 25,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                     textAlign: TextAlign.start,
//                                   ),
//                                 )
//                               : const SizedBox(
//                                   height: 0,
//                                 ),
//                           Container(
//                             height: MediaQuery.of(context).size.height * .24,
//                             child: MyListViewBuilder(
//                                 setState, BBCOne, ontapchannel, context),
//                           ),
//                           category.length != 0
//                               ? Container(
//                                   margin: const EdgeInsets.only(left: 20),
//                                   width: MediaQuery.of(context).size.width * 1,
//                                   child: const Text(
//                                     'Trending Now',
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                       fontSize: 25,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                     textAlign: TextAlign.start,
//                                   ),
//                                 )
//                               : const SizedBox(
//                                   height: 0,
//                                 ),
//                           Container(
//                             height: MediaQuery.of(context).size.height * .24,
//                             child: MyListViewBuilder(
//                                 setState, trending, ontapchannel, context),
//                           ),
//                           category.length != 0
//                               ? Container(
//                                   margin: const EdgeInsets.only(left: 20),
//                                   width: MediaQuery.of(context).size.width * 1,
//                                   child: const Text(
//                                     'Kannada Channels',
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                       fontSize: 25,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                     textAlign: TextAlign.start,
//                                   ),
//                                 )
//                               : const SizedBox(
//                                   height: 0,
//                                 ),
//                           Container(
//                             height: MediaQuery.of(context).size.height * .24,
//                             child: MyListViewBuilder(
//                                 setState, kannada, ontapchannel, context),
//                           ),
//                           if (miniplayerOpen.value != null)
//                             const SizedBox(
//                               height: 130,
//                             ),
//                         ],
//                       ),
//                     ),
//                   ),
//                   if (miniplayerOpen.value != null)
//                     Firsttime != true
//                         ? Miniplayer(
//                             elevation: 0,
//                             controller: controllerStack,
//                             backgroundColor: bgColor,
//                             minHeight: 110,
//                             maxHeight: MediaQuery.of(context).size.height * 1,
//                             builder: (height, percentage) => ClipRect(
//                               child: BackdropFilter(
//                                   filter: ui.ImageFilter.blur(
//                                     sigmaX: 20.0,
//                                     sigmaY: 20.0,
//                                   ),
//                                   child: (height != 110)
//                                       ? FittedBox(
//                                           child: Container(
//                                             width: MediaQuery.of(context)
//                                                     .size
//                                                     .width *
//                                                 1,
//                                             height: MediaQuery.of(context)
//                                                     .size
//                                                     .height *
//                                                 1,
//                                             decoration: BoxDecoration(
//                                               gradient: LinearGradient(
//                                                 begin: Alignment.bottomCenter,
//                                                 end: Alignment.topCenter,
//                                                 colors: [
//                                                   Colors.black.withOpacity(0.9),
//                                                   Colors.black.withOpacity(0.7),
//                                                   Colors.black.withOpacity(0.5),
//                                                   Colors.black.withOpacity(0.3),
//                                                 ],
//                                               ),
//                                             ),
//                                             child: musicplayer(
//                                               context,
//                                               ontapplay,
//                                               setState,
//                                             ),
//                                           ),
//                                         )
//                                       : minimusic(
//                                           ontapmini,
//                                         )),
//                             ),
//                           )
//                         : const SizedBox(
//                             height: 0,
//                           )
//                 ],
//               ),
//             ),
//           );
//     // );
//   }

//   ontapchannel() {
//     setState(() {
//       bgColor = Color((math.Random().nextDouble() * 0xFFFFFF).toInt())
//           .withOpacity(1.0);
//       print("startminiplayerOpen");
//       startminiplayerOpen(urlOfChannel);
//       loader.value = true;
//       Future.delayed(const Duration(seconds: 5), () {
//         setState(() {
//           loader.value = false;
//         });
//       });
//       // playing.value == false;
//     });

//     controllerStack.animateToHeight(
//         state: PanelState.MAX, duration: const Duration(milliseconds: 500));
//   }

//   ontapplay() {
//     if (playing.value == true) {
//       stopminiplayerOpen();
//       loader.value = false;
//     } else {
//       print("startminiplayerOpen");
//       loader.value = true;
//       Future.delayed(const Duration(seconds: 5), () {
//         setState(() {
//           loader.value = false;
//         });
//       });

//       startminiplayerOpen(urlOfChannel);
//     }
//   }

//   ontapmini() {
//     miniplayerOpen.value = !miniplayerOpen.value;
//     if (playing.value == true) {
//       stopminiplayerOpen();
//       loader.value = false;
//     } else {
//       print("startminiplayerOpen");
//       loader.value = true;
//       Future.delayed(const Duration(seconds: 5), () {
//         setState(() {
//           loader.value = false;
//         });
//       });
//       startminiplayerOpen(urlOfChannel);
//     }
//   }
// }
