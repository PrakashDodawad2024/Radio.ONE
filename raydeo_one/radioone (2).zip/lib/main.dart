import 'dart:io';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:get/get.dart';
import 'package:miniplayer/miniplayer.dart';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:volume_controller/volume_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'backgroundplay/mainplay.dart';
import 'landingpages/homepage.dart';
import 'mqtt/mqttregister.dart';
import 'package:intl/date_symbol_data_local.dart';

int currentindex = 0;
int currentindx = 0;
bool isloading = false;
bool loadingdata = true;
RxString currentPlaying = "".obs;

RxBool playing = false.obs;
RxBool loader = false.obs;
RxBool tapped = false.obs;
RxBool onplay = false.obs;
RxBool onpause = false.obs;
List alldata = [];
RxList stationdata = [].obs;
List categories = [];
RxList categorylist = [].obs;
List<MediaSources> recent = [];
List<MediaSources> newrelease = [];
List<MediaSources> kannada = [];
List<MediaSources> Hindi = [];
List<MediaSources> Devotional = [];
List<MediaSources> BBCOne = [];
List<MediaSources> trending = [];
List urls = [];
Color bgColor = Colors.purple;
bool? isFirsttime;
bool? isRegistered;
RxBool firsttime = true.obs;
bool Firsttimee = true;
Box? channel;
Box? clientdetailBox;
Box? allmessages;
Box? statiomessages;
List<MediaSources> mediasourcelist = [];
List<MediaSources> mediasource = [];
List<MediaSources> frpSource = [];
String selected = "";
RxString nameOfChannel = ''.obs;
RxString descOfChannel = ''.obs;
RxString urlOfChannel = ''.obs;
RxString imgurlOfChannel = ''.obs;

Color maincolor = const Color.fromARGB(146, 57, 42, 65);
Future<String?> _getId() async {
  var deviceInfo = DeviceInfoPlugin();
  if (Platform.isIOS) {
    // import 'dart:io'
    var iosDeviceInfo = await deviceInfo.iosInfo;
    return iosDeviceInfo.identifierForVendor; // unique ID on iOS
  } else if (Platform.isAndroid) {
    var androidDeviceInfo = await deviceInfo.androidInfo;
    return androidDeviceInfo.id; // unique ID on Android
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  isFirsttime = sharedPreferences.getBool("isFirsttime") ?? true;
  isRegistered = sharedPreferences.getBool("isRegistered") ?? false;
  await Hive.initFlutter();
  await _getId();
  channel = await Hive.openBox("channel");
  clientdetailBox = await Hive.openBox("clientdetailBox");
  allmessages = await Hive.openBox("allmessages");
  statiomessages = await Hive.openBox("statiomessages");
  initializeDateFormatting().then((_) => runApp(const MyApp()));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    callmqtt();
  }

  callmqtt() async {
    if (isRegistered == false) await Mqtt().registerUserMethod();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Radio One',
      theme: ThemeData(
        primaryColor: maincolor,
      ),
      home: AnimatedSplashScreen(
        backgroundColor: Colors.black,
        splashIconSize: 250,
        splash: Center(
          child: Column(
            children: [
              const Icon(
                Icons.radio,
                color: Colors.lightBlue,
                size: 150,
              ),
              RichText(
                text: const TextSpan(
                  text: 'Radio One ',
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.lightBlue),
                  // children: const <TextSpan>[],
                ),
              ),
            ],
          ),
        ),
        duration: 250,
        nextScreen: playback(),
        splashTransition: SplashTransition.sizeTransition,
      ),
    );
  }
}
 // callmqtt() async {
  //   await Mqtt().registerUserMethod();
  //   final allresponse = await allmessages!.get("allmessages");
  //   if (allresponse != null) {
  //     final decodeddata = jsonDecode(allresponse["channel_message"]);
  //     final alldecodeddata = jsonDecode(decodeddata["description"]);
  //     print("alldecodeddata${alldecodeddata}");
  //     alldatas.value = alldecodeddata;
  //     print("alldata$alldatas");
  //     setState(() {
  //       isloading = false;
  //     });
  //     if (alldatas != []) {
  // for (int i = 0; i < alldatas.length; i++) {
  //   category.add(alldatas[i]["channel_category"]);
  //   url.add(alldatas[i]["channel_stream_url"]);
  // }
  //       for (int j = 0; j < mediasourcelist.length; j++) {
  //         if (mediasourcelist[j].description == "Recently Played") {
  //           recent.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "New Releases") {
  //           newrelease.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "BBC Radio One") {
  //           BBCOne.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "Kannada Channel") {
  //           kannada.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "Hindi Channels") {
  //           Hindi.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "Devotional channels") {
  //           Devotional.add(mediasourcelist[j]);
  //         } else {
  //           trending.add(mediasourcelist[j]);
  //         }
  //       }
  //     }
  //   }
  // }