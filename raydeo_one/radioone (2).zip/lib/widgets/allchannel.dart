import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_launcher_icons/xml_templates.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:get/get.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:raydeo_one/landingpages/homepage.dart';
import 'package:raydeo_one/mqtt/mqttconnection.dart';
import 'dart:math' as math;
import '../backgroundplay/frp_player.dart';
import '../backgroundplay/mainplay.dart';
import '../main.dart';
import 'dart:math';

Random random = new Random();
Widget MyListViewBuilder(FlutterRadioPlayer flutterRadioPlayers,
    FRPSource frpSources, List<MediaSources> allmedia, context) {
  print("alldata:${allmedia}");
  return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      itemCount: mediasourcelist.length,
      // dragStartBehavior: DragStartBehavior.start,
      itemBuilder: (BuildContext ctx, index) {
        MediaSources mediaItem = mediasourcelist[index];

        // SelectedMedia = FRPSource(mediaSources: [mediaItem]);
        return Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            InkWell(
              onTap: () {
                // MQTTConnections()
                //     .subscribeToTopicMethod("${alldata[index]["channel_id"]}");
                print("channel_id:${alldata[index]["channel_id"]}");
                print("channel_name:${alldata[index]["channel_name"]}");
                // if (play.value == true)
                onplay.value = false;
                currentindx = alldata[index]["total_number_of_subscribers"];
                //selected = allmedia[index].description!;
                print("mediaItem.description:${selected}");
                flutterRadioPlayers.addMediaSources(frpSources);
                flutterRadioPlayers.seekToMediaSource(index, true);
                flutterRadioPlayers.useIcyData(true);
                miniplayerOpen.value = !miniplayerOpen.value;

                firsttime.value = false;
                nameOfChannel.value = mediaItem.title!;
                descOfChannel.value = mediaItem.description!;
                urlOfChannel.value = mediaItem.url!;

                print("frpSources:${frpSources.mediaSources!.isEmpty}");
                print("nameOfChannel:${nameOfChannel}");
                print("descOfChannel:${descOfChannel}");
                print("firsttime:${firsttime}");

                controllerStack.animateToHeight(
                    state: PanelState.MAX,
                    duration: const Duration(milliseconds: 500));
                // ontapchannel();
              },
              child: Stack(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * .4,
                    height: MediaQuery.of(context).size.height * .2,
                    margin: const EdgeInsets.all(8),
                    // padding: const EdgeInsets.all(5),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: Color(
                                (math.Random().nextDouble() * 0xFFFFFF).toInt())
                            .withOpacity(1.0),
                        borderRadius: BorderRadius.circular(15)),
                    child: Text(
                      "${mediaItem.title}",
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 75,
                      height: 35,
                      decoration: BoxDecoration(
                          color: Colors.black38,
                          borderRadius: BorderRadius.circular(20)),
                      margin: EdgeInsets.only(
                          left: MediaQuery.of(context).size.width * 0.28,
                          top: MediaQuery.of(context).size.width * 0.025),
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Row(
                            children: [
                              Icon(
                                Icons.remove_red_eye,
                                color: Colors.white,
                              ),
                              Text(
                                " ${alldata[index]["total_number_of_subscribers"]}",
                                style: TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      });
}
