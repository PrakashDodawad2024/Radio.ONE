import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_source_modal.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:raydeo_one/landingpages/homepage.dart';
import 'package:raydeo_one/mqtt/mqttconnection.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:volume_controller/volume_controller.dart';
import '../main.dart';
import '../main.dart';
import '../main.dart';
import '../mqtt/mqttregister.dart';
import '../widgets/minimusic.dart';
import '../widgets/musicplayer.dart';
import 'frp_player.dart';
import 'dart:ui' as ui;

final FlutterRadioPlayer flutterRadioPlayer = FlutterRadioPlayer();

final FRPSource frpSource = FRPSource(mediaSources: mediasourcelist);

class playback extends StatefulWidget {
  const playback({Key? key}) : super(key: key);

  @override
  State<playback> createState() => playbackState();
}

class playbackState extends State<playback> {
  double _setVolumeValue = 0;
  String frpStatus = "flutter_radio_stopped";

  // selected == "Recently Played"
  //     ? recent
  //     : selected == "New Releases"
  //         ? newrelease
  //         : selected == "BBC Radio One"
  //             ? BBCOne
  //             : selected == "Kannada Channel"
  //                 ? kannada
  //                 : selected == "Hindi Channels"
  //                     ? Hindi
  //                     : selected == "Devotional Channels"
  //                         ? Devotional
  //                         : selected == "Trending Now"
  //                             ? trending
  //                             :

  @override
  void initState() {
    super.initState();
    flutterRadioPlayer.initPlayer();
    // flutterRadioPlayer.addMediaSources(frpSource);
    callmqtt();
  }

  callmqtt() async {
    // await Mqtt().registerUserMethod();
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var connectionDetail =
        jsonDecode("${sharedPreferences.getString('allconnectionData')}");

    // await MQTTConnections().connectToMQTTMethod(
    //     connectionDetail['ip_address'],
    //     connectionDetail['port'],
    //     connectionDetail['user_name'],
    //     connectionDetail['password']);
    //Future.delayed(Duration(seconds: 10), () {});
  }
  // for (int i = 0; i < alldata.length; i++) {
  //   categories.add(alldata[i]["channel_category"]);
  //   urls.add(alldata[i]["channel_stream_url"]);
  // }
  // setState(() {
  //   mediasourcelist.add(MediaSources(
  //     url: alldata[i]["channel_stream_url"],
  //     description: alldata[i]["channel_category"],
  //     isPrimary: i == 0 ? true : false,
  //     title: alldata[i]["channel_name"],
  //     isAac: true,
  //   ));
  // });

  // } else {
  //   print("hereeeeeeee");
  // }
  // for (int j = 0; j < mediasourcelist.length; j++) {
  //   if (mediasourcelist[j].description == "Recently Played") {
  //     recent.add(MediaSources(
  //       url: mediasourcelist[j].url,
  //       description: mediasourcelist[j].description,
  //       isPrimary: j == 0 ? true : false,
  //       title: mediasourcelist[j].title,
  //       isAac: true,
  //     ));
  //   } else if (mediasourcelist[j].description == "New Releases") {
  //     newrelease.add(MediaSources(
  //       url: mediasourcelist[j].url,
  //       description: mediasourcelist[j].description,
  //       isPrimary: j == 0 ? true : false,
  //       title: mediasourcelist[j].title,
  //       isAac: true,
  //     ));
  //   } else if (mediasourcelist[j].description == "BBC Radio One") {
  //     BBCOne.add(MediaSources(
  //       url: mediasourcelist[j].url,
  //       description: mediasourcelist[j].description,
  //       isPrimary: j == 0 ? true : false,
  //       title: mediasourcelist[j].title,
  //       isAac: true,
  //     ));
  //   } else if (mediasourcelist[j].description == "Kannada Channel") {
  //     kannada.add(MediaSources(
  //       url: mediasourcelist[j].url,
  //       description: mediasourcelist[j].description,
  //       isPrimary: j == 0 ? true : false,
  //       title: mediasourcelist[j].title,
  //       isAac: true,
  //     ));
  //   } else if (mediasourcelist[j].description == "Hindi Channels") {
  //     Hindi.add(MediaSources(
  //       url: mediasourcelist[j].url,
  //       description: mediasourcelist[j].description,
  //       isPrimary: j == 0 ? true : false,
  //       title: mediasourcelist[j].title,
  //       isAac: true,
  //     ));
  //   } else if (mediasourcelist[j].description == "Devotional channels") {
  //     Devotional.add(MediaSources(
  //       url: mediasourcelist[j].url,
  //       description: mediasourcelist[j].description,
  //       isPrimary: j == 0 ? true : false,
  //       title: mediasourcelist[j].title,
  //       isAac: true,
  //     ));
  //   } else {
  //     trending.add(MediaSources(
  //       url: mediasourcelist[j].url,
  //       description: mediasourcelist[j].description,
  //       isPrimary: j == 0 ? true : false,
  //       title: mediasourcelist[j].title,
  //       isAac: true,
  //     ));
  //   }
  // }
  // print("mediasourcelist$mediasourcelist");
  // print("bbcone$BBCOne");

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: MyHomePage(
      flutterRadioPlayers: flutterRadioPlayer,
      frpSource: frpSource,
      useIcyData: true,
    ));
  }

  addSourceFunction() {
    return flutterRadioPlayer.addMediaSources(frpSource);
  }

  updateCurrentStatus(status) {
    frpStatus = status;
  }
}
