import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_radio_player/flutter_radio_player.dart';
import 'package:flutter_radio_player/models/frp_player_event.dart';
import 'package:get/get.dart';
import 'dart:math' as math;

import 'package:raydeo_one/main.dart';

class FRPPlayerControls extends StatefulWidget {
  final FlutterRadioPlayer flutterRadioPlayer;
  final Function addSourceFunction;
  final Function nextSource;
  final Function prevSource;

  final Function(String status) updateCurrentStatus;

  const FRPPlayerControls({
    Key? key,
    required this.flutterRadioPlayer,
    required this.addSourceFunction,
    required this.nextSource,
    required this.prevSource,
    required this.updateCurrentStatus,
  }) : super(key: key);

  @override
  State<FRPPlayerControls> createState() => _FRPPlayerControlsState();
}

class _FRPPlayerControlsState extends State<FRPPlayerControls> {
  String latestPlaybackStatus = "flutter_radio_stopped";

  double volume = 0.5;
  final nowPlayingTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: widget.flutterRadioPlayer.frpEventStream,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          FRPPlayerEvents frpEvent =
              FRPPlayerEvents.fromJson(jsonDecode(snapshot.data as String));
          if (kDebugMode) {
            print("====== EVENT START =====");
            print("Playback status: ${frpEvent.playbackStatus}");
            print("Icy details: ${frpEvent.icyMetaDetails}");
            print("Other: ${frpEvent.data}");
            print("====== EVENT END =====");
          }
          if (frpEvent.playbackStatus != null) {
            latestPlaybackStatus = frpEvent.playbackStatus!;
            widget.updateCurrentStatus(latestPlaybackStatus);
          }
          if (frpEvent.icyMetaDetails != null) {
            currentPlaying.value = frpEvent.icyMetaDetails!;
            nowPlayingTextController.text = frpEvent.icyMetaDetails!;
          }
          var statusIcon = const Icon(
            Icons.pause_circle_filled,
            size: 45,
            color: Colors.white,
          );
          switch (frpEvent.playbackStatus) {
            case "flutter_radio_playing":
              statusIcon = const Icon(
                Icons.pause_circle_filled,
                size: 45,
                color: Colors.white,
              );
              break;
            case "flutter_radio_paused":
              statusIcon = const Icon(
                Icons.play_circle_filled,
                size: 45,
                color: Colors.white,
              );
              break;
            case "flutter_radio_loading":
              statusIcon = const Icon(
                Icons.refresh_rounded,
                size: 45,
                color: Colors.white,
              );
              break;
            case "flutter_radio_stopped":
              statusIcon = const Icon(
                Icons.play_circle_filled,
                size: 45,
                color: Colors.white,
              );
              break;
          }
          return Obx(
            () => Column(
              children: [
                Container(
                  //  padding: EdgeInsets.only(bottom: 30),
                  color: Colors.grey.shade800.withOpacity(0.5),
                  // child: Text('$height, $percentage'),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.keyboard_double_arrow_up_rounded,
                        size: 30,
                        color: Colors.blueGrey,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            const SizedBox(
                              width: 20,
                            ),
                            Container(
                              height: 55,
                              width: 55,
                              color: Color(
                                      (math.Random().nextDouble() * 0xFFFFFF)
                                          .toInt())
                                  .withOpacity(1.0),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  "$nameOfChannel",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),

                                //  Text("$descOfChannel"),
                              ],
                            ),
                            const Spacer(),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: IconButton(
                                onPressed: () async {
                                  widget.flutterRadioPlayer.playOrPause();
                                  resetNowPlayingInfo();
                                },
                                icon: statusIcon,
                              ),
                            ),
                            const SizedBox(
                              width: 20,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }
        return SizedBox(
          height: 0,
        );
      },
    );
  }

  void resetNowPlayingInfo() {
    currentPlaying.value = "";
  }
}
