import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:volume_controller/volume_controller.dart';

import '../landingpages/homepage.dart';
import '../main.dart';

double _setVolumeValue = 0;
Widget musicplayer(
  context,
  ontapplay,
  setState,
) {
  return Obx(
    () => Stack(
      children: [
        Container(
          width: MediaQuery.of(context).size.width * 1,
          height: MediaQuery.of(context).size.height * 1,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const Icon(
                Icons.keyboard_double_arrow_down_rounded,
                size: 45,
                color: Colors.white,
              ),
              Text(
                NameOfChannel,
                style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              Container(
                decoration: BoxDecoration(
                    color: bgColor, borderRadius: BorderRadius.circular(20)),
                width: MediaQuery.of(context).size.width * .8,
                height: MediaQuery.of(context).size.width * .8,
              ),
              Container(
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20)),
                width: MediaQuery.of(context).size.width * .85,
                height: MediaQuery.of(context).size.height * .15,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    InkWell(
                      onTap: () {
                        ontapplay();
                      },
                      child: Obx(
                        () => Icon(
                          (playing.value == true)
                              ? Icons.stop_rounded
                              : Icons.play_arrow_rounded,
                          color: Colors.white,
                          size: 60,
                        ),
                      ),
                    ),
                    Slider(
                      activeColor: Colors.white,
                      min: 0,
                      max: 1,
                      onChanged: (double value) {
                        _setVolumeValue = value;
                        VolumeController().setVolume(_setVolumeValue);
                        setState(() {});
                      },
                      value: _setVolumeValue,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (loader.value == true)
          const Opacity(
            opacity: 0.5,
            child: ModalBarrier(dismissible: false, color: Colors.white),
          ),
        if (loader.value == true)
          Center(
            child: Container(
              width: 50,
              height: 50,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: CircularProgressIndicator(
                color: Colors.blue,
                strokeWidth: 5,
              ),
            ),
          ),
      ],
    ),
  );
}
