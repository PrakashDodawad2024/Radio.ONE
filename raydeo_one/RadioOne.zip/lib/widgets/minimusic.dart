import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:math' as math;
import '../landingpages/homepage.dart';
import '../main.dart';

Widget minimusic(ontapmini) {
  return Obx(
    () => Container(
      //  padding: EdgeInsets.only(bottom: 30),
      color: Colors.grey.shade800.withOpacity(0.5),
      // child: Text('$height, $percentage'),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const Icon(
            Icons.keyboard_double_arrow_up_rounded,
            size: 30,
            color: Colors.white,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                const SizedBox(
                  width: 20,
                ),
                Container(
                  height: 55,
                  width: 55,
                  color: Color((math.Random().nextDouble() * 0xFFFFFF).toInt())
                      .withOpacity(1.0),
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  NameOfChannel,
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
                const Spacer(),
                loader.value == true
                    ? CircularProgressIndicator()
                    : InkWell(
                        onTap: () {
                          ontapmini();
                        },
                        child: Icon(
                          (playing.value == true)
                              ? Icons.stop_rounded
                              : Icons.play_arrow_rounded,
                          color: Colors.white,
                          size: 55,
                        ),
                      )
              ],
            ),
          ),
        ],
      ),
    ),
  );
}
