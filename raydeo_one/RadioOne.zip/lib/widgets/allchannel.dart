import 'package:flutter/material.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:raydeo_one/landingpages/homepage.dart';
import 'dart:math' as math;
import '../main.dart';

Widget MyListViewBuilder(setState, alldata, ontapchannel, context) {
  return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      itemCount: alldata.length,
      itemBuilder: (BuildContext ctx, index) {
        return Column(
          children: [
            InkWell(
              onTap: () {
                // // startminiplayerOpen();
                // setState() {
                //   currentindex = alldata[index];
                // }
                Firsttime = false;
                NameOfChannel = alldata[index]["channel_name"];
                urlOfChannel = alldata[index]["channel_stream_url"];
                // print(NameOfChannel);
                // print('prakash');

                ontapchannel();
              },
              child: alldata[index]["channel_category"] == 'Recently Played'
                  ? Container(
                      width: MediaQuery.of(context).size.width * .4,
                      height: MediaQuery.of(context).size.height * .2,
                      margin: const EdgeInsets.all(8),
                      padding: const EdgeInsets.all(5),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: Color((math.Random().nextDouble() * 0xFFFFFF)
                                  .toInt())
                              .withOpacity(1.0),
                          borderRadius: BorderRadius.circular(15)),
                      child: Text(
                        "${alldata[index]["channel_name"]}",
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                    )
                  : alldata[index]["channel_category"] == 'New Releases'
                      ? Container(
                          width: MediaQuery.of(context).size.width * .4,
                          height: MediaQuery.of(context).size.height * .2,
                          margin: const EdgeInsets.all(8),
                          padding: const EdgeInsets.all(5),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: Color(
                                      (math.Random().nextDouble() * 0xFFFFFF)
                                          .toInt())
                                  .withOpacity(1.0),
                              borderRadius: BorderRadius.circular(15)),
                          child: Text(
                            "${alldata[index]["channel_name"]}",
                            style: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                          ),
                        )
                      : alldata[index]["channel_category"] == 'BBC Radio One'
                          ? Container(
                              width: MediaQuery.of(context).size.width * .4,
                              height: MediaQuery.of(context).size.height * .2,
                              margin: const EdgeInsets.all(8),
                              padding: const EdgeInsets.all(5),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  color: Color((math.Random().nextDouble() *
                                              0xFFFFFF)
                                          .toInt())
                                      .withOpacity(1.0),
                                  borderRadius: BorderRadius.circular(15)),
                              child: Text(
                                "${alldata[index]["channel_name"]}",
                                style: const TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                                textAlign: TextAlign.center,
                              ),
                            )
                          : alldata[index]["channel_category"] == 'Trending Now'
                              ? Container(
                                  width: MediaQuery.of(context).size.width * .4,
                                  height:
                                      MediaQuery.of(context).size.height * .2,
                                  margin: const EdgeInsets.all(8),
                                  padding: const EdgeInsets.all(5),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Color((math.Random().nextDouble() *
                                                  0xFFFFFF)
                                              .toInt())
                                          .withOpacity(1.0),
                                      borderRadius: BorderRadius.circular(15)),
                                  child: Text(
                                    "${alldata[index]["channel_name"]}",
                                    style: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.center,
                                  ),
                                )
                              : SizedBox(
                                  height: 0,
                                ),
            ),
          ],
        );
      });
}
