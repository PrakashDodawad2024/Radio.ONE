import 'dart:io';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miniplayer/miniplayer.dart';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:volume_controller/volume_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'landingpages/homepage.dart';
import 'mqtt/mqttregister.dart';

Color bgColor = Colors.purple;
bool? isFirsttime;
bool Firsttime = true;
Box? channel;
Box? clientdetails;
Box? allmessages;
String NameOfChannel = '';
String urlOfChannel = '';
Color maincolor = const Color.fromARGB(146, 57, 42, 65);
Future<String?> _getId() async {
  var deviceInfo = DeviceInfoPlugin();
  if (Platform.isIOS) {
    // import 'dart:io'
    var iosDeviceInfo = await deviceInfo.iosInfo;
    return iosDeviceInfo.identifierForVendor; // unique ID on iOS
  } else if (Platform.isAndroid) {
    var androidDeviceInfo = await deviceInfo.androidInfo;
    return androidDeviceInfo.id; // unique ID on Android
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  isFirsttime = sharedPreferences.getBool("isFirsttime") ?? true;
  await Hive.initFlutter();
  await _getId();
  channel = await Hive.openBox("channel");
  clientdetails = await Hive.openBox("clientdetails");
  allmessages = await Hive.openBox("allmessages");
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primaryColor: maincolor,
      ),
      home: AnimatedSplashScreen(
        backgroundColor: Colors.black,
        splashIconSize: 250,
        splash: Center(
          child: Column(
            children: [
              const Icon(
                Icons.radio,
                color: Colors.lightBlue,
                size: 150,
              ),
              RichText(
                text: const TextSpan(
                  text: 'Radio.One ',
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.lightBlue),
                  // children: const <TextSpan>[],
                ),
              ),
            ],
          ),
        ),
        duration: 250,
        nextScreen: MyHomePage(),
        splashTransition: SplashTransition.sizeTransition,
      ),
    );
  }
}
