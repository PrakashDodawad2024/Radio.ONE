import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:event/event.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:http/http.dart' as http;

import 'package:shared_preferences/shared_preferences.dart';

import '../main.dart';

String? finalConnectionStatus;
MqttServerClient? clientDetails;
BuildContext? newcontext;
var maxTries = 3;
var currentTry = 1;
StreamSubscription<List<MqttReceivedMessage<MqttMessage>>>? listenerObject;

class MQTTConnections {
  Future connectToMQTTMethod(ipadres, port, username, pass) async {
    print("ipadres:$ipadres");
    print("port:$port");
    print("username:$username");
    print("pass:$pass");
    print("Connecting to mqtt");

    try {
      clientDetails = MqttServerClient.withPort(
        ipadres,
        username,
        port,
      );
      print("clientDetails${clientDetails!.clientIdentifier}");
      clientDetails!.logging(on: true);
      // MqttConnectFlags()
      clientDetails!.onConnected = () => onConnected();
      clientDetails!.onDisconnected = () => onDisconnected();
      clientDetails!.onSubscribed = ((topic) => {
            // print("**Subscribed To The Topic ${topic}*"),
          });
      clientDetails!.onSubscribeFail = ((topic) => {
            // print("*Failed To Subscribe To Topic ${topic}**"),
          });
      clientDetails!.clientIdentifier = username;
      clientDetails!.onAutoReconnect = onAutoReconnect();
      clientDetails!.autoReconnect = false;
      final connMessage = MqttConnectMessage().withClientIdentifier(username);
      clientDetails!.connectionMessage = connMessage;

      try {
        await clientDetails!.connect(username, pass);
        await subscribeToTopicsAndListenMethod();
      } on NoConnectionException catch (e) {
        print(e);
        clientDetails!.disconnect();
      } on SocketException catch (e) {
        print('EXAMPLE::socket exception - $e');
        clientDetails!.disconnect();
      }
    } catch (error) {
      print(error);
    }
  }

  subscribeToTopicsAndListenMethod() async {
    clientDetails!.subscribe("xvzsWFDZ5N", MqttQos.atLeastOnce);
    var channeldata = await getChannelDetailsMethod("xvzsWFDZ5N");
    log("channeldata${channeldata}");
  }

  Future getChannelDetailsMethod(channel_id) async {
    try {
      final SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      final device_id = sharedPreferences.getString('device_id');
      final userMobileNumber = sharedPreferences.getString('UserMobileNumber');
      var url = Uri.parse(
          'https://bjzrb8a47c.execute-api.ap-south-1.amazonaws.com/production/getchanneldetails');
      var response = await http.post(url,
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': 'XlbJLSIbFn8A3yEi4bcNX5oWbuDp2H9x8a7IxVA0',
          },
          body: json.encode(
              {"client_id": "${device_id}", "channel_id": "${channel_id}"}));
      if (json.decode(response.body)['status'] == 'success') {
        return json.decode(response.body)['response']['channel_details'];
      } else {
        return 'NOT_APPLICABLE';
      }
    } catch (error) {
      return 'NOT_APPLICABLE';
    }
  }

  MQTTSubscribeMethod(channel_id) async {
    try {
      await clientDetails!.subscribe(channel_id, MqttQos.atLeastOnce);
      return 'SUCCESS';
    } catch (error) {
      print("joining error:${error.toString()}");
      return 'FAILURE';
    }
  }

  MQTTDisconnectMethod() {
    try {
      if (clientDetails != null) {
        clientDetails?.disconnect();
        return 'SUCCESS';
      } else {
        return 'FAILURE';
      }
    } catch (error) {
      print(error);
      return 'FAILURE';
    }
  }

  static void pong() {
    print('Ping response client callback invoked');
  }

  onAutoReconnect() {
    listenerObject?.cancel();
    print("MQTT is Reconnecting !!!");

    setSharedPrefrerences('CONNECTED');
  }

  onConnected() {
    print("MQTT is Getting Connected !!!");
    listenToMessages();

    setSharedPrefrerences('CONNECTED');
  }

  onDisconnected() async {
    print("&&&&&&&& Got Disconnected &&&&&&&&&");

    setSharedPrefrerences('DISCONNECTED');
    listenerObject?.cancel();
  }

  onSubscribed(topic) {
    print("&&&&&&&&&&SubScribed&&&&&&&&&&&&&");
    // print(topic);
    print("*****");
  }

  onSubscribeFail(topic) {
    print("*Failed To Subscribed!!!*");
    // print(topic);
  }

  getConnetctionStatus() {
    var status = clientDetails!.connectionStatus!.state;
    return status;
  }

  Future pushDataToHive(hiveChannelList, messageItem) async {
    try {
      var channelObject = await channel?.get(messageItem['channel_id']);
      log("channelDetails:$channelObject");
      await channel!.put(channelObject['channel_id'], channelObject);
    } catch (error) {
      print(error);
    }
  }

  listenToMessages() async {
    print("******Listener Got Initiated********");
    var channelObject = await channel?.get('xvzsWFDZ5N');
    log("channelDetails:$channelObject");

    listenerObject = clientDetails!.updates
        ?.listen((List<MqttReceivedMessage<MqttMessage>> event) async {
      print("**Iam Listening**");

      var receivedMessage = event[0].payload as MqttPublishMessage;
      final messageItem = json.decode(
        MqttPublishPayload.bytesToStringAsString(
            receivedMessage.payload.message),
      );
      log("message:$messageItem");

      if (receivedMessage.payload.message.isEmpty) return;
      messageItem['channel_message'] = utf8.decode(
          (messageItem["channel_message"] as String)
              .replaceAll(RegExp("[^0-9,]"), "")
              .replaceAll(" ", "")
              .split(",")
              .map((string) => int.parse(string))
              .toList());
      log("messagedecode:${jsonDecode(messageItem['channel_message'])}");
      if (messageItem != null) {
        await allmessages!.delete("allmessages");
        await allmessages!.put("allmessages", messageItem);
        log("messageItemmessageItemmessageItem${allmessages!.get("allmessages")}");
      }

      try {} catch (error) {
        print(error);
      }
    });
  }

  setSharedPrefrerences(connection_status) async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    sharedPreferences.setString("connection_status", connection_status);
  }

  getUserDetails() async {
    SharedPreferences shared = await SharedPreferences.getInstance();
    return jsonDecode(shared.getString('userDetails')!);
  }

  internalDisconnect() {}
}
