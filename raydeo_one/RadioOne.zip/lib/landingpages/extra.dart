// import 'dart:convert';
// import 'dart:math' as math;
// import 'dart:math';
// import 'dart:ui' as ui;
// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:miniplayer/miniplayer.dart';
// import 'package:volume_controller/volume_controller.dart';

// import '../main.dart';
// import '../mqtt/mqttconnection.dart';
// import '../mqtt/mqttregister.dart';
// import '../widgets/listofchannel.dart';

// class MyHomeP extends StatefulWidget {
//   @override
//   State<MyHomeP> createState() => _MyHomePageState();
// }

// class _MyHomePageState extends State<MyHomeP> {
//   RxBool miniplayerOpen = false.obs;
//   RxBool playing = false.obs;
//   RxList alldata = [].obs;
//   final controllerStack = MiniplayerController();
//   final _random = new Random();
//   static final AudioPlayer _player = AudioPlayer();
//   double _volumeListenerValue = 0;
//   double _getVolume = 0;
//   double _setVolumeValue = 0;
// // generate a random index based on the list length
//   final titleList = [
//     'Top Picks',
//     'Recently Listened to',
//     'International',
//     'Hindi Stations',
//   ];

//   List stationNames = [
//     {
//       "name": 'Radio Mirchi',
//       "color": Colors.red,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_fourfm"
//     },
//     {
//       "name": 'BBC Radio One',
//       "color": Colors.amber,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_fourfm"
//     },
//     {
//       "name": 'Tropical Beats FM',
//       "color": Colors.purple,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_fourlw"
//     },
//     {
//       "name": 'Fever FM',
//       "color": Colors.green,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_four_extra"
//     },
//   ];

//   List stationNames1 = [
//     {
//       "name": 'R&B FM',
//       "color": Colors.brown,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_1xtra"
//     },
//     {
//       "name": 'Big FM',
//       "color": Colors.cyan,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_1xtra"
//     },
//     {
//       "name": 'Jazz FM',
//       "color": Colors.white,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_1xtra"
//     },
//     {
//       "name": 'All India Radio',
//       "color": Colors.red,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_1xtra"
//     },
//   ];

//   List stationNames2 = [
//     {
//       "name": 'Radio One',
//       "color": Colors.blue,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_two"
//     },
//     {
//       "name": 'Hip-Hop Beats FM',
//       "color": Colors.pink,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_two"
//     },
//     {
//       "name": 'BBC Radio One',
//       "color": Colors.green,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_two"
//     },
//     {
//       "name": 'Red FM',
//       "color": Colors.brown,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_two"
//     },
//   ];

//   List stationNames3 = [
//     {
//       "name": 'Radio City',
//       "color": Colors.indigo,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_three"
//     },
//     {
//       "name": 'Hit FM',
//       "color": Colors.yellow,
//       "channelurl":
//           "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_five_live_sports_extra"
//     },
//     {
//       "name": 'Soho Radio',
//       "color": Colors.teal,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_6music"
//     },
//     {
//       "name": 'Worldwide FM',
//       "color": Colors.brown,
//       "channelurl": "http://stream.live.vc.bbcmedia.co.uk/bbc_radio_three"
//     },
//   ];

//   @override
//   void initState() {
//     AudioPlayer.global.setGlobalAudioContext(_getAudioContext());
//     // AudioPlayer.global.setGlobalAudioContext(_getAudioContext());
//     // VolumeController().listener((volume) {
//     //   setState(() => _volumeListenerValue = volume);
//     // });

//     // _flutterShazamKitPlugin.configureShazamKitSession().then((value) {
//     //   // startDetection();
//     //   _flutterShazamKitPlugin.onMatchResultDiscovered((result) {
//     //     if (result is Matched) {
//     //       print(result.mediaItems);
//     //       // setState(() {
//     //       //   _mediaItems.insertAll(0, result.mediaItems);
//     //       // });
//     //     } else if (result is NoMatch) {}
//     //   });
//     //   _flutterShazamKitPlugin.onDetectStateChanged((state) {
//     //     setState(() {
//     //       // _state = state;
//     //     });
//     //   });
//     //   _flutterShazamKitPlugin.onError((error) {
//     //     print(error.message);
//     //   });
//     // });

//     // VolumeController().getVolume().then((volume) => _setVolumeValue = volume);
//     // TODO: implement initState
//     super.initState();
//     callmqtt();
//   }

//   callmqtt() async {
//     await Mqtt().registerUserMethod();
//     final allresponse = await allmessages!.get("allmessages");
//     if (allresponse != null) {
//       final decodeddata = jsonDecode(allresponse["channel_message"]);
//       final alldecodeddata = jsonDecode(decodeddata["description"]);
//       print("alldecodeddata${alldecodeddata}");
//       alldata.value = alldecodeddata;
//       print("alldata$alldata");
//     }
//   }

//   @override
//   void dispose() {
//     VolumeController().removeListener();
//     super.dispose();
//   }

//   // startDetection() {
//   //   _flutterShazamKitPlugin.startDetectionWithMicrophone();
//   // }

//   AudioContext _getAudioContext() {
//     return const AudioContext(
//         android: AudioContextAndroid(
//           isSpeakerphoneOn: false,
//           stayAwake: true,
//           contentType: AndroidContentType.music,
//           usageType: AndroidUsageType.media,
//           audioFocus: AndroidAudioFocus.gain,
//         ),
//         iOS: AudioContextIOS(
//             category: AVAudioSessionCategory.soloAmbient,
//             options: [
//               // AVAudioSessionOptions.defaultToSpeaker,
//             ]
//             // +
//             // [AVAudioSessionOptions.allowAirPlay] +
//             // [AVAudioSessionOptions.allowBluetooth] +
//             // [AVAudioSessionOptions.allowBluetoothA2DP]
//             ));
//   }

//   startminiplayerOpen() {
//     playing.value = true;
//     _player
//         .play(UrlSource('https://stream.live.vc.bbcmedia.co.uk/bbc_radio_one'));
//     // startDetection();
//   }

//   stopminiplayerOpen() {
//     playing.value = false;
//     _player.stop();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MiniplayerWillPopScope(
//       onWillPop: () async {
//         //  NavigatorState navigator = _navigatorKey.currentState;
//         // if (!navigator.canPop()) return true;
//         // navigator.pop();
//         return false;
//       },
//       child: Obx(
//         () => Scaffold(
//           body: Stack(
//             children: <Widget>[
//               Container(
//                 padding: const EdgeInsets.only(top: 30),
//                 color: Colors.black,
//                 height: MediaQuery.of(context).size.height * 1,
//                 child: SingleChildScrollView(
//                   child: Column(
//                     children: [
//                       for (int i = 0; i < 4; i++)
//                         Column(mainAxisSize: MainAxisSize.min, children: [
//                           if (i == 0)
//                             const SizedBox(
//                               height: 50,
//                             ),
//                           if (i == 0)
//                             Container(
//                               margin: const EdgeInsets.only(left: 20),
//                               width: MediaQuery.of(context).size.width * 1,
//                               child: const Text(
//                                 'Radio One',
//                                 style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 38,
//                                     fontWeight: FontWeight.bold),
//                                 textAlign: TextAlign.start,
//                               ),
//                             ),
//                           const SizedBox(
//                             height: 20,
//                           ),
//                           Container(
//                             margin: const EdgeInsets.only(left: 20),
//                             width: MediaQuery.of(context).size.width * 1,
//                             child: Text(
//                               '${alldata[i]}',
//                               style: const TextStyle(
//                                   color: Colors.white,
//                                   fontSize: 25,
//                                   fontWeight: FontWeight.bold),
//                               textAlign: TextAlign.start,
//                             ),
//                           ),
//                           const SizedBox(
//                             height: 10,
//                           ),
//                           Container(
//                             margin: const EdgeInsets.only(left: 10),
//                             height: MediaQuery.of(context).size.height * .2,
//                             child: ListView.builder(
//                                 shrinkWrap: true,
//                                 scrollDirection: Axis.horizontal,
//                                 itemCount: 4,
//                                 itemBuilder: (BuildContext ctx, index) {
//                                   return InkWell(
//                                     onTap: () {
//                                       // startminiplayerOpen();
//                                       setState(() {
//                                         bgColor = (i == 0)
//                                             ? (stationNames[index]['color'])
//                                             : (i == 1)
//                                                 ? (stationNames1[index]
//                                                     ['color'])
//                                                 : (i == 2)
//                                                     ? (stationNames2[index]
//                                                         ['color'])
//                                                     : (stationNames3[index]
//                                                         ['color']);
//                                       });
//                                       controllerStack.animateToHeight(
//                                           state: PanelState.MAX,
//                                           duration: const Duration(
//                                               milliseconds: 500));
//                                     },
//                                     child: Container(
//                                       width: MediaQuery.of(context).size.width *
//                                           .4,
//                                       margin: const EdgeInsets.all(8),
//                                       padding: const EdgeInsets.all(5),
//                                       alignment: Alignment.center,
//                                       decoration: BoxDecoration(
//                                           color: (i == 0)
//                                               ? Color((math.Random()
//                                                               .nextDouble() *
//                                                           0xFFFFFF)
//                                                       .toInt())
//                                                   .withOpacity(1.0)
//                                               : (i == 1)
//                                                   ? Color((math.Random()
//                                                                   .nextDouble() *
//                                                               0xFFFFFF)
//                                                           .toInt())
//                                                       .withOpacity(1.0)
//                                                   : (i == 2)
//                                                       ? Color((math.Random()
//                                                                       .nextDouble() *
//                                                                   0xFFFFFF)
//                                                               .toInt())
//                                                           .withOpacity(1.0)
//                                                       : Color((math.Random()
//                                                                       .nextDouble() *
//                                                                   0xFFFFFF)
//                                                               .toInt())
//                                                           .withOpacity(1.0),
//                                           borderRadius:
//                                               BorderRadius.circular(15)),
//                                       child: Text(
//                                         (i == 0)
//                                             ? "${stationNames[index]['name']}"
//                                             : (i == 1)
//                                                 ? "${stationNames1[index]['name']}"
//                                                 : (i == 2)
//                                                     ? "${stationNames2[index]['name']}"
//                                                     : "${stationNames3[index]['name']}",
//                                         style: const TextStyle(
//                                             fontSize: 20,
//                                             fontWeight: FontWeight.bold),
//                                         textAlign: TextAlign.center,
//                                       ),
//                                     ),
//                                   );
//                                 }),
//                           ),
//                         ]),
//                       Container(
//                         margin: const EdgeInsets.only(left: 20),
//                         width: MediaQuery.of(context).size.width * 1,
//                         child: const Text(
//                           'Testing',
//                           style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 25,
//                               fontWeight: FontWeight.bold),
//                           textAlign: TextAlign.start,
//                         ),
//                       ),
//                       InkWell(
//                         onTap: () {
//                           // startminiplayerOpen();
//                           setState(() {
//                             bgColor = Color(
//                                     (math.Random().nextDouble() * 0xFFFFFF)
//                                         .toInt())
//                                 .withOpacity(1.0);
//                           });
//                           controllerStack.animateToHeight(
//                               state: PanelState.MAX,
//                               duration: const Duration(milliseconds: 500));
//                         },
//                         child: Container(
//                           margin: const EdgeInsets.only(left: 10),
//                           height: MediaQuery.of(context).size.height * .2,
//                           child: AllList(setState, context),
//                         ),
//                       ),
//                       if (miniplayerOpen.value != null)
//                         const SizedBox(
//                           height: 130,
//                         ),
//                     ],
//                   ),
//                 ),
//               ),
//               if (miniplayerOpen.value != null)
//                 Miniplayer(
//                   elevation: 0,
//                   controller: controllerStack,
//                   backgroundColor: bgColor,
//                   minHeight: 110,
//                   maxHeight: MediaQuery.of(context).size.height * 1,
//                   builder: (height, percentage) => ClipRect(
//                     child: BackdropFilter(
//                       filter: ui.ImageFilter.blur(
//                         sigmaX: 20.0,
//                         sigmaY: 20.0,
//                       ),
//                       child: (height != 110)
//                           ? FittedBox(
//                               child: Container(
//                                 width: MediaQuery.of(context).size.width * 1,
//                                 height: MediaQuery.of(context).size.height * 1,
//                                 decoration: BoxDecoration(
//                                   gradient: LinearGradient(
//                                     begin: Alignment.bottomCenter,
//                                     end: Alignment.topCenter,
//                                     colors: [
//                                       Colors.black.withOpacity(0.9),
//                                       Colors.black.withOpacity(0.7),
//                                       Colors.black.withOpacity(0.5),
//                                       Colors.black.withOpacity(0.3),
//                                     ],
//                                   ),
//                                 ),
//                                 child: Column(
//                                   mainAxisAlignment:
//                                       MainAxisAlignment.spaceEvenly,
//                                   children: [
//                                     const Icon(
//                                       Icons.keyboard_double_arrow_down_rounded,
//                                       size: 45,
//                                       color: Colors.white,
//                                     ),
//                                     const Text(
//                                       'BBC RADIO ONE',
//                                       style: TextStyle(
//                                           fontSize: 25,
//                                           fontWeight: FontWeight.bold,
//                                           color: Colors.white),
//                                     ),
//                                     Container(
//                                       decoration: BoxDecoration(
//                                           color: bgColor,
//                                           borderRadius:
//                                               BorderRadius.circular(20)),
//                                       width: MediaQuery.of(context).size.width *
//                                           .8,
//                                       height:
//                                           MediaQuery.of(context).size.width *
//                                               .8,
//                                     ),
//                                     Container(
//                                       decoration: BoxDecoration(
//                                           color: Colors.black.withOpacity(0.5),
//                                           borderRadius:
//                                               BorderRadius.circular(20)),
//                                       width: MediaQuery.of(context).size.width *
//                                           .85,
//                                       height:
//                                           MediaQuery.of(context).size.height *
//                                               .15,
//                                       child: Column(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.spaceEvenly,
//                                         children: [
//                                           InkWell(
//                                             onTap: () {
//                                               if (playing.value == true) {
//                                                 stopminiplayerOpen();
//                                               } else {
//                                                 startminiplayerOpen();
//                                               }
//                                             },
//                                             child: Obx(
//                                               () => Icon(
//                                                 (playing.value == true)
//                                                     ? Icons.stop_rounded
//                                                     : Icons.play_arrow_rounded,
//                                                 color: Colors.white,
//                                                 size: 60,
//                                               ),
//                                             ),
//                                           ),
//                                           Slider(
//                                             activeColor: Colors.white,
//                                             min: 0,
//                                             max: 1,
//                                             onChanged: (double value) {
//                                               _setVolumeValue = value;
//                                               VolumeController()
//                                                   .setVolume(_setVolumeValue);
//                                               setState(() {});
//                                             },
//                                             value: _setVolumeValue,
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             )
//                           : Container(
//                               //  padding: EdgeInsets.only(bottom: 30),
//                               color: Colors.grey.shade800.withOpacity(0.5),
//                               // child: Text('$height, $percentage'),
//                               child: Column(
//                                 mainAxisAlignment: MainAxisAlignment.start,
//                                 children: [
//                                   const Icon(
//                                     Icons.keyboard_double_arrow_up_rounded,
//                                     size: 30,
//                                     color: Colors.white,
//                                   ),
//                                   Row(
//                                     children: [
//                                       const SizedBox(
//                                         width: 20,
//                                       ),
//                                       Container(
//                                         height: 55,
//                                         width: 55,
//                                         color: Colors.purple,
//                                       ),
//                                       const SizedBox(
//                                         width: 10,
//                                       ),
//                                       const Text(
//                                         'The Reminder - The Weeknd',
//                                         style: TextStyle(
//                                             fontSize: 16, color: Colors.white),
//                                       ),
//                                       const Spacer(),
//                                       InkWell(
//                                         onTap: () {
//                                           miniplayerOpen.value =
//                                               !miniplayerOpen.value;
//                                           if (playing.value == true) {
//                                             stopminiplayerOpen();
//                                           } else {
//                                             startminiplayerOpen();
//                                           }
//                                         },
//                                         child: Icon(
//                                           (miniplayerOpen.value == true)
//                                               ? Icons.stop_rounded
//                                               : Icons.play_arrow_rounded,
//                                           color: Colors.white,
//                                           size: 55,
//                                         ),
//                                       )
//                                     ],
//                                   ),
//                                 ],
//                               ),
//                             ),
//                     ),
//                   ),
//                 ),
//               // Container(
//               //   margin: EdgeInsets.only(top: 40),
//               //   child: ElevatedButton(
//               //       style:
//               //           ElevatedButton.styleFrom(backgroundColor: Colors.white),
//               //       onPressed: () {
//               //         startminiplayerOpen();
//               //         // AudioPlayer.global
//               //         //     .setGlobalAudioContext(_getAudioContext());
//               //       },
//               //       child: Text('TEST')),
//               // ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
