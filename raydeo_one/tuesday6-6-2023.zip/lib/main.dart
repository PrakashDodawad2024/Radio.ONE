import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:raydeo_one/themes/themeConstant.dart';
import 'package:uni_links/uni_links.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'landingpages/homepage.dart';
import 'mqtt/mqttconnection.dart';
import 'mqtt/mqttregister.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:firebase_core/firebase_core.dart';

int currentindx = 0;
int changeindex = 0;
bool isloading = false;
bool loadingdata = true;
RxString currentPlaying = "".obs;
RxInt subcount = 1.obs;
RxInt curindex = 0.obs;
RxBool playing = false.obs;
RxBool empty = false.obs;
RxBool homepageloader = true.obs;
RxBool loader = false.obs;
RxBool tapped = false.obs;
RxBool onplay = false.obs;
RxBool onpause = false.obs;
RxBool tapemail = false.obs;
RxBool tapmob = false.obs;
// RxBool isDark = false.obs;
RxBool opennew = false.obs;
RxBool favpage = false.obs;
RxBool nameuser = false.obs;
bool verified = accountdetails!.get(
      "MobNoVerified",
    ) ??
    false;
bool addFavourite = false;
List alldata = [];
List favlist = [];
List displayfavlist = [];
String username = accountdetails!.get(
      "username",
    ) ??
    "Your Name";
String mobileNumber = accountdetails!.get(
      "mobileNumber",
    ) ??
    "Mobile Number";
RxList stationdata = [].obs;
List categories = [];
String changename = "";
RxList categorylist = [
  "Newly Added",
  "Favourites",
].obs;
RxList titlelist = [].obs;
RxList viewmorelist = [].obs;
List urls = [];
Color bgColor = Colors.purple;
Color maincolor = Color.fromARGB(255, 152, 188, 145);
bool? isFirsttime;
bool? isRegistered;
// bool firsttime = true;
bool Firsttimee = true;
Box? channel;
Box? clientdetailBox;
Box? allmessages;
Box? accountdetails;
Box? statiomessages;
Box? favouritelist;
String selected = "";
RxString nameOfChannel = ''.obs;
RxString descOfChannel = ''.obs;
RxString urlOfChannel = ''.obs;
RxString imgurlOfChannel = ''.obs;
RxString idOfChannel = ''.obs;
RxString catgOfChannel = ''.obs;
RxString catgChannel = 'Newly Added'.obs;
bool isDataConnected = true;
bool _initialURILinkHandled = false;
bool viewmore = false;
bool isDark =
    SchedulerBinding.instance.window.platformBrightness == Brightness.dark;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  isFirsttime = sharedPreferences.getBool("isFirsttime") ?? true;
  isRegistered = sharedPreferences.getBool("isRegistered") ?? false;
  await Hive.initFlutter();
  channel = await Hive.openBox("channel");
  clientdetailBox = await Hive.openBox("clientdetailBox");
  allmessages = await Hive.openBox("allmessages");
  statiomessages = await Hive.openBox("statiomessages");
  favouritelist = await Hive.openBox("favouritelist");
  accountdetails = await Hive.openBox("accountdetails");
  initializeDateFormatting().then((_) => runApp(const MyApp()));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  Uri? _initialURI;
  Uri? _currentURI;
  Object? _err;
  StreamSubscription? _streamSubscription;

  @override
  void initState() {
    super.initState();
    deviceThemeListener();
    _initURIHandler();
    _incomingLinkHandler();
    callmqtt();
  }

  deviceThemeListener() {
    final window = WidgetsBinding.instance.window;
    // This callback is called every time the brightness changes.
    window.onPlatformBrightnessChanged = () {
      final brightness = window.platformBrightness;
      print("brightness:$brightness");
      if (brightness == Brightness.dark) {
        setState(() {
          isDark = true;
        });
      } else {
        setState(() {
          isDark = false;
        });
      }
    };
  }

  Future<void> _initURIHandler() async {
    if (!_initialURILinkHandled) {
      _initialURILinkHandled = true;
      // Fluttertoast.showToast(
      //     msg: "Invoked _initURIHandler",
      //     toastLength: Toast.LENGTH_SHORT,
      //     gravity: ToastGravity.BOTTOM,
      //     timeInSecForIosWeb: 1,
      //     backgroundColor: Colors.green,
      //     textColor: Colors.white);
      try {
        final initialURI = await getInitialUri();
        // Use the initialURI and warn the user if it is not correct,
        // but keep in mind it could be `null`.
        if (initialURI != null) {
          debugPrint("Initial URI received $initialURI");
          if (!mounted) {
            return;
          }
          setState(() {
            _initialURI = initialURI;
          });
        } else {
          debugPrint("Null Initial URI received");
        }
      } on PlatformException {
        // Platform messages may fail, so we use a try/catch PlatformException.
        // Handle exception by warning the user their action did not succeed
        debugPrint("Failed to receive initial uri");
      } on FormatException catch (err) {
        if (!mounted) {
          return;
        }
        debugPrint('Malformed Initial URI received');
        setState(() => _err = err);
      }
    }
  }

  /// Handle incoming links - the ones that the app will receive from the OS
  /// while already started.
  void _incomingLinkHandler() {
    if (!kIsWeb) {
      // It will handle app links while the app is already started - be it in
      // the foreground or in the background.
      _streamSubscription = uriLinkStream.listen((Uri? uri) {
        if (!mounted) {
          return;
        }
        debugPrint('Received URI: $uri');
        setState(() {
          _currentURI = uri;
          _err = null;
        });
      }, onError: (Object err) {
        if (!mounted) {
          return;
        }
        debugPrint('Error occurred: $err');
        setState(() {
          _currentURI = null;
          if (err is FormatException) {
            _err = err;
          } else {
            _err = null;
          }
        });
      });
    }
  }

  @override
  void dispose() {
    _streamSubscription?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.resumed:
        print("APP IS RESUMED!!!");
        // RestAPIs.joiningChannel = false;
        // if (RestAPIs.imagePickerOn == false) {
        print("picker is off");
        MQTTConnectionCommonMethod();
        // connectivityResult?.resume();
        // internetConnection?.resume();
        // }

        break;
      case AppLifecycleState.inactive:
        // MQTTConnectionDisconnectMethod();
        // connectivityResult?.pause();
        // internetConnection?.pause();
        listenerObject?.cancel();
        // listenerEvent.unsubscribeAll();
        // unsubscribeToEventListener();

        // listenerEvent.subscribe((args) {});
        break;
      case AppLifecycleState.paused:
        // MQTTConnectionDisconnectMethod();
        // connectivityResult?.pause();
        // internetConnection?.pause();
        listenerObject?.cancel();
        // listenerEvent.unsubscribeAll();
        // listenerEvent.subscribe((args) {});
        break;
      case AppLifecycleState.detached:
        // if (RestAPIs.imagePickerOn == false) {
        print("detached");
        // MQTTConnectionDisconnectMethod();
        // connectivityResult?.pause();
        // internetConnection?.pause();
        listenerObject?.cancel();
        // }
        // listenerEvent.unsubscribeAll();
        break;
    }
  }

  callmqtt() async {
    if (isRegistered == false) {
      await Mqtt().registerUserMethod();
    } else {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      var connectionDetail = await jsonDecode(
          "${sharedPreferences.getString('allconnectionData')}");
      await MQTTConnections().connectToMQTTMethod(
          connectionDetail['ip_address'],
          connectionDetail['port'],
          connectionDetail['user_name'],
          connectionDetail['password']);
      print(
          "**********************************************************************************************************");
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Radio.One',
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      home: AnimatedSplashScreen(
        backgroundColor: Color.fromARGB(255, 50, 50, 50),
        splashIconSize: 300,
        splash: Center(
          child: Column(
            children: [
              Container(
                  color: Color.fromARGB(255, 50, 50, 50),
                  padding: const EdgeInsets.all(15),
                  width: 300,
                  height: 300,
                  child: const ClipRRect(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                      child:
                          Image(image: AssetImage("assets/Raydeo.ONE.png")))),
            ],
          ),
        ),
        duration: 300,
        nextScreen: MyHomePage(),
        splashTransition: SplashTransition.fadeTransition,
      ),
    );
  }

  MQTTConnectionCommonMethod() async {
    if (isRegistered == false) {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      var connectionDetail =
          jsonDecode("${sharedPreferences.getString('allconnectionData')}");
      MQTTConnections().connectToMQTTMethod(
          connectionDetail['ip_address'],
          connectionDetail['port'],
          connectionDetail['user_name'],
          connectionDetail['password']);
    }
  }

  // MQTTConnectionDisconnectMethod() {
  //   try {
  //     if (clientDetails != null) {
  //       clientDetails?.disconnect();
  //       return 'SUCCESS';
  //     } else {
  //       return 'FAILURE';
  //     }
  //   } catch (error) {
  //     print(error);
  //     return 'FAILURE';
  //   }
  // }
}
 // callmqtt() async {
  //   await Mqtt().registerUserMethod();
  //   final allresponse = await allmessages!.get("allmessages");
  //   if (allresponse != null) {
  //     final decodeddata = jsonDecode(allresponse["channel_message"]);
  //     final alldecodeddata = jsonDecode(decodeddata["description"]);
  //     print("alldecodeddata${alldecodeddata}");
  //     alldatas.value = alldecodeddata;
  //     print("alldata$alldatas");
  //     setState(() {
  //       isloading = false;
  //     });
  //     if (alldatas != []) {
  // for (int i = 0; i < alldatas.length; i++) {
  //   category.add(alldatas[i]["channel_category"]);
  //   url.add(alldatas[i]["channel_stream_url"]);
  // }
  //       for (int j = 0; j < mediasourcelist.length; j++) {
  //         if (mediasourcelist[j].description == "Recently Played") {
  //           recent.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "New Releases") {
  //           newrelease.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "BBC Radio One") {
  //           BBCOne.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "Kannada Channel") {
  //           kannada.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "Hindi Channels") {
  //           Hindi.add(mediasourcelist[j]);
  //         } else if (mediasourcelist[j].description == "Devotional channels") {
  //           Devotional.add(mediasourcelist[j]);
  //         } else {
  //           trending.add(mediasourcelist[j]);
  //         }
  //       }
  //     }
  //   }
  // }