import 'package:flutter/material.dart';
import 'package:miniplayer/miniplayer.dart';
import 'package:radio_player/radio_player.dart';
import 'package:raydeo_one/main.dart';
import 'package:raydeo_one/main.dart';
import 'homepage.dart';
import '../mqtt/mqttconnection.dart';
import '../mqtt/mqttregister.dart';

class CustomSearchDelegate extends SearchDelegate {
  final Function setState;

  CustomSearchDelegate({
    Key? key,
    required this.setState,
  });
  RadioPlayer _radioPlayer = RadioPlayer();
  // Demo list to show querying
  List searchTerms = titlelist;

  // first overwrite to
  // clear the search text
  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          query = '';
        },
        icon: Icon(
          Icons.clear,
          color: maincolor,
        ),
      ),
    ];
  }

  // second overwrite to pop out of search menu
  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () {
        close(context, null);
      },
      icon: Icon(
        Icons.arrow_back,
        color: maincolor,
      ),
    );
  }

  // third overwrite to show query result
  @override
  Widget buildResults(BuildContext context) {
    List matchQuery = [];
    for (var title in searchTerms) {
      if (title.toString().toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(title);
      }
    }
    return Container(
      color: Theme.of(context).backgroundColor,
      child: ListView.builder(
        itemCount: alldata.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return (matchQuery
                  .contains(alldata[index]['channel_name'].toString()))
              ? InkWell(
                  onTap: () async {
                    close(context, null);
                    if (status != 'Offline') {
                      if (idOfChannel != "") {
                        await MQTTConnections()
                            .unsubscribeToChannel("$idOfChannel");
                        controllerStack.animateToHeight(
                            state: PanelState.MAX,
                            duration: const Duration(milliseconds: 30));
                      }
                      controllerStack.animateToHeight(
                          state: PanelState.MAX,
                          duration: const Duration(milliseconds: 30));
                      _radioPlayer.stop();
                      loader.value = true;
                      Future.delayed(const Duration(seconds: 3), () {
                        setState(() {
                          loader.value = false;
                        });
                      });

                      // print("called");
                      // print(
                      //     "channel_id:${alldata[index]["channel_id"]}");
                      // print(
                      //     "channel_namesss:${alldata[index]["channel_name"]}");
                      // if (play.value == true)

                      currentindx =
                          alldata[index]["total_number_of_subscribers"];

                      Mqtt.firsttime!.value = false;
                      nameOfChannel.value = alldata[index]["channel_name"];
                      descOfChannel.value =
                          alldata[index]["channel_description"];
                      idOfChannel.value = alldata[index]["channel_id"];
                      urlOfChannel.value = alldata[index]["channel_stream_url"];
                      imgurlOfChannel.value =
                          alldata[index]["channel_image_url"];
                      // startminiplayerOpen(urlOfChannel);

                      await MQTTConnections()
                          .MQTTSubscribeMethod("$idOfChannel");

                      if (displayfavlist.isNotEmpty) {
                        for (int i = 0; i < displayfavlist.length; i++) {
                          if (displayfavlist[i]["channel_id"]
                              .toString()
                              .contains(idOfChannel)) {
                            setState(() {
                              addFavourite = true;
                            });
                            break;
                          } else {
                            setState(() {
                              addFavourite = false;
                            });
                          }
                        }
                      }
                      await _radioPlayer.setChannel(
                        title: '$nameOfChannel',
                        url: '$urlOfChannel',
                        imagePath: '$imgurlOfChannel',
                      );
                      Future.delayed(const Duration(milliseconds: 10), () {
                        _radioPlayer.play();
                      });

                      _radioPlayer.stateStream.listen((value) {
                        print("sdgxcfhjbkn:$value");
                        setState(() {
                          isPlaying = value;
                        });
                      });

                      _radioPlayer.metadataStream.listen((value) {
                        setState(() {
                          metadata = value;
                        });
                      });

                      print("nameOfChannel:${nameOfChannel}");
                      print("descOfChannel:${descOfChannel}");
                      print("firsttime:${Mqtt.firsttime!.value}");
                    } else {
                      // _radioPlayer.stop();
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          behavior: SnackBarBehavior.floating,
                          padding: const EdgeInsets.all(5),
                          shape: const StadiumBorder(),
                          backgroundColor: Colors.white,
                          duration: const Duration(seconds: 3),
                          content: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              SizedBox(
                                width: 40,
                                height: 40,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: const Image(
                                      image: AssetImage(
                                          "assets/Raydeo.ONE512.png")),
                                ),
                              ),
                              const SizedBox(
                                width: 250,
                                child: Text(
                                  "Please check your internet connection and try again",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14),
                                ),
                              )
                            ],
                          )));
                    }
                  },
                  child: ListTile(
                    leading: SizedBox(
                        width: 60,
                        height: 60,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.network(
                              "${alldata[index]['channel_image_url']}"),
                        )),
                    title: Text(alldata[index]['channel_name']),
                    subtitle: Text(alldata[index]['channel_category']),
                  ),
                )
              : const SizedBox(
                  height: 0,
                );
        },
      ),
    );
  }

  // last overwrite to show the
  // querying process at the runtime
  @override
  Widget buildSuggestions(BuildContext context) {
    List matchQuery = [];
    for (var title in searchTerms) {
      if (title.toString().toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(title);
      }
    }
    return Container(
      color: Theme.of(context).backgroundColor,
      child: ListView.builder(
        itemCount: alldata.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return (matchQuery
                      .contains(alldata[index]['channel_name'].toString()) ||
                  matchQuery
                      .contains(alldata[index]['channel_category'].toString()))
              ? InkWell(
                  onTap: () async {
                    close(context, null);
                    if (status != 'Offline') {
                      if (idOfChannel != "") {
                        await MQTTConnections()
                            .unsubscribeToChannel("$idOfChannel");
                        controllerStack.animateToHeight(
                            state: PanelState.MAX,
                            duration: const Duration(milliseconds: 30));
                      }
                      controllerStack.animateToHeight(
                          state: PanelState.MAX,
                          duration: const Duration(milliseconds: 30));
                      loader.value = true;
                      Future.delayed(const Duration(seconds: 3), () {
                        setState(() {
                          loader.value = false;
                        });
                      });

                      // print("called");
                      // print(
                      //     "channel_id:${alldata[index]["channel_id"]}");
                      // print(
                      //     "channel_namesss:${alldata[index]["channel_name"]}");
                      // if (play.value == true)

                      currentindx =
                          alldata[index]["total_number_of_subscribers"];
                      favdata = alldata[index];

                      Mqtt.firsttime!.value = false;
                      nameOfChannel.value = alldata[index]["channel_name"];
                      descOfChannel.value =
                          alldata[index]["channel_description"];
                      idOfChannel.value = alldata[index]["channel_id"];
                      urlOfChannel.value = alldata[index]["channel_stream_url"];
                      imgurlOfChannel.value =
                          alldata[index]["channel_image_url"];
                      // startminiplayerOpen(urlOfChannel);

                      await MQTTConnections()
                          .MQTTSubscribeMethod("$idOfChannel");
                      // _radioPlayer.stop();
                      if (displayfavlist.isNotEmpty) {
                        for (int i = 0; i < displayfavlist.length; i++) {
                          if (displayfavlist[i]["channel_id"]
                              .toString()
                              .contains(idOfChannel)) {
                            setState(() {
                              addFavourite = true;
                            });
                            break;
                          } else {
                            setState(() {
                              addFavourite = false;
                            });
                          }
                        }
                      }
                      await _radioPlayer.setChannel(
                        title: '$nameOfChannel',
                        url: '$urlOfChannel',
                        imagePath: '$imgurlOfChannel',
                      );
                      Future.delayed(const Duration(milliseconds: 10), () {
                        _radioPlayer.play();
                      });

                      _radioPlayer.stateStream.listen((value) {
                        print("sdgxcfhjbkn:$value");
                        setState(() {
                          isPlaying = value;
                        });
                      });

                      _radioPlayer.metadataStream.listen((value) {
                        setState(() {
                          metadata = value;
                        });
                      });

                      print("nameOfChannel:${nameOfChannel}");
                      print("descOfChannel:${descOfChannel}");
                      print("firsttime:${Mqtt.firsttime!.value}");
                    } else {
                      // _radioPlayer.stop();
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          behavior: SnackBarBehavior.floating,
                          padding: const EdgeInsets.all(5),
                          shape: const StadiumBorder(),
                          backgroundColor: Colors.white,
                          duration: const Duration(seconds: 3),
                          content: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: const [
                              SizedBox(
                                width: 40,
                                height: 40,
                                child: Image(
                                    image:
                                        AssetImage("assets/Raydeo.ONE512.png")),
                              ),
                              SizedBox(
                                width: 250,
                                child: Text(
                                  "Please check your internet connection and try again",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14),
                                ),
                              )
                            ],
                          )));
                    }
                  },
                  child: ListTile(
                    leading: SizedBox(
                        width: 60,
                        height: 60,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.network(
                              "${alldata[index]['channel_image_url']}"),
                        )),
                    title: Text(alldata[index]['channel_name']),
                    subtitle: Text(alldata[index]['channel_category']),
                  ),
                )
              : const SizedBox(
                  height: 0,
                );
        },
      ),
    );
  }
}
