import 'dart:async';
import 'package:flutter/material.dart';
import 'package:raydeo_one/main.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'authpages.dart/firebaseauth.dart';

class MobileNumberVerificationScreen extends StatefulWidget {
  @override
  _MobileNumberVerificationScreenState createState() =>
      _MobileNumberVerificationScreenState();
}

class _MobileNumberVerificationScreenState
    extends State<MobileNumberVerificationScreen> {
  final TextEditingController phoneNumnerController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool? otpSent;
  bool isloading = false;
  bool _isOTPSent = false;
  bool _isPhoneNumberValid = false;
  bool ontapped = true;
  String phoneNumber = "";
  var countryCode;
  @override
  void dispose() {
    phoneNumnerController.dispose();
    super.dispose();
  }

  void _verifyOTP() {
    // Here, you can implement the logic to verify the entered OTP.
    // You might use an API call or a third-party service to verify the OTP.
    // Once the OTP is verified successfully, navigate to the next screen or perform the desired action.
    // You can access the entered OTP using _otpController.text.
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          elevation: 0,
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: const Icon(
                Icons.arrow_back,
                color: Colors.black,
              )),
          title: const Text(
            'Mobile Number Verification',
            style: TextStyle(
              color: Colors.black,
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Container(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.03,
                  ),
                  const Text(
                    'Please enter your mobile number. verification code will be sent to your number.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.03,
                  ),
                  Container(
                    // padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: IntlPhoneField(
                      dropdownIcon: const Icon(
                        Icons.arrow_drop_down_rounded,
                        color: Colors.black,
                      ),
                      flagsButtonMargin: const EdgeInsets.all(5),
                      dropdownDecoration: BoxDecoration(
                          // border: Border.all(color: Colors.grey.shade300),
                          color: Colors.white,
                          shape: BoxShape.rectangle,
                          borderRadius: BorderRadius.circular(30)),
                      autovalidateMode: AutovalidateMode.disabled,
                      dropdownTextStyle: const TextStyle(fontSize: 16),
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          isCollapsed: true,
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 14),
                          border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          enabledBorder: const OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: maincolor),
                          ),
                          filled: true,
                          hintText: "Phone Number",
                          hintStyle: TextStyle(color: maincolor),
                          labelStyle: TextStyle(color: maincolor),
                          labelText: "Phone Number"),
                      controller: phoneNumnerController,
                      initialCountryCode: "IN",
                      autofocus: false,
                      onChanged: (phone) {
                        countryCode = phone.countryCode;
                      },
                      onTap: () {
                        setState(() {
                          ontapped = false;
                        });

                        // _formKey.currentState!.reset();
                      },
                      validator: (number) {
                        if (ontapped = true) {
                          if (number == null) {
                            return "Required Number";
                          } else {
                            return null;
                          }
                        }

                        return null;
                      },
                    ),
                  ),
                  const SizedBox(height: 40.0),
                  Container(
                    width: double.infinity,
                    // padding: EdgeInsets.all(5),
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: maincolor),
                        child: isloading == true
                            ? const CircularProgressIndicator(
                                color: Colors.white,
                              )
                            : const Text(
                                'Send OTP',
                                style: TextStyle(color: Colors.black),
                              ),
                        onPressed: () {
                          FirebaseConfiguration().phoneNumberVerification(
                              countryCode, phoneNumnerController.text, context);
                          setState(() {
                            _isOTPSent = true;
                          });
                          setState(() {
                            isloading = true;
                          });
                          Timer(
                            const Duration(seconds: 8),
                            () {
                              setState(() {
                                isloading = false;
                              });
                            },
                          );
                        }),
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
