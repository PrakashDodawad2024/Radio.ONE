import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:raydeo_one/main.dart';
import 'package:raydeo_one/profilepages/profile.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'phoneverifyscreen.dart';

class FirebaseConfiguration {
  FirebaseAuth auth = FirebaseAuth.instance;
  List informstion = [];

  Future phoneNumberVerification(countryCode, phoneNumber, context) async {
    print("countrycode$countryCode");
    print("phoneNumber$phoneNumber");
    try {
      await auth.verifyPhoneNumber(
          timeout: Duration(seconds: 5),
          phoneNumber: '${countryCode}${phoneNumber}',
          verificationCompleted: (PhoneAuthCredential) {},
          verificationFailed: (FirebaseAuthException exception) async {
            print("wdavcz");
            // Generic().showLoadingIndicator(context);
            // ScaffoldMessenger.of(context)
            //     .showSnackBar(SnackBar(content: Text("${exception.message}")));
          },
          codeSent: (String VerificationID, int? resendToken) async {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => PhoneVerifyScreen(
                    countryCode,
                    phoneNumber,
                    VerificationID,
                  ),
                ));

            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            //     backgroundColor: Colors.green,
            //     content: Text(
            //       "OTP Sent Successfully.....!",
            //     )));
            // Generic().showSuccessSnackBar("OTP sent", context);
          },
          codeAutoRetrievalTimeout: (String VerificationID) {});
      return 'SUCCESS';
    } catch (error) {
      print(error);
      return 'ERROR';
    }
  }

  verifyOTP(
    countryCode,
    phoneNumber,
    otp,
    verificationid,
    context,
  ) {
    AuthCredential authCredential = PhoneAuthProvider.credential(
        verificationId: verificationid, smsCode: otp);
    auth.signInWithCredential(authCredential).then(
      (result) async {
        SharedPreferences sharedPreferences =
            await SharedPreferences.getInstance();
        SharedPreferences prefs = await SharedPreferences.getInstance();

        // sharedPreferences.setString('userName', name);
        // print('userName:${name}');
        sharedPreferences.setString('userCountryCode', countryCode);
        print('userCountryCode:${countryCode}');
        sharedPreferences.setString('userNumber', phoneNumber);
        print('userNumber:${phoneNumber}');
        // await grapqlapiservice()
        //     .getCurrentUserDeteil(countryCode, phoneNumber, name);

        sharedPreferences.setBool('Signedin', true);
        prefs.setBool('isFirstTime', false);
        print("siiignedIn:${prefs.getBool('isFirstTime')}");

        print("signedIn:${sharedPreferences.getBool('Signedin')}");

        // await grapqlapiservice().getConusmer();
        accountdetails!.put("MobNoVerified", true);
        accountdetails!.put("mobileNumber", "${countryCode}${phoneNumber}");

        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: ((context) => Profile())));

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            backgroundColor: Colors.green,
            content: Text(
              "Mobile Number verified Successfully.....!",
            )));
      },
    ).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          backgroundColor: Colors.red,
          content: Text(
            "Please enter the correct OTP...!",
          )));
    });
    return "SUCESS";
  }
}
