import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';

import '../main.dart';
import 'mqttconnection.dart';

class Mqtt {
  static RxBool? firsttime = true.obs;
  static RxBool? viewalll = true.obs;
  RxString uniqueId = "".obs;
  // registerUserMethod() async {
  //   print("register user");
  //       DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  //   AndroidDeviceInfo tvInfo = await deviceInfo.androidInfo;
  //   log(tvInfo.toString());
  //   final SharedPreferences sharedPreferences =
  //       await SharedPreferences.getInstance();
  //   final DeviceId = await sharedPreferences.getString('device_id');
  //   print(DeviceId);
  //   print(tvInfo.model);
  //   try {
  //     final SharedPreferences sharedPreferences =
  //         await SharedPreferences.getInstance();
  //     // final userCountryCode = sharedPreferences.getString('UserCountryCode');
  //     // final userMobileNumber = sharedPreferences.getString('UserMobileNumber');
  //     // final userName = sharedPreferences.getString('UserName');
  //     // print("Name:$userName");
  //     var url = Uri.parse(
  //         'https://bjzrb8a47c.execute-api.ap-south-1.amazonaws.com/production/registeruser');
  //     var response = await http.post(url,
  //         headers: {
  //           'Content-Type': 'application/json',
  //           'x-api-key': 'XlbJLSIbFn8A3yEi4bcNX5oWbuDp2H9x8a7IxVA0',
  //         },
  //         body: json.encode({
  //           "user_mobile_number": "+916366133365",
  //           "user_country_code": "+91",
  //           "user_contact_number": "6366133365",
  //           "user_name": "prakash",
  //         }));
  //     // print("statuscode:${response.statusCode}");
  //     // log("response:${response.body}");
  //     if (json.decode(response.body)['status'] == 'success') {
  //       return json.decode(response.body);
  //     } else {
  //       // ShowToast().showToast('You are offline');
  //     }
  //   } catch (e) {
  //     // ShowToast().showToast('You are offline');
  //     return e;
  //   }
  // }
  registerUserMethod() async {
    print("decodedBodyRegidteruser");
    // String DeviceId = '';
    // Loading.value = true;
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    var deviceid = await deviceInfo.androidInfo.toString();
    AndroidDeviceInfo tvInfo = await deviceInfo.androidInfo;
    log(tvInfo.toString());
    print("decodedBody:${tvInfo.model}");
    print("decodedBody:${tvInfo.id}");
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    // sharedPreferences.setString('device_id', tvInfo.id);
    // final DeviceId = await sharedPreferences.getString('device_id');
    // print(DeviceId);
    print(tvInfo.model);
    print('*GETTING QR CODE*');
    try {
      var headers = {
        'Content-Type': 'application/json',
        'x-api-key': 'XlbJLSIbFn8A3yEi4bcNX5oWbuDp2H9x8a7IxVA0'
      };
      var request = http.Request(
          'POST',
          Uri.parse(
              'https://bjzrb8a47c.execute-api.ap-south-1.amazonaws.com/production/registerdeviceandgenerateqr'));
      request.body = json.encode({
        if (tvInfo.id != null) "device_id": "", //id has to be empty
        "device_name": "${tvInfo.model}"
      });
      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        final body = await response.stream.bytesToString();
        final decodedBody = await json.decode(body.toString());
        // clientdetails!.put('clientDeets', decodedBody);
        print(body);
        print("decodedBody111:$decodedBody");
        print(decodedBody['device_id']);
        print(decodedBody['unique_id']);
        print(decodedBody['connection_details']['ip_address']);

        uniqueId.value = decodedBody['unique_id'];

        final SharedPreferences sharedPreferences =
            await SharedPreferences.getInstance();
        sharedPreferences.setString('device_id', decodedBody['unique_id']);
        print("spdata:${sharedPreferences.getString('device_id')}");
        print(
            "aconnectionData:${jsonEncode(decodedBody['connection_details'])}");
        sharedPreferences.setBool("isRegistered", true);
        sharedPreferences.setString(
            'allconnectionData', jsonEncode(decodedBody['connection_details']));
        print("spdata:${sharedPreferences.getString('allconnectionData')}");
        await MQTTConnections().connectToMQTTMethod(
            decodedBody['connection_details']['ip_address'],
            decodedBody['connection_details']['port'],
            decodedBody['connection_details']['user_name'],
            decodedBody['connection_details']['password']);
        // websocketSubscribe(decodedBody['device_id'], decodedBody['unique_id']);
        // listAllSubscriptionsOfUser();
      } else {
        print(response.reasonPhrase);
      }
    } catch (e) {
      print(e);
    }
  }
}
